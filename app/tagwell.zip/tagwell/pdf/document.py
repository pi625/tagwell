"""PDF file structure: cross-reference tables/streams, object streams, page tree (ISO 32000-1 §7.5)."""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Iterator

from .objects import Keyword, Lexer, Name, PDFError, PDFString, Ref, Stream, text_of

_OBJ_HEADER_RE = re.compile(rb"(?<![0-9])(\d{1,10})\s+(\d{1,5})\s+obj\b")


class EncryptedPDFError(PDFError):
    """The file is encrypted; this MVP does not implement the security handlers."""


@dataclass
class Page:
    index: int
    dict: dict
    resources: dict
    mediabox: tuple[float, float, float, float]
    cropbox: tuple[float, float, float, float]
    rotate: int
    ref: Ref | None = None
    contents: list[Stream] = field(default_factory=list)

    @property
    def width(self) -> float:
        x0, y0, x1, y1 = self.cropbox
        w, h = abs(x1 - x0), abs(y1 - y0)
        return h if self.rotate % 180 else w

    @property
    def height(self) -> float:
        x0, y0, x1, y1 = self.cropbox
        w, h = abs(x1 - x0), abs(y1 - y0)
        return w if self.rotate % 180 else h

    def to_display(self, x: float, y: float) -> tuple[float, float]:
        """Map default user space to an upright display space with origin at the
        bottom-left of the (rotated) crop box. Larger y is higher on the page."""
        x0, y0, x1, y1 = self.cropbox
        x0, x1 = min(x0, x1), max(x0, x1)
        y0, y1 = min(y0, y1), max(y0, y1)
        r = self.rotate % 360
        if r == 90:
            return (y - y0, (x1 - x0) - (x - x0))
        if r == 180:
            return ((x1 - x0) - (x - x0), (y1 - y0) - (y - y0))
        if r == 270:
            return ((y1 - y0) - (y - y0), x - x0)
        return (x - x0, y - y0)


class Document:
    def __init__(self, data: bytes):
        if not data:
            raise PDFError("empty file")
        self.data = data
        self.xref: dict[int, tuple] = {}  # num -> ("n", offset, gen) | ("c", objstm_num, index)
        self.trailer: dict = {}
        self._cache: dict[int, Any] = {}
        self._objstm_cache: dict[int, dict[int, Any]] = {}
        self.repaired = False
        self.warnings: list[str] = []
        self.crypt = None
        self.encrypted = False
        self._encrypt_num: int | None = None
        self._load_xref()
        if not self.trailer.get("Root"):
            self._reconstruct()
        if self.trailer.get("Encrypt") is not None:
            self._init_crypt()
        root = self.resolve(self.trailer.get("Root"))
        if not isinstance(root, dict):
            self._reconstruct()
            root = self.resolve(self.trailer.get("Root"))
        if not isinstance(root, dict):
            raise PDFError("no document catalog")
        self.catalog: dict = root
        self.pages: list[Page] = list(self._walk_pages())

    def _init_crypt(self) -> None:
        from .crypto import DecryptionError, StandardSecurityHandler

        enc_ref = self.trailer.get("Encrypt")
        self._encrypt_num = enc_ref.num if isinstance(enc_ref, Ref) else None
        enc = self.resolve(enc_ref)
        if not isinstance(enc, dict):
            raise EncryptedPDFError("encrypted PDF with an unreadable /Encrypt dictionary")
        ids = self.resolve(self.trailer.get("ID"))
        first_id = bytes(self.resolve(ids[0])) if isinstance(ids, list) and ids else b""
        try:
            self.crypt = StandardSecurityHandler(enc, first_id, self.resolve)
        except DecryptionError as e:
            raise EncryptedPDFError(f"encrypted PDF: {e}") from e
        self.encrypted = True
        # Anything parsed before the key was known is still ciphertext.
        keep = {self._encrypt_num: self._cache[self._encrypt_num]} if self._encrypt_num in self._cache else {}
        self._cache = keep
        self._objstm_cache.clear()

    def _decrypt_value(self, v: Any, num: int, gen: int) -> Any:
        if isinstance(v, PDFString):
            return PDFString(self.crypt.decrypt_string(num, gen, bytes(v)))
        if isinstance(v, list):
            return [self._decrypt_value(x, num, gen) for x in v]
        if isinstance(v, dict):
            return {k: self._decrypt_value(x, num, gen) for k, x in v.items()}
        return v

    def _decrypt_obj(self, obj: Any, num: int, gen: int) -> Any:
        if isinstance(obj, Stream):
            t = obj.dict.get("Type")
            if t == "XRef":
                return obj
            obj.dict = self._decrypt_value(obj.dict, num, gen)
            if t == "Metadata" and not self.crypt.encrypt_metadata:
                return obj
            filters = obj.dict.get("Filter")
            if filters == "Crypt" or (isinstance(filters, list) and filters[:1] == ["Crypt"]):
                return obj  # Identity crypt filter (the only one we meet in practice)
            # Decrypt lazily: large image streams are never decoded, so never decrypted.
            crypt = self.crypt
            obj._pre = lambda raw, n=num, g=gen: crypt.decrypt_stream(n, g, raw)
            obj._decoded = None
            return obj
        return self._decrypt_value(obj, num, gen)

    @classmethod
    def open(cls, path: str) -> "Document":
        with open(path, "rb") as fh:
            return cls(fh.read())

    # -- cross reference -----------------------------------------------------
    def _load_xref(self) -> None:
        idx = self.data.rfind(b"startxref")
        if idx < 0:
            self._reconstruct()
            return
        lx = Lexer(self.data, idx + len(b"startxref"))
        offset = lx.next_token()
        seen: set[int] = set()
        first = True
        try:
            while isinstance(offset, int) and offset not in seen and 0 <= offset < len(self.data):
                seen.add(offset)
                trailer = self._read_xref_section(offset)
                if first:
                    self.trailer = dict(trailer)
                    first = False
                else:
                    for k, v in trailer.items():
                        self.trailer.setdefault(k, v)
                if isinstance(trailer.get("XRefStm"), int):
                    try:
                        self._read_xref_section(trailer["XRefStm"])
                    except PDFError:
                        pass
                offset = trailer.get("Prev")
        except PDFError as e:
            self.warnings.append(f"xref damaged ({e}); reconstructed by scanning")
            self._reconstruct()
            return
        if not self.xref:
            self._reconstruct()

    def _read_xref_section(self, offset: int) -> dict:
        lx = Lexer(self.data, offset)
        lx.skip_ws()
        if self.data.startswith(b"xref", lx.pos):
            lx.pos += 4
            while True:
                save = lx.pos
                tok = lx.next_token()
                if isinstance(tok, Keyword) and tok == "trailer":
                    trailer = lx.parse_object()
                    if not isinstance(trailer, dict):
                        raise PDFError("bad trailer")
                    return trailer
                if not isinstance(tok, int):
                    lx.pos = save
                    raise PDFError("bad xref table")
                start = tok
                count = lx.next_token()
                if not isinstance(count, int):
                    raise PDFError("bad xref subsection")
                lx.skip_ws()
                for i in range(count):
                    lx.skip_ws()
                    line = self.data[lx.pos : lx.pos + 20]
                    parts = line.split()
                    if len(parts) < 3:
                        raise PDFError("bad xref entry")
                    lx.pos += 18
                    while lx.pos < len(self.data) and self.data[lx.pos] in b"\r\n ":
                        lx.pos += 1
                    try:
                        off, gen, kind = int(parts[0]), int(parts[1]), parts[2][:1]
                    except ValueError as e:
                        raise PDFError("bad xref entry") from e
                    num = start + i
                    if num in self.xref:
                        continue  # newer section already defined it
                    if kind == b"n" and off > 0:
                        self.xref[num] = ("n", off, gen)
                    else:
                        self.xref[num] = ("f",)
        # xref stream
        obj = self._parse_indirect_at(offset)
        if not isinstance(obj, Stream) or obj.dict.get("Type") != "XRef":
            raise PDFError("startxref does not point to xref")
        d = obj.dict
        w = d.get("W") or [1, 2, 1]
        size = d.get("Size", 0)
        index = d.get("Index") or [0, size]
        data = obj.decode()
        entry_len = sum(w)
        pos = 0
        for s in range(0, len(index) - 1, 2):
            start, count = index[s], index[s + 1]
            for i in range(count):
                if pos + entry_len > len(data):
                    break
                fields = []
                p = pos
                for width in w:
                    v = 0
                    for b in data[p : p + width]:
                        v = (v << 8) | b
                    fields.append(v)
                    p += width
                pos += entry_len
                ftype = fields[0] if w[0] else 1
                num = start + i
                if num in self.xref:
                    continue
                if ftype == 1:
                    self.xref[num] = ("n", fields[1], fields[2] if len(fields) > 2 else 0)
                elif ftype == 2:
                    self.xref[num] = ("c", fields[1], fields[2])
                else:
                    self.xref[num] = ("f",)
        return d

    def _reconstruct(self) -> None:
        """Rebuild the xref by scanning for `n g obj` headers (last definition wins)."""
        self.repaired = True
        self.xref = {}
        self._cache.clear()
        for m in _OBJ_HEADER_RE.finditer(self.data):
            self.xref[int(m.group(1))] = ("n", m.start(), int(m.group(2)))
        trailer: dict = {}
        for m in re.finditer(rb"trailer", self.data):
            lx = Lexer(self.data, m.end())
            t = lx.parse_object()
            if isinstance(t, dict):
                trailer.update(t)
        # Object streams and xref streams may hold the catalog in modern files.
        for num, entry in list(self.xref.items()):
            obj = self._load(num)
            if isinstance(obj, Stream):
                if obj.dict.get("Type") == "XRef":
                    for k in ("Root", "Info", "ID", "Encrypt"):
                        if k in obj.dict:
                            trailer.setdefault(k, obj.dict[k])
                elif obj.dict.get("Type") == "ObjStm":
                    try:
                        for inner in self._objstm(num):
                            self.xref.setdefault(inner, ("c", num, -1))
                    except PDFError:
                        pass
        if "Root" not in trailer:
            for num in self.xref:
                obj = self._load(num)
                if isinstance(obj, dict) and obj.get("Type") == "Catalog":
                    trailer["Root"] = Ref(num, 0)
                    break
        self.trailer = trailer

    # -- objects ---------------------------------------------------------
    def _parse_indirect_at(self, offset: int, num: int | None = None) -> Any:
        lx = Lexer(self.data, offset)
        n = lx.next_token()
        g = lx.next_token()
        kw = lx.next_token()
        if not (isinstance(n, int) and isinstance(g, int) and kw == "obj"):
            # Offsets are sometimes off by a few bytes; search nearby.
            window = self.data[max(0, offset - 64) : offset + 64]
            pat = (str(num).encode() if num is not None else rb"\d+") + rb"\s+\d+\s+obj\b"
            m = re.search(pat, window)
            if not m:
                raise PDFError(f"no object at offset {offset}")
            lx = Lexer(self.data, max(0, offset - 64) + m.end())
            n = num
        obj = lx.parse_object()
        save = lx.pos
        tok = lx.next_token()
        if isinstance(obj, dict) and isinstance(tok, Keyword) and tok == "stream":
            pos = lx.pos
            if self.data[pos : pos + 2] == b"\r\n":
                pos += 2
            elif self.data[pos : pos + 1] in (b"\n", b"\r"):
                pos += 1
            length = obj.get("Length")
            if isinstance(length, Ref):
                length = self._resolve_length(length)
            end = None
            if isinstance(length, int) and length >= 0:
                cand = pos + length
                tail = self.data[cand : cand + 20]
                if b"endstream" in tail:
                    end = cand
            if end is None:
                k = self.data.find(b"endstream", pos)
                if k < 0:
                    raise PDFError("unterminated stream")
                end = k
                while end > pos and self.data[end - 1] in b"\r\n":
                    end -= 1
            ref = Ref(n, 0) if isinstance(n, int) else None
            return Stream(obj, self.data[pos:end], ref, self)
        lx.pos = save
        return obj

    def _resolve_length(self, ref: Ref) -> Any:
        entry = self.xref.get(ref.num)
        if entry and entry[0] == "n":
            try:
                return self._parse_indirect_at(entry[1], ref.num)
            except PDFError:
                return None
        return self.resolve(ref)

    def _objstm(self, stm_num: int) -> dict[int, Any]:
        if stm_num in self._objstm_cache:
            return self._objstm_cache[stm_num]
        stm = self._load(stm_num)
        if not isinstance(stm, Stream):
            raise PDFError("object stream missing")
        n = self.resolve(stm.dict.get("N")) or 0
        first = self.resolve(stm.dict.get("First")) or 0
        data = stm.decode()
        lx = Lexer(data)
        pairs = []
        for _ in range(n):
            a, b = lx.next_token(), lx.next_token()
            if not (isinstance(a, int) and isinstance(b, int)):
                break
            pairs.append((a, b))
        objs: dict[int, Any] = {}
        for num, off in pairs:
            lx2 = Lexer(data, first + off)
            try:
                objs[num] = lx2.parse_object()
            except Exception:  # noqa: BLE001 - one broken object must not sink the file
                objs[num] = None
        self._objstm_cache[stm_num] = objs
        return objs

    def _load(self, num: int) -> Any:
        if num in self._cache:
            return self._cache[num]
        entry = self.xref.get(num)
        obj: Any = None
        if entry is None or entry[0] == "f":
            obj = None
        elif entry[0] == "n":
            try:
                obj = self._parse_indirect_at(entry[1], num)
            except PDFError as e:
                self.warnings.append(f"object {num}: {e}")
                obj = None
            if self.crypt is not None and obj is not None and num != self._encrypt_num:
                try:
                    obj = self._decrypt_obj(obj, num, entry[2] if len(entry) > 2 else 0)
                except Exception as e:  # noqa: BLE001 - a bad object must not sink the file
                    self.warnings.append(f"object {num}: decryption failed ({e})")
                    obj = None
        elif entry[0] == "c":
            try:
                obj = self._objstm(entry[1]).get(num)
            except PDFError as e:
                self.warnings.append(f"object {num} in stream {entry[1]}: {e}")
                obj = None
        if isinstance(obj, Stream) and obj.ref is None:
            obj.ref = Ref(num, 0)
        self._cache[num] = obj
        return obj

    def resolve(self, obj: Any, depth: int = 0) -> Any:
        while isinstance(obj, Ref):
            if depth > 32:
                return None
            obj = self._load(obj.num)
            depth += 1
        return obj

    def get(self, d: Any, key: str, default: Any = None) -> Any:
        d = self.resolve(d)
        if isinstance(d, Stream):
            d = d.dict
        if not isinstance(d, dict):
            return default
        v = self.resolve(d.get(key))
        return default if v is None else v

    # -- page tree ---------------------------------------------------------
    def _walk_pages(self) -> Iterator[Page]:
        root = self.get(self.catalog, "Pages")
        index = 0
        stack: list[tuple[Any, dict, int]] = [(self.catalog.get("Pages"), {}, 0)]
        visited: set[int] = set()
        if root is None:
            return
        while stack:
            node_ref, inherited, depth = stack.pop()
            node = self.resolve(node_ref)
            if not isinstance(node, dict) or depth > 64:
                continue
            key = node_ref.num if isinstance(node_ref, Ref) else id(node)
            if key in visited:
                continue
            visited.add(key)
            inh = dict(inherited)
            for k in ("Resources", "MediaBox", "CropBox", "Rotate"):
                if k in node:
                    inh[k] = node[k]
            kids = self.resolve(node.get("Kids"))
            ntype = node.get("Type")
            if ntype == "Pages" or (ntype is None and isinstance(kids, list)):
                for kid in reversed(kids or []):
                    stack.append((kid, inh, depth + 1))
                continue
            mb = self._box(inh.get("MediaBox")) or (0.0, 0.0, 612.0, 792.0)
            cb = self._box(inh.get("CropBox")) or mb
            rot = self.resolve(inh.get("Rotate")) or 0
            res = self.resolve(inh.get("Resources")) or {}
            contents = self.resolve(node.get("Contents"))
            streams: list[Stream] = []
            for c in contents if isinstance(contents, list) else [contents]:
                c = self.resolve(c)
                if isinstance(c, Stream):
                    streams.append(c)
            yield Page(index, node, res if isinstance(res, dict) else {}, mb, cb,
                       int(rot) if isinstance(rot, (int, float)) else 0,
                       node_ref if isinstance(node_ref, Ref) else None, streams)
            index += 1

    def _box(self, v: Any) -> tuple[float, float, float, float] | None:
        v = self.resolve(v)
        if isinstance(v, list) and len(v) == 4:
            try:
                vals = [float(self.resolve(x)) for x in v]
                return (vals[0], vals[1], vals[2], vals[3])
            except (TypeError, ValueError):
                return None
        return None

    def page_index_of(self, ref: Any) -> int | None:
        if not isinstance(ref, Ref):
            return None
        if not hasattr(self, "_page_by_num"):
            self._page_by_num = {p.ref.num: p.index for p in self.pages if p.ref is not None}
        return self._page_by_num.get(ref.num)

    # -- metadata ------------------------------------------------------------
    def info(self) -> dict:
        info = self.resolve(self.trailer.get("Info"))
        return info if isinstance(info, dict) else {}

    def xmp(self) -> str | None:
        md = self.get(self.catalog, "Metadata")
        if isinstance(md, Stream):
            try:
                return md.decode().decode("utf-8", "replace")
            except PDFError:
                return None
        return None

    def title(self) -> tuple[str | None, str | None]:
        """Return (xmp dc:title, Info /Title)."""
        xmp_title = None
        xmp = self.xmp()
        if xmp:
            m = re.search(r"<dc:title>(.*?)</dc:title>", xmp, re.S)
            if m:
                inner = re.sub(r"<[^>]+>", " ", m.group(1))
                inner = re.sub(r"\s+", " ", inner).strip()
                xmp_title = _xml_unescape(inner) or None
        info_title = text_of(self.resolve(self.info().get("Title")))
        return xmp_title, (info_title.strip() if info_title else None)


def _xml_unescape(s: str) -> str:
    return (s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"')
            .replace("&apos;", "'").replace("&amp;", "&"))


__all__ = ["Document", "Page", "PDFError", "EncryptedPDFError", "Name", "PDFString", "Ref", "Stream"]
