"""PDF Standard Security Handler (ISO 32000-1 §7.6, ISO 32000-2 §7.6.4): RC4 and AES.

Only the empty user password is tried: Tagwell opens documents that anyone can open, which
covers the very common "permissions only" encryption used to stop editing or copying. Pure Python
(AES included) so the package stays dependency-free; speed is adequate for document-sized data.
"""
from __future__ import annotations

import hashlib
import struct

PAD = bytes.fromhex("28BF4E5E4E758A4164004E56FFFA01082E2E00B6D0683E802F0CA9FE6453697A")

# --- RC4 -------------------------------------------------------------------------------


def rc4(key: bytes, data: bytes) -> bytes:
    s = list(range(256))
    j = 0
    klen = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % klen]) & 0xFF
        s[i], s[j] = s[j], s[i]
    out = bytearray(len(data))
    i = j = 0
    for n, b in enumerate(data):
        i = (i + 1) & 0xFF
        j = (j + s[i]) & 0xFF
        s[i], s[j] = s[j], s[i]
        out[n] = b ^ s[(s[i] + s[j]) & 0xFF]
    return bytes(out)


# --- AES (FIPS-197) ------------------------------------------------------------------------

def _xtime(a: int) -> int:
    a <<= 1
    return (a ^ 0x11B) if a & 0x100 else a


def _build_tables():
    """S-box from the multiplicative inverse in GF(2^8) followed by the AES affine transform."""
    exp, log = [0] * 255, [0] * 256
    x = 1
    for i in range(255):
        exp[i] = x
        log[x] = i
        x ^= _xtime(x) & 0xFF  # multiply by the generator 3
        x &= 0xFF
    sbox = [0] * 256
    for a in range(256):
        b = 0 if a == 0 else exp[(255 - log[a]) % 255]
        rot = 0
        for k in range(5):
            rot ^= ((b << k) | (b >> (8 - k))) & 0xFF
        sbox[a] = rot ^ 0x63
    inv = [0] * 256
    for i, v in enumerate(sbox):
        inv[v] = i
    return sbox, inv


SBOX, INV_SBOX = _build_tables()


def _mul(a: int, b: int) -> int:
    r = 0
    while b:
        if b & 1:
            r ^= a
        a = _xtime(a)
        b >>= 1
    return r & 0xFF


_M2 = [_mul(i, 2) for i in range(256)]
_M3 = [_mul(i, 3) for i in range(256)]
_M9 = [_mul(i, 9) for i in range(256)]
_M11 = [_mul(i, 11) for i in range(256)]
_M13 = [_mul(i, 13) for i in range(256)]
_M14 = [_mul(i, 14) for i in range(256)]


class AES:
    def __init__(self, key: bytes):
        if len(key) not in (16, 24, 32):
            raise ValueError("AES key must be 16, 24 or 32 bytes")
        nk = len(key) // 4
        self.nr = nk + 6
        w = [list(key[4 * i: 4 * i + 4]) for i in range(nk)]
        rcon = 1
        for i in range(nk, 4 * (self.nr + 1)):
            t = list(w[i - 1])
            if i % nk == 0:
                t = t[1:] + t[:1]
                t = [SBOX[b] for b in t]
                t[0] ^= rcon
                rcon = _xtime(rcon) & 0xFF
            elif nk > 6 and i % nk == 4:
                t = [SBOX[b] for b in t]
            w.append([w[i - nk][k] ^ t[k] for k in range(4)])
        self.rk = [sum(w[4 * r: 4 * r + 4], []) for r in range(self.nr + 1)]

    def encrypt_block(self, block: bytes) -> bytes:
        s = [b ^ k for b, k in zip(block, self.rk[0])]
        for r in range(1, self.nr + 1):
            s = [SBOX[b] for b in s]
            s = [s[(i + 4 * (i % 4)) % 16] for i in range(16)]  # ShiftRows (column-major state)
            if r != self.nr:
                t = []
                for c in range(4):
                    a0, a1, a2, a3 = s[4 * c: 4 * c + 4]
                    t += [_M2[a0] ^ _M3[a1] ^ a2 ^ a3, a0 ^ _M2[a1] ^ _M3[a2] ^ a3,
                          a0 ^ a1 ^ _M2[a2] ^ _M3[a3], _M3[a0] ^ a1 ^ a2 ^ _M2[a3]]
                s = t
            s = [b ^ k for b, k in zip(s, self.rk[r])]
        return bytes(s)

    def decrypt_block(self, block: bytes) -> bytes:
        s = [b ^ k for b, k in zip(block, self.rk[self.nr])]
        for r in range(self.nr - 1, -1, -1):
            s = [s[(i - 4 * (i % 4)) % 16] for i in range(16)]  # InvShiftRows
            s = [INV_SBOX[b] for b in s]
            s = [b ^ k for b, k in zip(s, self.rk[r])]
            if r != 0:
                t = []
                for c in range(4):
                    a0, a1, a2, a3 = s[4 * c: 4 * c + 4]
                    t += [_M14[a0] ^ _M11[a1] ^ _M13[a2] ^ _M9[a3], _M9[a0] ^ _M14[a1] ^ _M11[a2] ^ _M13[a3],
                          _M13[a0] ^ _M9[a1] ^ _M14[a2] ^ _M11[a3], _M11[a0] ^ _M13[a1] ^ _M9[a2] ^ _M14[a3]]
                s = t
        return bytes(s)

    def cbc_decrypt(self, iv: bytes, data: bytes) -> bytes:
        out = bytearray()
        prev = iv
        for i in range(0, len(data) - len(data) % 16, 16):
            blk = data[i: i + 16]
            out += bytes(a ^ b for a, b in zip(self.decrypt_block(blk), prev))
            prev = blk
        return bytes(out)

    def cbc_encrypt(self, iv: bytes, data: bytes) -> bytes:
        out = bytearray()
        prev = iv
        for i in range(0, len(data), 16):
            blk = bytes(a ^ b for a, b in zip(data[i: i + 16], prev))
            prev = self.encrypt_block(blk)
            out += prev
        return bytes(out)


def unpad(data: bytes) -> bytes:
    if data and 1 <= data[-1] <= 16 and data.endswith(bytes([data[-1]]) * data[-1]):
        return data[: -data[-1]]
    return data


def aes_decrypt_pdf(key: bytes, data: bytes) -> bytes:
    """PDF AES: 16-byte IV followed by CBC ciphertext with PKCS#5 padding."""
    if len(data) < 32:
        return b""
    return unpad(AES(key).cbc_decrypt(data[:16], data[16:]))


# --- Standard security handler ---------------------------------------------------------------

class DecryptionError(Exception):
    pass


def _r6_hash(pwd: bytes, salt: bytes, udata: bytes, revision: int) -> bytes:
    k = hashlib.sha256(pwd + salt + udata).digest()
    if revision == 5:
        return k
    i = 0
    while True:
        k1 = (pwd + k + udata) * 64
        e = AES(k[:16]).cbc_encrypt(k[16:32], k1)
        m = sum(e[:16]) % 3
        k = (hashlib.sha256, hashlib.sha384, hashlib.sha512)[m](e).digest()
        i += 1
        if i >= 64 and e[-1] <= i - 32:
            break
    return k[:32]


class StandardSecurityHandler:
    def __init__(self, encrypt: dict, first_id: bytes, resolve):
        r = resolve
        if str(r(encrypt.get("Filter"))) != "Standard":
            raise DecryptionError(f"unsupported security handler {r(encrypt.get('Filter'))}")
        self.v = int(r(encrypt.get("V")) or 0)
        self.r = int(r(encrypt.get("R")) or 0)
        self.o = bytes(r(encrypt.get("O")) or b"")
        self.u = bytes(r(encrypt.get("U")) or b"")
        self.p = int(r(encrypt.get("P")) or 0)
        self.length = int(r(encrypt.get("Length")) or 40)
        self.encrypt_metadata = r(encrypt.get("EncryptMetadata")) is not False
        self.ue = bytes(r(encrypt.get("UE")) or b"")
        self.id0 = first_id or b""
        self.stm_method = self.str_method = "V2" if self.v in (1, 2) else None
        if self.v >= 4:
            cf = r(encrypt.get("CF")) or {}
            stmf = str(r(encrypt.get("StmF")) or "Identity")
            strf = str(r(encrypt.get("StrF")) or "Identity")
            self.stm_method = self._cfm(cf, stmf, r)
            self.str_method = self._cfm(cf, strf, r)
        self.key = self._compute_key()

    @staticmethod
    def _cfm(cf: dict, name: str, r) -> str | None:
        if name == "Identity":
            return None
        d = r(cf.get(name)) or {}
        m = str(r(d.get("CFM")) or "None")
        return {"V2": "V2", "AESV2": "AESV2", "AESV3": "AESV3", "None": None}.get(m, m)

    def _compute_key(self) -> bytes:
        if self.r >= 5:
            return self._key_r6(b"")
        n = 5 if self.r == 2 else self.length // 8
        h = hashlib.md5(PAD + self.o[:32] + struct.pack("<i", self.p) + self.id0)
        if self.r >= 4 and not self.encrypt_metadata:
            h.update(b"\xff\xff\xff\xff")
        key = h.digest()
        if self.r >= 3:
            for _ in range(50):
                key = hashlib.md5(key[:n]).digest()
        key = key[:n]
        if not self._check_user(key):
            raise DecryptionError("a password is required to open this document")
        return key

    def _check_user(self, key: bytes) -> bool:
        if self.r == 2:
            return rc4(key, PAD) == self.u[:32]
        x = rc4(key, hashlib.md5(PAD + self.id0).digest())
        for i in range(1, 20):
            x = rc4(bytes(b ^ i for b in key), x)
        return x[:16] == self.u[:16]

    def _key_r6(self, pwd: bytes) -> bytes:
        u = self.u
        if len(u) < 48:
            raise DecryptionError("malformed /U for AES-256")
        if _r6_hash(pwd, u[32:40], b"", self.r) != u[:32]:
            raise DecryptionError("a password is required to open this document")
        ik = _r6_hash(pwd, u[40:48], b"", self.r)
        ue = self.ue
        if len(ue) < 32:
            raise DecryptionError("malformed /UE")
        return AES(ik).cbc_decrypt(b"\0" * 16, ue[:32])

    def _obj_key(self, num: int, gen: int, aes: bool) -> bytes:
        if self.r >= 5:
            return self.key
        k = self.key + struct.pack("<i", num)[:3] + struct.pack("<i", gen)[:2]
        if aes:
            k += b"sAlT"
        return hashlib.md5(k).digest()[: min(len(self.key) + 5, 16)]

    def _decrypt(self, method: str | None, num: int, gen: int, data: bytes) -> bytes:
        if method is None:
            return data
        if method == "V2":
            return rc4(self._obj_key(num, gen, False), data)
        if method in ("AESV2", "AESV3"):
            return aes_decrypt_pdf(self._obj_key(num, gen, True), data)
        raise DecryptionError(f"unsupported crypt filter {method}")

    def decrypt_string(self, num: int, gen: int, data: bytes) -> bytes:
        return self._decrypt(self.str_method, num, gen, data)

    def decrypt_stream(self, num: int, gen: int, data: bytes) -> bytes:
        return self._decrypt(self.stm_method, num, gen, data)
