"""Stream decoding filters (ISO 32000-1 §7.4). Image codecs are passed through undecoded."""
from __future__ import annotations

import zlib
from typing import Any

from .objects import Name, PDFError

IMAGE_FILTERS = {"DCTDecode", "DCT", "JPXDecode", "CCITTFaxDecode", "CCF", "JBIG2Decode"}


def _as_list(v: Any) -> list:
    if v is None:
        return []
    return v if isinstance(v, list) else [v]


def decode_stream(stream: Any, doc: Any = None) -> bytes:
    resolve = doc.resolve if doc is not None else (lambda x: x)
    filters = [resolve(f) for f in _as_list(resolve(stream.dict.get("Filter")))]
    parms = [resolve(p) for p in _as_list(resolve(stream.dict.get("DecodeParms")))]
    data = stream.raw
    for i, f in enumerate(filters):
        p = parms[i] if i < len(parms) and isinstance(parms[i], dict) else {}
        p = {k: resolve(v) for k, v in p.items()}
        data = apply_filter(str(f), data, p)
    return data


def apply_filter(name: str, data: bytes, parms: dict | None = None) -> bytes:
    parms = parms or {}
    if name in ("FlateDecode", "Fl"):
        return _predict(flate_decode(data), parms)
    if name in ("LZWDecode", "LZW"):
        return _predict(lzw_decode(data, parms.get("EarlyChange", 1)), parms)
    if name in ("ASCIIHexDecode", "AHx"):
        return ascii_hex_decode(data)
    if name in ("ASCII85Decode", "A85"):
        return ascii85_decode(data)
    if name in ("RunLengthDecode", "RL"):
        return run_length_decode(data)
    if name in IMAGE_FILTERS or name == "Crypt":
        return data
    raise PDFError(f"unsupported filter {name}")


def flate_decode(data: bytes) -> bytes:
    try:
        return zlib.decompress(data)
    except zlib.error:
        # Truncated or trailing-garbage streams are common; salvage what we can.
        d = zlib.decompressobj()
        out = bytearray()
        try:
            for i in range(0, len(data), 4096):
                out += d.decompress(data[i : i + 4096])
        except zlib.error:
            pass
        if not out:
            # Some producers emit raw deflate without the zlib header.
            try:
                return zlib.decompress(data, -15)
            except zlib.error as e:
                raise PDFError(f"bad Flate stream: {e}") from e
        return bytes(out)


def _predict(data: bytes, parms: dict) -> bytes:
    predictor = int(parms.get("Predictor", 1) or 1)
    if predictor == 1:
        return data
    colors = int(parms.get("Colors", 1) or 1)
    bpc = int(parms.get("BitsPerComponent", 8) or 8)
    columns = int(parms.get("Columns", 1) or 1)
    bpp = max(1, (colors * bpc + 7) // 8)
    row_len = (colors * bpc * columns + 7) // 8
    if predictor == 2:
        if bpc != 8:
            return data
        out = bytearray(data)
        for r in range(0, len(out), row_len):
            for i in range(r + bpp, min(r + row_len, len(out))):
                out[i] = (out[i] + out[i - bpp]) & 0xFF
        return bytes(out)
    # PNG predictors (10-15): every row is prefixed with a filter-type byte.
    out = bytearray()
    prev = bytearray(row_len)
    stride = row_len + 1
    for r in range(0, len(data) - row_len, stride) if len(data) >= stride else []:
        ftype = data[r]
        row = bytearray(data[r + 1 : r + 1 + row_len])
        if ftype == 1:
            for i in range(bpp, row_len):
                row[i] = (row[i] + row[i - bpp]) & 0xFF
        elif ftype == 2:
            for i in range(row_len):
                row[i] = (row[i] + prev[i]) & 0xFF
        elif ftype == 3:
            for i in range(row_len):
                left = row[i - bpp] if i >= bpp else 0
                row[i] = (row[i] + ((left + prev[i]) >> 1)) & 0xFF
        elif ftype == 4:
            for i in range(row_len):
                a = row[i - bpp] if i >= bpp else 0
                b = prev[i]
                c = prev[i - bpp] if i >= bpp else 0
                pa, pb, pc = abs(b - c), abs(a - c), abs(a + b - 2 * c)
                pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
                row[i] = (row[i] + pr) & 0xFF
        out += row
        prev = row
    return bytes(out)


def ascii_hex_decode(data: bytes) -> bytes:
    end = data.find(b">")
    if end >= 0:
        data = data[:end]
    digits = bytes(b for b in data if b not in b" \t\r\n\x0c\x00")
    if len(digits) % 2:
        digits += b"0"
    return bytes.fromhex(digits.decode("latin-1"))


def ascii85_decode(data: bytes) -> bytes:
    data = bytes(b for b in data if b not in b" \t\r\n\x0c\x00")
    if data.startswith(b"<~"):
        data = data[2:]
    end = data.find(b"~>")
    if end >= 0:
        data = data[:end]
    out = bytearray()
    group: list[int] = []
    for b in data:
        if b == 0x7A and not group:  # 'z' = four zero bytes
            out += b"\0\0\0\0"
            continue
        if not (33 <= b <= 117):
            continue
        group.append(b - 33)
        if len(group) == 5:
            v = 0
            for g in group:
                v = v * 85 + g
            out += (v & 0xFFFFFFFF).to_bytes(4, "big")
            group = []
    if group:
        n = len(group)
        group += [84] * (5 - n)
        v = 0
        for g in group:
            v = v * 85 + g
        out += (v & 0xFFFFFFFF).to_bytes(4, "big")[: n - 1]
    return bytes(out)


def run_length_decode(data: bytes) -> bytes:
    out = bytearray()
    i = 0
    n = len(data)
    while i < n:
        length = data[i]
        if length == 128:
            break
        if length < 128:
            out += data[i + 1 : i + 2 + length]
            i += 2 + length
        else:
            if i + 1 < n:
                out += bytes([data[i + 1]]) * (257 - length)
            i += 2
    return bytes(out)


def lzw_decode(data: bytes, early_change: int = 1) -> bytes:
    early = 1 if early_change in (None, 1, True) else 0
    out = bytearray()
    table = [bytes([i]) for i in range(256)] + [b"", b""]  # 256 clear, 257 EOD
    code_len = 9
    bitbuf = 0
    bits = 0
    prev: bytes | None = None
    for byte in data:
        bitbuf = (bitbuf << 8) | byte
        bits += 8
        while bits >= code_len:
            bits -= code_len
            code = (bitbuf >> bits) & ((1 << code_len) - 1)
            if code == 256:
                table = table[:258]
                code_len = 9
                prev = None
                continue
            if code == 257:
                return bytes(out)
            if prev is None:
                entry = table[code] if code < len(table) else b""
            elif code < len(table):
                entry = table[code]
                table.append(prev + entry[:1])
            else:
                entry = prev + prev[:1]
                table.append(entry)
            out += entry
            prev = entry
            size = len(table) + early
            code_len = 9 if size < 512 else 10 if size < 1024 else 11 if size < 2048 else 12
    return bytes(out)


def is_name(v: Any, s: str) -> bool:
    return isinstance(v, Name) and str(v) == s
