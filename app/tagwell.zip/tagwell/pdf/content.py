"""Content stream interpreter (ISO 32000-1 §8-9, §14.6 marked content).

Produces positioned text runs, image placements and painted paths, each annotated with
the marked-content context (MCID / Artifact) it was drawn in. Geometry is reported in an
upright display space (points, origin bottom-left of the crop box, y up).
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any

from .fonts import Font, load_font
from .objects import Keyword, Lexer, Name, PDFError, PDFString, Ref, Stream

Matrix = tuple[float, float, float, float, float, float]
IDENTITY: Matrix = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
MAX_OPERATORS = 3_000_000
MAX_FORM_DEPTH = 12


def mul(m1: Matrix, m2: Matrix) -> Matrix:
    """Return m1 x m2 (apply m1 first, then m2), PDF row-vector convention."""
    a1, b1, c1, d1, e1, f1 = m1
    a2, b2, c2, d2, e2, f2 = m2
    return (
        a1 * a2 + b1 * c2,
        a1 * b2 + b1 * d2,
        c1 * a2 + d1 * c2,
        c1 * b2 + d1 * d2,
        e1 * a2 + f1 * c2 + e2,
        e1 * b2 + f1 * d2 + f2,
    )


def apply(m: Matrix, x: float, y: float) -> tuple[float, float]:
    a, b, c, d, e, f = m
    return (a * x + c * y + e, b * x + d * y + f)


BBox = tuple[float, float, float, float]


def union(a: BBox | None, b: BBox | None) -> BBox | None:
    if a is None:
        return b
    if b is None:
        return a
    return (min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))


@dataclass
class Mark:
    tag: str
    mcid: int | None
    props: dict


@dataclass
class TextRun:
    page: int
    text: str
    bbox: BBox
    size: float
    bold: bool
    font: str
    mcid: int | None
    stm: int | None
    artifact: bool
    artifact_kind: str | None
    invisible: bool
    seq: int
    fill_lum: float = 0.0
    rotated: bool = False  # baseline not horizontal on the displayed page (rotated tables, spine text)


@dataclass
class ImageDraw:
    page: int
    bbox: BBox
    mcid: int | None
    stm: int | None
    artifact: bool
    seq: int
    inline: bool = False
    xobj: int | None = None  # object number of the image XObject (same number = same picture)


def _picture_id(xo: "Stream") -> int:
    """Identity of an image's pixels, so a picture embedded several times (InDesign does this for a
    repeated signature or logo) is recognised as the same picture."""
    d = xo.dict
    return hash((str(d.get("Width")), str(d.get("Height")), len(xo.raw), bytes(xo.raw[:4096])))


@dataclass
class PathDraw:
    page: int
    bbox: BBox
    mcid: int | None
    stm: int | None
    artifact: bool
    seq: int
    stroke: bool
    fill: bool
    fill_lum: float


@dataclass
class PageContent:
    page: int
    width: float
    height: float
    texts: list[TextRun] = field(default_factory=list)
    images: list[ImageDraw] = field(default_factory=list)
    paths: list[PathDraw] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    operator_count: int = 0
    # Every (stm, MCID) whose marked-content sequence appears in the stream, even if it draws nothing
    # (producers such as Antenna House wrap clipping paths in their own MCID).
    mcids_seen: set = field(default_factory=set)


@dataclass
class _GState:
    ctm: Matrix = IDENTITY
    tc: float = 0.0
    tw: float = 0.0
    th: float = 1.0
    tl: float = 0.0
    font: Font | None = None
    fs: float = 0.0
    rise: float = 0.0
    tr: int = 0
    fill_lum: float = 0.0

    def copy(self) -> "_GState":
        return _GState(self.ctm, self.tc, self.tw, self.th, self.tl, self.font, self.fs,
                       self.rise, self.tr, self.fill_lum)


def _lum_gray(v: float) -> float:
    return max(0.0, min(1.0, v))


def _lum_rgb(r: float, g: float, b: float) -> float:
    return max(0.0, min(1.0, 0.2126 * r + 0.7152 * g + 0.0722 * b))


def _lum_cmyk(c: float, m: float, y: float, k: float) -> float:
    return _lum_rgb((1 - c) * (1 - k), (1 - m) * (1 - k), (1 - y) * (1 - k))


_EI_RE = re.compile(rb"[\x00\t\n\x0c\r ]EI(?=[\x00\t\n\x0c\r ]|$)")


class Interpreter:
    def __init__(self, doc: Any, page: Any):
        self.doc = doc
        self.page = page
        self.out = PageContent(page.index, page.width, page.height)
        self.font_cache: dict = {}
        self.seq = 0
        self.marks: list[Mark] = []
        self.stm: int | None = None
        self.form_stack: list[int] = []

    # -- public ------------------------------------------------------------
    def run(self) -> PageContent:
        data = b""
        for s in self.page.contents:
            try:
                data += s.decode() + b"\n"
            except PDFError as e:
                self.out.warnings.append(f"page {self.page.index + 1}: content stream unreadable ({e})")
        self._interpret(data, self.page.resources, _GState())
        return self.out

    # -- helpers -----------------------------------------------------------
    def _ctx(self) -> tuple[int | None, bool, str | None]:
        mcid = None
        artifact = False
        kind = None
        for m in self.marks:
            if m.tag == "Artifact":
                artifact = True
                t = m.props.get("Subtype") or m.props.get("Type")
                if t is not None:
                    kind = str(t)
            if m.mcid is not None:
                mcid = m.mcid
        return mcid, artifact, kind

    def _display_bbox(self, pts: list[tuple[float, float]]) -> BBox:
        dp = [self.page.to_display(x, y) for x, y in pts]
        xs = [p[0] for p in dp]
        ys = [p[1] for p in dp]
        return (min(xs), min(ys), max(xs), max(ys))

    def _props(self, operand: Any, resources: dict) -> dict:
        r = self.doc.resolve
        if isinstance(operand, dict):
            return {k: r(v) for k, v in operand.items()}
        if isinstance(operand, Name):
            props = r(resources.get("Properties")) if isinstance(resources, dict) else None
            if isinstance(props, dict):
                p = r(props.get(str(operand)))
                if isinstance(p, dict):
                    return {k: r(v) for k, v in p.items()}
        return {}

    # -- interpreter loop ----------------------------------------------------
    def _interpret(self, data: bytes, resources: dict, gs: _GState) -> None:
        r = self.doc.resolve
        lx = Lexer(data)
        operands: list[Any] = []
        stack: list[_GState] = []
        tm: Matrix = IDENTITY
        tlm: Matrix = IDENTITY
        path_pts: list[tuple[float, float]] = []
        cur: tuple[float, float] = (0.0, 0.0)
        mark_depth_at_entry = len(self.marks)
        while True:
            if self.out.operator_count > MAX_OPERATORS:
                self.out.warnings.append(f"page {self.page.index + 1}: operator limit reached; analysis truncated")
                break
            try:
                tok = lx.parse_object()
            except (IndexError, ValueError):
                break
            if tok is None:
                if lx.at_end():
                    break
                operands.append(None)
                continue
            if not isinstance(tok, Keyword) or isinstance(tok, Name):
                operands.append(tok)
                continue
            op = str(tok)
            self.out.operator_count += 1
            ops = operands
            operands = []
            try:
                if op == "BI":
                    self._inline_image(lx, gs)
                    continue
                if op in ("Tj", "'", '"', "TJ"):
                    if op == "'":
                        tlm = mul((1, 0, 0, 1, 0, -gs.tl), tlm)
                        tm = tlm
                    elif op == '"':
                        if len(ops) >= 3:
                            gs.tw, gs.tc = float(ops[0]), float(ops[1])
                        tlm = mul((1, 0, 0, 1, 0, -gs.tl), tlm)
                        tm = tlm
                    arg = ops[-1] if ops else None
                    items = arg if op == "TJ" and isinstance(arg, list) else [arg]
                    tm = self._show(items, gs, tm)
                elif op == "Td" and len(ops) >= 2:
                    tlm = mul((1, 0, 0, 1, float(ops[0]), float(ops[1])), tlm)
                    tm = tlm
                elif op == "TD" and len(ops) >= 2:
                    gs.tl = -float(ops[1])
                    tlm = mul((1, 0, 0, 1, float(ops[0]), float(ops[1])), tlm)
                    tm = tlm
                elif op == "Tm" and len(ops) >= 6:
                    tlm = tuple(float(x) for x in ops[:6])  # type: ignore[assignment]
                    tm = tlm
                elif op == "T*":
                    tlm = mul((1, 0, 0, 1, 0, -gs.tl), tlm)
                    tm = tlm
                elif op == "BT":
                    tm = tlm = IDENTITY
                elif op == "ET":
                    pass
                elif op == "Tf" and len(ops) >= 2:
                    gs.font = load_font(self.doc, resources, str(ops[0]), self.font_cache)
                    gs.fs = float(ops[1])
                elif op == "Tc" and ops:
                    gs.tc = float(ops[0])
                elif op == "Tw" and ops:
                    gs.tw = float(ops[0])
                elif op == "Tz" and ops:
                    gs.th = float(ops[0]) / 100.0
                elif op == "TL" and ops:
                    gs.tl = float(ops[0])
                elif op == "Ts" and ops:
                    gs.rise = float(ops[0])
                elif op == "Tr" and ops:
                    gs.tr = int(ops[0])
                elif op == "q":
                    stack.append(gs.copy())
                elif op == "Q":
                    if stack:
                        gs = stack.pop()
                elif op == "cm" and len(ops) >= 6:
                    gs.ctm = mul(tuple(float(x) for x in ops[:6]), gs.ctm)  # type: ignore[arg-type]
                elif op in ("BMC", "BDC"):
                    tag = str(ops[0]) if ops else ""
                    props = self._props(ops[1], resources) if op == "BDC" and len(ops) > 1 else {}
                    mcid = props.get("MCID")
                    self.marks.append(Mark(tag, mcid if isinstance(mcid, int) else None, props))
                    if isinstance(mcid, int):
                        self.out.mcids_seen.add((self.stm, mcid))
                elif op == "EMC":
                    if len(self.marks) > mark_depth_at_entry:
                        self.marks.pop()
                elif op == "Do" and ops:
                    self._do(str(ops[0]), resources, gs)
                elif op in ("g",) and ops:
                    gs.fill_lum = _lum_gray(float(ops[0]))
                elif op == "rg" and len(ops) >= 3:
                    gs.fill_lum = _lum_rgb(float(ops[0]), float(ops[1]), float(ops[2]))
                elif op == "k" and len(ops) >= 4:
                    gs.fill_lum = _lum_cmyk(*(float(x) for x in ops[:4]))
                elif op in ("sc", "scn"):
                    nums = [float(x) for x in ops if isinstance(x, (int, float)) and not isinstance(x, bool)]
                    if len(nums) == 1:
                        gs.fill_lum = _lum_gray(nums[0])
                    elif len(nums) == 3:
                        gs.fill_lum = _lum_rgb(*nums)
                    elif len(nums) == 4:
                        gs.fill_lum = _lum_cmyk(*nums)
                elif op == "m" and len(ops) >= 2:
                    cur = apply(gs.ctm, float(ops[0]), float(ops[1]))
                    path_pts.append(cur)
                elif op == "l" and len(ops) >= 2:
                    cur = apply(gs.ctm, float(ops[0]), float(ops[1]))
                    path_pts.append(cur)
                elif op in ("c", "v", "y") and len(ops) >= 4:
                    vals = [float(x) for x in ops]
                    for i in range(0, len(vals) - 1, 2):
                        path_pts.append(apply(gs.ctm, vals[i], vals[i + 1]))
                    cur = path_pts[-1]
                elif op == "re" and len(ops) >= 4:
                    x, y, w, h = (float(v) for v in ops[:4])
                    for px, py in ((x, y), (x + w, y), (x + w, y + h), (x, y + h)):
                        path_pts.append(apply(gs.ctm, px, py))
                elif op in ("S", "s", "f", "F", "f*", "B", "B*", "b", "b*"):
                    if path_pts:
                        mcid, art, _ = self._ctx()
                        stroke = op in ("S", "s", "B", "B*", "b", "b*")
                        fill = op not in ("S", "s")
                        self.seq += 1
                        self.out.paths.append(PathDraw(self.page.index, self._display_bbox(path_pts), mcid,
                                                       self.stm, art, self.seq, stroke, fill, gs.fill_lum))
                    path_pts = []
                elif op == "n":
                    path_pts = []
                # All other operators (colour spaces, line styles, clipping, shading, ...)
                # do not affect geometry we need.
            except (TypeError, ValueError, IndexError, ZeroDivisionError):
                continue
        # Unbalanced BDC inside a form must not leak to the caller.
        del self.marks[mark_depth_at_entry:]

    # -- text ----------------------------------------------------------------
    def _show(self, items: list[Any], gs: _GState, tm: Matrix) -> Matrix:
        font = gs.font
        if font is None:
            font = Font(self.doc, None, "default")
            gs.font = font
        fs = gs.fs
        chars: list[str] = []
        bbox: BBox | None = None
        start_tm = tm
        for item in items:
            if isinstance(item, (int, float)) and not isinstance(item, bool):
                adj = -float(item) / 1000.0 * fs * gs.th
                if float(item) < -200 and chars and not chars[-1].isspace():
                    chars.append(" ")
                tm = mul((1, 0, 0, 1, adj, 0), tm)
                continue
            if not isinstance(item, (bytes, PDFString)):
                continue
            for code, u, w0, is_space in font.decode(bytes(item)):
                trm = mul((fs * gs.th, 0, 0, fs, 0, gs.rise), mul(tm, gs.ctm))
                if not is_space and u.strip():
                    corners = [apply(trm, 0, -0.2), apply(trm, w0, -0.2), apply(trm, w0, 0.8), apply(trm, 0, 0.8)]
                    bbox = union(bbox, self._display_bbox(corners))
                chars.append(u)
                tx = (w0 * fs + gs.tc + (gs.tw if is_space else 0.0)) * gs.th
                tm = mul((1, 0, 0, 1, tx, 0), tm)
        text = "".join(chars)
        if bbox is not None and text.strip():
            m = mul(start_tm, gs.ctm)
            size = abs(fs) * math.hypot(m[2], m[3])
            mcid, art, kind = self._ctx()
            self.seq += 1
            p0 = self.page.to_display(*apply(m, 0, 0))
            p1 = self.page.to_display(*apply(m, 1, 0))
            rotated = abs(p1[1] - p0[1]) > 0.3 * abs(p1[0] - p0[0])
            self.out.texts.append(TextRun(self.page.index, text, bbox, round(size, 2), font.bold or gs.tr == 2,
                                          font.base_font, mcid, self.stm, art, kind, gs.tr in (3, 7),
                                          self.seq, gs.fill_lum, rotated))
        return tm

    # -- XObjects ------------------------------------------------------------
    def _do(self, name: str, resources: dict, gs: _GState) -> None:
        r = self.doc.resolve
        xobjs = r(resources.get("XObject")) if isinstance(resources, dict) else None
        ref = xobjs.get(name) if isinstance(xobjs, dict) else None
        xo = r(ref)
        if not isinstance(xo, Stream):
            return
        sub = xo.dict.get("Subtype")
        if sub == "Image":
            pts = [apply(gs.ctm, x, y) for x, y in ((0, 0), (1, 0), (1, 1), (0, 1))]
            mcid, art, _ = self._ctx()
            self.seq += 1
            self.out.images.append(ImageDraw(self.page.index, self._display_bbox(pts), mcid, self.stm, art, self.seq,
                                             False, _picture_id(xo)))
        elif sub == "Form":
            num = getattr(ref, "num", None)
            if len(self.form_stack) >= MAX_FORM_DEPTH or (num is not None and num in self.form_stack):
                return
            self.form_stack.append(num if num is not None else -1)
            fgs = gs.copy()
            mat = r(xo.dict.get("Matrix"))
            if isinstance(mat, list) and len(mat) == 6:
                try:
                    fgs.ctm = mul(tuple(float(r(x)) for x in mat), gs.ctm)  # type: ignore[arg-type]
                except (TypeError, ValueError):
                    pass
            fres = r(xo.dict.get("Resources"))
            saved_stm = self.stm
            # MCIDs inside a form XObject belong to that stream (referenced via MCR /Stm).
            if xo.dict.get("StructParents") is not None or xo.dict.get("StructParent") is not None:
                self.stm = num
            try:
                self._interpret(xo.decode(), fres if isinstance(fres, dict) else resources, fgs)
            except PDFError as e:
                self.out.warnings.append(f"page {self.page.index + 1}: form XObject unreadable ({e})")
            self.stm = saved_stm
            self.form_stack.pop()

    def _inline_image(self, lx: Lexer, gs: _GState) -> None:
        # Skip the parameter dictionary up to ID, then the binary data up to EI.
        while True:
            tok = lx.next_token()
            if tok is None:
                return
            if isinstance(tok, Keyword) and tok == "ID":
                break
        start = lx.pos + 1
        m = _EI_RE.search(lx.data, start)
        lx.pos = m.end() if m else len(lx.data)
        pts = [apply(gs.ctm, x, y) for x, y in ((0, 0), (1, 0), (1, 1), (0, 1))]
        mcid, art, _ = self._ctx()
        self.seq += 1
        self.out.images.append(ImageDraw(self.page.index, self._display_bbox(pts), mcid, self.stm, art, self.seq, True))


def interpret_page(doc: Any, page: Any) -> PageContent:
    return Interpreter(doc, page).run()
