"""Minimal, dependency-free PDF reader focused on structure and geometry."""
