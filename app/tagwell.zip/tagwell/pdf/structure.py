"""Logical structure tree (ISO 32000-1 §14.7-14.8)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Iterator, Union

from .objects import Name, PDFString, Ref, Stream, text_of

STANDARD_TYPES = {
    # PDF 1.7 standard structure types
    "Document", "Part", "Art", "Sect", "Div", "BlockQuote", "Caption", "TOC", "TOCI", "Index",
    "NonStruct", "Private", "P", "H", "H1", "H2", "H3", "H4", "H5", "H6", "L", "LI", "Lbl",
    "LBody", "Table", "TR", "TH", "TD", "THead", "TBody", "TFoot", "Span", "Quote", "Note",
    "Reference", "BibEntry", "Code", "Link", "Annot", "Ruby", "RB", "RT", "RP", "Warichu",
    "WT", "WP", "Figure", "Formula", "Form",
    # PDF 2.0 additions
    "DocumentFragment", "Aside", "Title", "FENote", "Sub", "Em", "Strong", "Artifact",
}
HEADING_TYPES = {"H", "H1", "H2", "H3", "H4", "H5", "H6"}
GROUPING_TYPES = {"Document", "DocumentFragment", "Part", "Art", "Sect", "Div", "NonStruct",
                  "Private", "BlockQuote", "TOC", "Index", "Aside", "Title"}
BLOCK_TYPES = {"P", "H", "H1", "H2", "H3", "H4", "H5", "H6", "Caption", "LI", "Lbl", "LBody",
               "TH", "TD", "Note", "Code", "BibEntry", "Figure", "Formula", "Form", "TOCI",
               "Quote", "FENote"}


@dataclass(frozen=True)
class MCRef:
    page: int | None
    mcid: int
    stm: int | None = None


@dataclass(frozen=True)
class ObjRef:
    page: int | None
    obj: Any


@dataclass(eq=False)
class Node:
    type: str
    raw_type: str
    parent: "Node | None" = None
    page: int | None = None
    alt: str | None = None
    actual_text: str | None = None
    lang: str | None = None
    title: str | None = None
    elem_id: str | None = None
    attrs: dict = field(default_factory=dict)
    children: list["Child"] = field(default_factory=list)
    index: int = 0  # document order (pre-order)

    def walk(self) -> Iterator["Node"]:
        stack: list[Node] = [self]
        while stack:
            n = stack.pop()
            yield n
            kids = [c for c in n.children if isinstance(c, Node)]
            stack.extend(reversed(kids))

    def node_children(self) -> list["Node"]:
        return [c for c in self.children if isinstance(c, Node)]

    def mcrefs(self) -> list[MCRef]:
        """All marked-content references under this node, in logical order."""
        out: list[MCRef] = []
        stack: list[Child] = [self]
        while stack:
            c = stack.pop()
            if isinstance(c, MCRef):
                out.append(c)
            elif isinstance(c, Node):
                stack.extend(reversed(c.children))
        return out

    def ancestors(self) -> Iterator["Node"]:
        p = self.parent
        while p is not None:
            yield p
            p = p.parent

    def has_ancestor(self, types: set[str]) -> bool:
        return any(a.type in types for a in self.ancestors())

    def effective_lang(self) -> str | None:
        if self.lang:
            return self.lang
        for a in self.ancestors():
            if a.lang:
                return a.lang
        return None


Child = Union[Node, MCRef, ObjRef]


@dataclass
class StructTree:
    root: Node | None
    role_map: dict[str, str]
    nodes: list[Node]
    unknown_types: set[str]
    warnings: list[str]

    def by_type(self, *types: str) -> list[Node]:
        ts = set(types)
        return [n for n in self.nodes if n.type in ts]


def _resolve_role(raw: str, role_map: dict[str, str]) -> str:
    seen = set()
    t = raw
    while t not in STANDARD_TYPES and t in role_map and t not in seen:
        seen.add(t)
        t = role_map[t]
    return t


def _attrs(doc: Any, elem: dict, class_map: dict) -> dict:
    r = doc.resolve
    out: dict = {}

    def merge(a: Any) -> None:
        a = r(a)
        if isinstance(a, Stream):
            a = a.dict
        if isinstance(a, dict):
            for k, v in a.items():
                if k != "O":
                    out[k] = r(v)

    classes = r(elem.get("C"))
    for c in classes if isinstance(classes, list) else [classes]:
        c = r(c)
        if isinstance(c, Name) and isinstance(class_map, dict):
            cm = r(class_map.get(str(c)))
            for item in cm if isinstance(cm, list) else [cm]:
                merge(item)
    a = r(elem.get("A"))
    for item in a if isinstance(a, list) else [a]:
        if isinstance(item, int):
            continue  # revision number
        merge(item)
    return out


def build_struct_tree(doc: Any) -> StructTree:
    r = doc.resolve
    root_d = r(doc.catalog.get("StructTreeRoot"))
    if not isinstance(root_d, dict):
        return StructTree(None, {}, [], set(), [])
    rm = r(root_d.get("RoleMap"))
    role_map = {k: str(r(v)) for k, v in rm.items()} if isinstance(rm, dict) else {}
    class_map = r(root_d.get("ClassMap"))
    class_map = class_map if isinstance(class_map, dict) else {}
    root = Node("StructTreeRoot", "StructTreeRoot")
    nodes: list[Node] = []
    unknown: set[str] = set()
    warnings: list[str] = []
    visited: set[int] = set()
    counter = 0

    # Depth-first, children pushed in reverse so each parent's children end up in logical order.
    raw_k = root_d.get("K")
    kids = r(raw_k)
    items0 = kids if isinstance(kids, list) else ([raw_k] if raw_k is not None else [])
    stack: list[tuple[Any, Node, int | None]] = [(k, root, None) for k in reversed(items0)]

    while stack:
        kid, parent, inh_page = stack.pop()
        if isinstance(kid, Ref):
            if kid.num in visited:
                warnings.append(f"structure cycle at object {kid.num}")
                continue
            visited.add(kid.num)
        k = r(kid)
        if isinstance(k, bool):
            continue
        if isinstance(k, int):
            parent.children.append(MCRef(inh_page, k))
            continue
        if not isinstance(k, dict):
            continue
        ktype = k.get("Type")
        if ktype == "MCR":
            mcid = r(k.get("MCID"))
            pg = doc.page_index_of(k.get("Pg")) if k.get("Pg") is not None else inh_page
            stm = k.get("Stm")
            if isinstance(mcid, int):
                parent.children.append(MCRef(pg, mcid, stm.num if isinstance(stm, Ref) else None))
            continue
        if ktype == "OBJR":
            pg = doc.page_index_of(k.get("Pg")) if k.get("Pg") is not None else inh_page
            parent.children.append(ObjRef(pg, k.get("Obj")))
            continue
        s = r(k.get("S"))
        if s is None:
            continue
        raw = str(s)
        std = _resolve_role(raw, role_map)
        if std not in STANDARD_TYPES:
            unknown.add(raw)
        pg = doc.page_index_of(k.get("Pg")) if k.get("Pg") is not None else inh_page
        node = Node(
            type=std,
            raw_type=raw,
            parent=parent,
            page=pg,
            alt=text_of(r(k.get("Alt"))),
            actual_text=text_of(r(k.get("ActualText"))),
            lang=text_of(r(k.get("Lang"))),
            title=text_of(r(k.get("T"))),
            elem_id=_id_text(r(k.get("ID"))),
            attrs=_attrs(doc, k, class_map),
        )
        counter += 1
        node.index = counter
        parent.children.append(node)
        nodes.append(node)
        sub = k.get("K")
        subr = r(sub)
        items = subr if isinstance(subr, list) else ([sub] if sub is not None else [])
        for item in reversed(items):
            stack.append((item, node, pg))
    for i, n in enumerate(root.walk()):
        n.index = i
    nodes = [n for n in root.walk() if n is not root]
    return StructTree(root, role_map, nodes, unknown, warnings)


def _id_text(v: Any) -> str | None:
    if isinstance(v, PDFString):
        return bytes(v).decode("latin-1")
    if isinstance(v, str):
        return str(v)
    return None
