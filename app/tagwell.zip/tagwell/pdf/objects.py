"""PDF object model and a tolerant parser for PDF object syntax (ISO 32000-1 §7.3)."""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any


class PDFError(Exception):
    """Raised when a file cannot be parsed as PDF."""


class Name(str):
    """A PDF name object (/Type). Stored without the leading slash."""

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return "/" + str(self)


class PDFString(bytes):
    """A PDF string object (literal or hex). Raw bytes; use decode_text() for text."""

    def decode_text(self) -> str:
        """Decode a PDF text string (UTF-16BE with BOM, UTF-8 with BOM, or PDFDocEncoding)."""
        data = bytes(self)
        if data.startswith(b"\xfe\xff"):
            return data[2:].decode("utf-16-be", "replace")
        if data.startswith(b"\xff\xfe"):
            return data[2:].decode("utf-16-le", "replace")
        if data.startswith(b"\xef\xbb\xbf"):
            return data[3:].decode("utf-8", "replace")
        return "".join(PDFDOC_TO_UNICODE.get(b, chr(b)) for b in data)


@dataclass(frozen=True)
class Ref:
    num: int
    gen: int = 0


class Stream:
    """A stream object: its dictionary plus raw (still-encoded) data."""

    __slots__ = ("dict", "raw", "ref", "_decoded", "_doc", "_pre")

    def __init__(self, d: dict, raw: bytes, ref: Ref | None = None, doc: Any = None):
        self.dict = d
        self.raw = raw
        self.ref = ref
        self._decoded: bytes | None = None
        self._doc = doc
        self._pre = None  # optional transform applied to raw before filters (decryption)

    def get(self, key: str, default: Any = None) -> Any:
        return self.dict.get(key, default)

    def decode(self) -> bytes:
        if self._decoded is None:
            from .filters import decode_stream

            if self._pre is not None:
                self.raw = self._pre(self.raw)
                self._pre = None
            self._decoded = decode_stream(self, self._doc)
        return self._decoded


class Keyword(str):
    """A bare token such as obj, endobj, R, stream, true, or an operator in content streams."""


# PDFDocEncoding differs from Latin-1 in 0x18-0x1F and 0x80-0x9F (ISO 32000-1 Annex D).
PDFDOC_TO_UNICODE = {
    0x18: "˘", 0x19: "ˇ", 0x1A: "ˆ", 0x1B: "˙", 0x1C: "˝",
    0x1D: "˛", 0x1E: "˚", 0x1F: "˜", 0x80: "•", 0x81: "†",
    0x82: "‡", 0x83: "…", 0x84: "—", 0x85: "–", 0x86: "ƒ",
    0x87: "⁄", 0x88: "‹", 0x89: "›", 0x8A: "−", 0x8B: "‰",
    0x8C: "„", 0x8D: "“", 0x8E: "”", 0x8F: "‘", 0x90: "’",
    0x91: "‚", 0x92: "™", 0x93: "ﬁ", 0x94: "ﬂ", 0x95: "Ł",
    0x96: "Œ", 0x97: "Š", 0x98: "Ÿ", 0x99: "Ž", 0x9A: "ı",
    0x9B: "ł", 0x9C: "œ", 0x9D: "š", 0x9E: "ž", 0xA0: "€",
}

WHITESPACE = b"\x00\t\n\x0c\r "
DELIMITERS = b"()<>[]{}/%"
_WS_SET = frozenset(WHITESPACE)
_DELIM_SET = frozenset(DELIMITERS)
_NUMBER_RE = re.compile(rb"[+-]?(?:\d+\.?\d*|\.\d+)")


class Lexer:
    """Tokenizer + recursive object parser over a bytes buffer.

    Tolerant by design: real-world PDFs are often slightly malformed, and a checker
    that crashes on them is useless to the customer.
    """

    def __init__(self, data: bytes, pos: int = 0):
        self.data = data
        self.pos = pos
        self.n = len(data)

    # -- low level -------------------------------------------------------
    def skip_ws(self) -> None:
        data, n = self.data, self.n
        pos = self.pos
        while pos < n:
            c = data[pos]
            if c in _WS_SET:
                pos += 1
            elif c == 0x25:  # % comment to end of line
                while pos < n and data[pos] not in (0x0A, 0x0D):
                    pos += 1
            else:
                break
        self.pos = pos

    def at_end(self) -> bool:
        self.skip_ws()
        return self.pos >= self.n

    def _regular_run(self) -> bytes:
        start = self.pos
        data, n = self.data, self.n
        pos = start
        while pos < n and data[pos] not in _WS_SET and data[pos] not in _DELIM_SET:
            pos += 1
        self.pos = pos
        return data[start:pos]

    def next_token(self) -> Any:
        """Return the next token as a Python value or a Keyword/delimiter marker."""
        self.skip_ws()
        if self.pos >= self.n:
            return None
        c = self.data[self.pos]
        if c == 0x2F:  # /
            self.pos += 1
            raw = self._regular_run()
            return Name(_decode_name(raw))
        if c == 0x28:  # (
            return self._literal_string()
        if c == 0x3C:  # <
            if self.data[self.pos + 1 : self.pos + 2] == b"<":
                self.pos += 2
                return Keyword("<<")
            return self._hex_string()
        if c == 0x3E:  # >
            if self.data[self.pos + 1 : self.pos + 2] == b">":
                self.pos += 2
                return Keyword(">>")
            self.pos += 1
            return Keyword(">")
        if c in (0x5B, 0x5D, 0x7B, 0x7D):  # [ ] { }
            self.pos += 1
            return Keyword(chr(c))
        if c == 0x29:  # stray )
            self.pos += 1
            return Keyword(")")
        raw = self._regular_run()
        if not raw:  # unexpected byte; skip it
            self.pos += 1
            return Keyword(chr(c))
        if _NUMBER_RE.fullmatch(raw):
            if b"." in raw:
                try:
                    return float(raw)
                except ValueError:
                    return 0.0
            return int(raw)
        if raw == b"true":
            return True
        if raw == b"false":
            return False
        if raw == b"null":
            return _NULL
        return Keyword(raw.decode("latin-1"))

    def _literal_string(self) -> PDFString:
        data, n = self.data, self.n
        pos = self.pos + 1
        depth = 1
        out = bytearray()
        while pos < n:
            c = data[pos]
            if c == 0x5C:  # backslash
                pos += 1
                if pos >= n:
                    break
                e = data[pos]
                if e in b"nrtbf":
                    out.append({0x6E: 10, 0x72: 13, 0x74: 9, 0x62: 8, 0x66: 12}[e])
                    pos += 1
                elif e in b"()\\":
                    out.append(e)
                    pos += 1
                elif 0x30 <= e <= 0x37:
                    j = pos
                    while j < n and j < pos + 3 and 0x30 <= data[j] <= 0x37:
                        j += 1
                    out.append(int(data[pos:j], 8) & 0xFF)
                    pos = j
                elif e == 0x0D:  # line continuation
                    pos += 1
                    if pos < n and data[pos] == 0x0A:
                        pos += 1
                elif e == 0x0A:
                    pos += 1
                else:
                    out.append(e)
                    pos += 1
                continue
            if c == 0x28:
                depth += 1
            elif c == 0x29:
                depth -= 1
                if depth == 0:
                    pos += 1
                    break
            out.append(c)
            pos += 1
        self.pos = pos
        return PDFString(bytes(out))

    def _hex_string(self) -> PDFString:
        end = self.data.find(b">", self.pos)
        if end < 0:
            end = self.n
        hexdigits = bytes(b for b in self.data[self.pos + 1 : end] if b not in _WS_SET)
        self.pos = end + 1
        if len(hexdigits) % 2:
            hexdigits += b"0"
        try:
            return PDFString(bytes.fromhex(hexdigits.decode("latin-1")))
        except ValueError:
            return PDFString(b"")

    # -- objects ---------------------------------------------------------
    def parse_object(self) -> Any:
        """Parse one object, resolving `n g R` references into Ref values."""
        return self._finish(self.next_token())

    def _finish(self, tok: Any) -> Any:
        if isinstance(tok, Keyword):
            if tok == "<<":
                return self._dict_body()
            if tok == "[":
                return self._array_body()
            return tok
        if isinstance(tok, int) and not isinstance(tok, bool):
            # Look ahead for "gen R".
            save = self.pos
            t2 = self.next_token()
            if isinstance(t2, int) and not isinstance(t2, bool):
                t3 = self.next_token()
                if isinstance(t3, Keyword) and t3 == "R":
                    return Ref(tok, t2)
            self.pos = save
            return tok
        if tok is _NULL:
            return None
        return tok

    def _dict_body(self) -> dict:
        d: dict = {}
        while True:
            tok = self.next_token()
            if tok is None:
                break
            if isinstance(tok, Keyword) and tok == ">>":
                break
            if isinstance(tok, Name):
                val_tok = self.next_token()
                if isinstance(val_tok, Keyword) and val_tok == ">>":
                    d[str(tok)] = None
                    break
                d[str(tok)] = self._finish(val_tok)
            # Ignore junk keys (malformed dictionaries).
        return d

    def _array_body(self) -> list:
        arr: list = []
        while True:
            tok = self.next_token()
            if tok is None:
                break
            if isinstance(tok, Keyword) and tok == "]":
                break
            arr.append(self._finish(tok))
        return arr


class _Null:
    def __repr__(self) -> str:  # pragma: no cover
        return "null"


_NULL = _Null()


def _decode_name(raw: bytes) -> str:
    if b"#" in raw:
        out = bytearray()
        i = 0
        while i < len(raw):
            if raw[i] == 0x23 and i + 2 < len(raw) + 1:
                try:
                    out.append(int(raw[i + 1 : i + 3], 16))
                    i += 3
                    continue
                except ValueError:
                    pass
            out.append(raw[i])
            i += 1
        raw = bytes(out)
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        return raw.decode("latin-1")


def text_of(value: Any) -> str | None:
    """Best-effort conversion of a PDF value to Python text."""
    if isinstance(value, PDFString):
        return value.decode_text()
    if isinstance(value, str):
        return str(value)
    return None
