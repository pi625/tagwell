"""Font handling sufficient for text extraction and glyph geometry (ISO 32000-1 §9)."""
from __future__ import annotations

import re
import unicodedata
from typing import Any

from .objects import Lexer, Name, PDFString, Stream

# --- encodings -----------------------------------------------------------------

def _single_byte_table(codec: str) -> dict[int, str]:
    table = {}
    for b in range(256):
        try:
            ch = bytes([b]).decode(codec)
        except UnicodeDecodeError:
            continue
        table[b] = ch
    return table


WIN_ANSI = _single_byte_table("cp1252")
MAC_ROMAN = _single_byte_table("mac_roman")
STANDARD = {b: chr(b) for b in range(0x20, 0x7F)}
STANDARD.update({0x27: "’", 0x60: "‘"})
STANDARD.update({
    0xA1: "¡", 0xA2: "¢", 0xA3: "£", 0xA4: "⁄", 0xA5: "¥", 0xA6: "ƒ",
    0xA7: "§", 0xA8: "¤", 0xA9: "'", 0xAA: "“", 0xAB: "«", 0xAC: "‹",
    0xAD: "›", 0xAE: "ﬁ", 0xAF: "ﬂ", 0xB1: "–", 0xB2: "†", 0xB3: "‡",
    0xB4: "·", 0xB6: "¶", 0xB7: "•", 0xB8: "‚", 0xB9: "„", 0xBA: "”",
    0xBB: "»", 0xBC: "…", 0xBD: "‰", 0xBF: "¿", 0xD0: "—",
})
ENCODINGS = {"WinAnsiEncoding": WIN_ANSI, "MacRomanEncoding": MAC_ROMAN, "StandardEncoding": STANDARD}

_GLYPHS = {
    "space": " ", "exclam": "!", "quotedbl": '"', "numbersign": "#", "dollar": "$", "percent": "%",
    "ampersand": "&", "quotesingle": "'", "parenleft": "(", "parenright": ")", "asterisk": "*",
    "plus": "+", "comma": ",", "hyphen": "-", "period": ".", "slash": "/", "colon": ":",
    "semicolon": ";", "less": "<", "equal": "=", "greater": ">", "question": "?", "at": "@",
    "bracketleft": "[", "backslash": "\\", "bracketright": "]", "asciicircum": "^",
    "underscore": "_", "grave": "`", "braceleft": "{", "bar": "|", "braceright": "}",
    "asciitilde": "~", "quoteright": "’", "quoteleft": "‘", "quotedblleft": "“",
    "quotedblright": "”", "quotesinglbase": "‚", "quotedblbase": "„",
    "bullet": "•", "endash": "–", "emdash": "—", "ellipsis": "…",
    "fi": "ﬁ", "fl": "ﬂ", "ff": "ﬀ", "ffi": "ﬃ", "ffl": "ﬄ",
    "trademark": "™", "copyright": "©", "registered": "®", "degree": "°",
    "section": "§", "paragraph": "¶", "dagger": "†", "daggerdbl": "‡",
    "periodcentered": "·", "minus": "−", "multiply": "×", "divide": "÷",
    "plusminus": "±", "nbspace": " ", "uni00A0": " ", "Euro": "€",
    "sterling": "£", "yen": "¥", "cent": "¢", "currency": "¤",
    "guillemotleft": "«", "guillemotright": "»", "guilsinglleft": "‹",
    "guilsinglright": "›", "exclamdown": "¡", "questiondown": "¿",
    "germandbls": "ß", "ae": "æ", "AE": "Æ", "oe": "œ", "OE": "Œ",
    "oslash": "ø", "Oslash": "Ø", "dotlessi": "ı", "lslash": "ł",
    "Lslash": "Ł", "eth": "ð", "Eth": "Ð", "thorn": "þ", "Thorn": "Þ",
    "mu": "µ", "onehalf": "½", "onequarter": "¼", "threequarters": "¾",
    "ordfeminine": "ª", "ordmasculine": "º", "logicalnot": "¬", "brokenbar": "¦",
    "dieresis": "¨", "macron": "¯", "acute": "´", "cedilla": "¸",
    "circumflex": "ˆ", "tilde": "˜", "ring": "˚", "caron": "ˇ",
    "perthousand": "‰", "florin": "ƒ", "fraction": "⁄", "square": "□",
    "checkmark": "✓", "circle": "○", "filledbox": "■", "triagrt": "►",
    "a109": "•", "H18533": "●", "H22073": "□", "uni2022": "•",
}
for _i, _n in enumerate(["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine"]):
    _GLYPHS[_n] = str(_i)

_ACCENTS = {
    "acute": "ACUTE", "grave": "GRAVE", "circumflex": "CIRCUMFLEX", "dieresis": "DIAERESIS",
    "tilde": "TILDE", "ring": "RING ABOVE", "cedilla": "CEDILLA", "caron": "CARON",
    "macron": "MACRON", "breve": "BREVE", "ogonek": "OGONEK", "dotaccent": "DOT ABOVE",
    "hungarumlaut": "DOUBLE ACUTE", "commaaccent": "CEDILLA",
}


def glyph_to_unicode(name: str) -> str | None:
    if name in _GLYPHS:
        return _GLYPHS[name]
    base = name.split(".", 1)[0]
    if base != name and base:
        return glyph_to_unicode(base)
    if "_" in name:
        parts = [glyph_to_unicode(p) for p in name.split("_")]
        if all(parts):
            return "".join(parts)  # type: ignore[arg-type]
    if len(name) == 1 and name.isascii() and name.isalpha():
        return name
    m = re.fullmatch(r"uni((?:[0-9A-Fa-f]{4})+)", name)
    if m:
        hx = m.group(1)
        try:
            return "".join(chr(int(hx[i : i + 4], 16)) for i in range(0, len(hx), 4))
        except ValueError:
            return None
    m = re.fullmatch(r"u([0-9A-Fa-f]{4,6})", name)
    if m:
        try:
            return chr(int(m.group(1), 16))
        except ValueError:
            return None
    if len(name) > 1 and name[0].isascii() and name[0].isalpha():
        letter, rest = name[0], name[1:]
        if rest in _ACCENTS:
            case = "CAPITAL" if letter.isupper() else "SMALL"
            try:
                return unicodedata.lookup(f"LATIN {case} LETTER {letter.upper()} WITH {_ACCENTS[rest]}")
            except KeyError:
                return None
    m = re.fullmatch(r"(?:cid|g|glyph)(\d+)", name)
    if m:
        return None
    return None


# --- CMaps ---------------------------------------------------------------------

class CMap:
    """Parsed ToUnicode or encoding CMap: code space ranges plus code->value mappings."""

    def __init__(self) -> None:
        self.codespace: list[tuple[int, int, int]] = []  # (nbytes, lo, hi)
        self.map: dict[tuple[int, int], Any] = {}  # (nbytes, code) -> str or int (cid)
        self.ranges: list[tuple[int, int, int, Any]] = []  # (nbytes, lo, hi, start_value)

    @classmethod
    def parse(cls, data: bytes, to_unicode: bool = True) -> "CMap":
        cm = cls()
        lx = Lexer(data)
        mode = None
        buf: list[Any] = []
        while True:
            tok = lx.parse_object()
            if tok is None and lx.at_end():
                break
            if isinstance(tok, str) and not isinstance(tok, Name):
                kw = str(tok)
                if kw in ("begincodespacerange", "beginbfchar", "beginbfrange", "begincidchar",
                          "begincidrange"):
                    mode = kw[5:]
                    buf = []
                    continue
                if kw.startswith("end") and mode and kw == "end" + mode:
                    cm._apply(mode, buf, to_unicode)
                    mode = None
                    buf = []
                    continue
            if mode:
                buf.append(tok)
        return cm

    def _apply(self, mode: str, items: list[Any], to_unicode: bool) -> None:
        def code(b: Any) -> tuple[int, int] | None:
            if isinstance(b, (bytes, PDFString)):
                return len(b), int.from_bytes(bytes(b), "big") if b else 0
            return None

        if mode == "codespacerange":
            for i in range(0, len(items) - 1, 2):
                lo, hi = code(items[i]), code(items[i + 1])
                if lo and hi:
                    self.codespace.append((lo[0], lo[1], hi[1]))
        elif mode in ("bfchar", "cidchar"):
            for i in range(0, len(items) - 1, 2):
                src = code(items[i])
                if not src:
                    continue
                self.map[src] = _dst_value(items[i + 1], to_unicode and mode == "bfchar")
        elif mode in ("bfrange", "cidrange"):
            for i in range(0, len(items) - 2, 3):
                lo, hi, dst = code(items[i]), code(items[i + 1]), items[i + 2]
                if not lo or not hi:
                    continue
                if isinstance(dst, list):
                    for k, d in enumerate(dst):
                        self.map[(lo[0], lo[1] + k)] = _dst_value(d, mode == "bfrange")
                else:
                    self.ranges.append((lo[0], lo[1], hi[1], _dst_value(dst, mode == "bfrange")))

    def lookup(self, nbytes: int, c: int) -> Any:
        v = self.map.get((nbytes, c))
        if v is not None:
            return v
        for nb, lo, hi, start in self.ranges:
            if nb == nbytes and lo <= c <= hi:
                off = c - lo
                if isinstance(start, str) and start:
                    return start[:-1] + chr(ord(start[-1]) + off)
                if isinstance(start, int):
                    return start + off
        return None

    def code_lengths(self) -> list[tuple[int, int, int]]:
        return sorted(self.codespace)


def _dst_value(v: Any, as_unicode: bool) -> Any:
    if isinstance(v, (bytes, PDFString)):
        b = bytes(v)
        if as_unicode:
            if len(b) % 2:
                b = b"\0" + b
            return b.decode("utf-16-be", "replace")
        return int.from_bytes(b, "big")
    if isinstance(v, int):
        return v
    if isinstance(v, Name):
        return glyph_to_unicode(str(v))
    return None


# --- fonts -----------------------------------------------------------------

BOLD_NAME_RE = re.compile(r"(bold|black|heavy|semibold|demibold|demi\b|extrabold|ultrabold)", re.I)
_STD14_DEFAULT_WIDTH = {"Courier": 600}


class Font:
    def __init__(self, doc: Any, fdict: dict | None, name: str = ""):
        self.doc = doc
        self.d = fdict or {}
        r = doc.resolve if doc is not None else (lambda x: x)
        self.subtype = str(r(self.d.get("Subtype")) or "Type1")
        base = r(self.d.get("BaseFont"))
        self.base_font = str(base) if base is not None else name
        self.composite = self.subtype == "Type0"
        self.width_scale = 0.001
        self.widths: dict[int, float] = {}
        self.default_width = 500.0
        self.to_unicode: CMap | None = None
        self.encoding: dict[int, str] = {}
        self.enc_cmap: CMap | None = None
        self.code_lengths: list[tuple[int, int, int]] = []
        self.flags = 0
        self.weight = 0
        tu = r(self.d.get("ToUnicode"))
        if isinstance(tu, Stream):
            try:
                self.to_unicode = CMap.parse(tu.decode(), to_unicode=True)
            except Exception:  # noqa: BLE001 - a broken CMap degrades text, not geometry
                self.to_unicode = None
        if self.composite:
            self._init_composite(r)
        else:
            self._init_simple(r)
        bare = self.base_font.split("+", 1)[-1]
        self.bold = bool(BOLD_NAME_RE.search(bare)) or bool(self.flags & (1 << 18)) or self.weight >= 600

    # simple fonts
    def _init_simple(self, r: Any) -> None:
        bare = self.base_font.split("+", 1)[-1]
        fd = r(self.d.get("FontDescriptor"))
        if isinstance(fd, dict):
            self.flags = int(r(fd.get("Flags")) or 0)
            self.weight = int(r(fd.get("FontWeight")) or 0)
            mw = r(fd.get("MissingWidth"))
            if isinstance(mw, (int, float)) and mw > 0:
                self.default_width = float(mw)
        for k, v in _STD14_DEFAULT_WIDTH.items():
            if bare.startswith(k):
                self.default_width = float(v)
        if self.subtype == "Type3":
            fm = r(self.d.get("FontMatrix"))
            if isinstance(fm, list) and fm:
                try:
                    self.width_scale = float(r(fm[0]))
                except (TypeError, ValueError):
                    pass
        first = r(self.d.get("FirstChar"))
        widths = r(self.d.get("Widths"))
        if isinstance(first, int) and isinstance(widths, list):
            for i, w in enumerate(widths):
                w = r(w)
                if isinstance(w, (int, float)):
                    self.widths[first + i] = float(w)
        enc = r(self.d.get("Encoding"))
        is_symbolic = bool(self.flags & 4) and not bool(self.flags & 32)
        table = dict(STANDARD if not is_symbolic else {})
        if not table:
            table = {b: chr(b) for b in range(0x20, 0x7F)}
        if isinstance(enc, Name) and str(enc) in ENCODINGS:
            table = dict(ENCODINGS[str(enc)])
        elif isinstance(enc, dict):
            be = r(enc.get("BaseEncoding"))
            if isinstance(be, Name) and str(be) in ENCODINGS:
                table = dict(ENCODINGS[str(be)])
            diffs = r(enc.get("Differences"))
            if isinstance(diffs, list):
                code = 0
                for item in diffs:
                    item = r(item)
                    if isinstance(item, int):
                        code = item
                    elif isinstance(item, Name):
                        u = glyph_to_unicode(str(item))
                        if u is not None:
                            table[code] = u
                        code += 1
        elif self.subtype == "TrueType" and enc is None:
            table = dict(WIN_ANSI)
        self.encoding = table

    # composite fonts
    def _init_composite(self, r: Any) -> None:
        enc = r(self.d.get("Encoding"))
        if isinstance(enc, Stream):
            try:
                self.enc_cmap = CMap.parse(enc.decode(), to_unicode=False)
                self.code_lengths = self.enc_cmap.code_lengths()
            except Exception:  # noqa: BLE001
                self.enc_cmap = None
        elif isinstance(enc, Name) and str(enc) in ("Identity-H", "Identity-V"):
            # Identity CMaps always use 2-byte codes. Some producers (Acrobat Paper Capture) write
            # a ToUnicode code space with an extra 1-byte range; it must not split the codes.
            self.code_lengths = [(2, 0, 0xFFFF)]
        if not self.code_lengths and self.to_unicode and self.to_unicode.codespace:
            self.code_lengths = self.to_unicode.code_lengths()
        desc = r(self.d.get("DescendantFonts"))
        cid = r(desc[0]) if isinstance(desc, list) and desc else None
        if isinstance(cid, dict):
            fd = r(cid.get("FontDescriptor"))
            if isinstance(fd, dict):
                self.flags = int(r(fd.get("Flags")) or 0)
                self.weight = int(r(fd.get("FontWeight")) or 0)
            dw = r(cid.get("DW"))
            self.default_width = float(dw) if isinstance(dw, (int, float)) else 1000.0
            w = r(cid.get("W"))
            if isinstance(w, list):
                i = 0
                while i < len(w):
                    c0 = r(w[i])
                    nxt = r(w[i + 1]) if i + 1 < len(w) else None
                    if isinstance(nxt, list) and isinstance(c0, int):
                        for k, val in enumerate(nxt):
                            val = r(val)
                            if isinstance(val, (int, float)):
                                self.widths[c0 + k] = float(val)
                        i += 2
                    elif i + 2 < len(w) and isinstance(c0, int) and isinstance(nxt, int):
                        val = r(w[i + 2])
                        if isinstance(val, (int, float)):
                            for c in range(c0, nxt + 1):
                                self.widths[c] = float(val)
                        i += 3
                    else:
                        i += 1
        else:
            self.default_width = 1000.0

    # decoding
    def decode(self, data: bytes) -> list[tuple[int, str, float, bool]]:
        """Split a string operand into glyphs: (code, unicode, width_in_text_space_units, is_space).

        Width is already scaled to text space (i.e. per unit font size).
        """
        out = []
        if not self.composite:
            for b in data:
                u = None
                if self.to_unicode is not None:
                    u = self.to_unicode.lookup(1, b)
                if u is None:
                    u = self.encoding.get(b)
                if u is None:
                    u = chr(b) if 32 <= b < 127 else "�"
                w = self.widths.get(b, self.default_width) * self.width_scale
                out.append((b, u, w, b == 32))
            return out
        i = 0
        n = len(data)
        lengths = self.code_lengths or [(2, 0, 0xFFFF)]
        while i < n:
            nb = None
            for length, lo, hi in lengths:
                if i + length <= n:
                    c = int.from_bytes(data[i : i + length], "big")
                    if lo <= c <= hi:
                        nb = length
                        break
            if nb is None:
                nb = 2 if i + 2 <= n else 1
            c = int.from_bytes(data[i : i + nb], "big")
            i += nb
            cid = c
            if self.enc_cmap is not None:
                v = self.enc_cmap.lookup(nb, c)
                if isinstance(v, int):
                    cid = v
            u = self.to_unicode.lookup(nb, c) if self.to_unicode else None
            if u is None:
                u = "�"
            w = self.widths.get(cid, self.default_width) * 0.001
            out.append((c, u, w, nb == 1 and c == 32))
        return out


def load_font(doc: Any, resources: dict, name: str, cache: dict) -> Font:
    r = doc.resolve
    fonts = r(resources.get("Font")) if isinstance(resources, dict) else None
    ref = fonts.get(name) if isinstance(fonts, dict) else None
    key = ("ref", ref.num) if hasattr(ref, "num") else ("name", name, id(fonts))
    if key in cache:
        return cache[key]
    fd = r(ref)
    font = Font(doc, fd if isinstance(fd, dict) else None, name)
    cache[key] = font
    return font
