"""Annotations and form fields (ISO 32000-1 §12.5, §12.7)."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from .objects import Ref, text_of


@dataclass
class Annotation:
    page: int
    subtype: str
    rect: tuple[float, float, float, float]  # display coordinates
    ref: Ref | None
    struct_parent: int | None
    contents: str | None
    hidden: bool
    # Form fields (Widget annotations): values inherited through the field /Parent chain.
    field_type: str | None = None
    name: str | None = None  # fully qualified /T
    tooltip: str | None = None  # /TU
    flags: int = 0


def _inherited(doc: Any, d: dict, key: str) -> Any:
    seen = 0
    while isinstance(d, dict) and seen < 32:
        if key in d:
            return doc.resolve(d[key])
        d = doc.resolve(d.get("Parent"))
        seen += 1
    return None


def _full_name(doc: Any, d: dict) -> str | None:
    parts = []
    seen = 0
    while isinstance(d, dict) and seen < 32:
        t = text_of(doc.resolve(d.get("T")))
        if t:
            parts.append(t)
        d = doc.resolve(d.get("Parent"))
        seen += 1
    return ".".join(reversed(parts)) or None


def page_annotations(doc: Any, page: Any) -> list[Annotation]:
    out = []
    annots = doc.resolve(page.dict.get("Annots"))
    if not isinstance(annots, list):
        return out
    for ref in annots:
        a = doc.resolve(ref)
        if not isinstance(a, dict):
            continue
        sub = str(doc.resolve(a.get("Subtype")) or "")
        rect = doc.resolve(a.get("Rect"))
        if not (isinstance(rect, list) and len(rect) == 4):
            continue
        try:
            x0, y0, x1, y1 = (float(doc.resolve(v)) for v in rect)
        except (TypeError, ValueError):
            continue
        p0 = page.to_display(min(x0, x1), min(y0, y1))
        p1 = page.to_display(max(x0, x1), max(y0, y1))
        bbox = (min(p0[0], p1[0]), min(p0[1], p1[1]), max(p0[0], p1[0]), max(p0[1], p1[1]))
        f = doc.resolve(a.get("F"))
        hidden = isinstance(f, int) and bool(f & 2)  # Hidden flag
        sp = doc.resolve(a.get("StructParent"))
        ann = Annotation(page.index, sub, bbox, ref if isinstance(ref, Ref) else None,
                         sp if isinstance(sp, int) else None, text_of(doc.resolve(a.get("Contents"))), hidden)
        if sub == "Widget":
            ft = _inherited(doc, a, "FT")
            ann.field_type = str(ft) if ft is not None else None
            ann.name = _full_name(doc, a)
            ann.tooltip = text_of(_inherited(doc, a, "TU"))
            ff = _inherited(doc, a, "Ff")
            ann.flags = ff if isinstance(ff, int) else 0
        out.append(ann)
    return out
