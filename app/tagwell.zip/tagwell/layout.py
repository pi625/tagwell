"""Geometric reading-order inference.

A recursive XY-cut with column-aware band merging:

1. Split the region into horizontal *bands* wherever there is a clear horizontal gap.
2. Merge consecutive bands that are compatible with a common vertical gutter (nothing
   crosses it). A run of such bands is one multi-column block, which must be read column
   by column, not band by band. This is the step plain XY-cut gets wrong when paragraph
   gaps in two columns happen to line up.
3. Inside a multi-column block, split at the gutter and recurse on each side.
4. A single band with no gutter is read in rows (top to bottom, then left to right).

Boxes use display coordinates: (x0, y0, x1, y1) with y up.
"""
from __future__ import annotations

from typing import Sequence

Box = tuple[float, float, float, float]
EPS = 0.5


def _gaps(intervals: list[tuple[float, float]], lo: float, hi: float, min_gap: float) -> list[tuple[float, float]]:
    """Empty sub-intervals of [lo, hi] not covered by any interval, at least min_gap wide."""
    ivs = sorted(intervals)
    gaps = []
    cur = lo
    for a, b in ivs:
        if a - cur >= min_gap:
            gaps.append((cur, a))
        cur = max(cur, b)
    if hi - cur >= min_gap:
        gaps.append((cur, hi))
    return gaps


def _gutters(boxes: Sequence[Box], min_gap: float) -> list[tuple[float, float]]:
    """Interior vertical gutters: x-intervals that no box overlaps, strictly between content."""
    if len(boxes) < 2:
        return []
    lo = min(b[0] for b in boxes)
    hi = max(b[2] for b in boxes)
    gaps = _gaps([(b[0], b[2]) for b in boxes], lo, hi, min_gap)
    return [g for g in gaps if g[0] > lo + EPS and g[1] < hi - EPS]


def _bands(boxes: Sequence[Box], min_gap: float) -> list[list[int]]:
    """Group box indices into horizontal bands, top to bottom."""
    order = sorted(range(len(boxes)), key=lambda i: -boxes[i][3])
    bands: list[list[int]] = []
    band_bottom = None
    for i in order:
        b = boxes[i]
        if band_bottom is None or b[3] > band_bottom - min_gap:
            if band_bottom is None:
                bands.append([i])
                band_bottom = b[1]
            else:
                bands[-1].append(i)
                band_bottom = min(band_bottom, b[1])
        else:
            bands.append([i])
            band_bottom = b[1]
    return bands


def _narrow(gutters: list[tuple[float, float]], boxes: Sequence[Box], min_gutter: float) -> list[tuple[float, float]]:
    """Gutters are empty vertical strips. Each box that intrudes into a strip from one side
    narrows it; a box that spans a strip (or narrows it below min_gutter) closes it."""
    out = []
    for a, b in gutters:
        alive = True
        for x0, _, x1, _ in boxes:
            if x1 <= a + EPS or x0 >= b - EPS:
                continue
            if x0 <= a + EPS and x1 >= b - EPS:
                alive = False
                break
            if (x0 + x1) / 2 < (a + b) / 2:
                a = max(a, x1)
            else:
                b = min(b, x0)
            if b - a < min_gutter:
                alive = False
                break
        if alive:
            out.append((a, b))
    return out


def _crosses(box: Box, gutter: tuple[float, float]) -> bool:
    mid = (gutter[0] + gutter[1]) / 2
    return box[0] < mid - EPS and box[2] > mid + EPS


def reading_order(boxes: Sequence[Box], min_gap: float = 2.0, min_gutter: float = 6.0,
                  keep_trailing: int | None = None, strict: bool = False,
                  rows_small: float | None = None) -> list[int]:
    """Return indices of `boxes` in inferred visual reading order (left-to-right scripts).

    keep_trailing: bands at the bottom of a column block that sit on only one side of the
    gutter are ambiguous: they may continue that column or start a new section below. None
    keeps them all in the block; an integer j keeps only the first j and reads the rest after
    the block (and also reads one-sided bands at the top of the block before it).
    strict: a band that crosses *any* gutter of a column block ends the block. The lenient
    default only requires it to leave at least one gutter intact, which tolerates accidental
    gutters (e.g. a label/value gap) but can swallow a section that starts under the columns.
    rows_small: if set, a column block whose boxes are all at most this tall (one or two lines:
    label/value pairs, form rows, short grid cells) is read row by row instead of column by column.
    """
    idx = list(range(len(boxes)))
    return _order(boxes, idx, min_gap, min_gutter, 0, keep_trailing, strict, rows_small)


def reading_orders(boxes: Sequence[Box], min_gap: float = 2.0, min_gutter: float = 6.0,
                   rows_small: float | None = None) -> list[list[int]]:
    """All plausible visual orders (distinct). Layout alone cannot decide whether a one-sided
    block below a column section continues that column or starts a new section; a verifier
    should only report a logical order that matches none of the plausible readings."""
    out: list[list[int]] = []
    cm = _column_major(boxes, min_gutter)
    if cm is not None:
        out.append(cm)
    for rows in ((None, rows_small) if rows_small else (None,)):
        for strict in (False, True):
            for keep in (None, 0, 1, 2, 3):
                o = reading_order(boxes, min_gap, min_gutter, keep, strict, rows)
                if o not in out:
                    out.append(o)
    return out


def _column_major(boxes: Sequence[Box], min_gutter: float) -> list[int] | None:
    """Newspaper reading when gutters run the full height of the content below an optional
    spanning header (up to 3 boxes): the header, then each column top to bottom, left to right.
    Index pages and simple multi-column pages. Columns must be substantial (5+ boxes, 1 inch wide)
    so a label/value grid is not read as two columns."""
    by_top = sorted(range(len(boxes)), key=lambda i: -boxes[i][3])
    for k in range(0, 4):
        head, rest = by_top[:k], by_top[k:]
        if len(rest) < 10:
            return None
        if head and min(boxes[i][1] for i in head) < max(boxes[i][3] for i in rest) - EPS:
            continue  # the header must sit above everything else
        sub = [boxes[i] for i in rest]
        gut = _gutters(sub, min(min_gutter, 3.0))
        if not gut:
            continue
        edges = [lo for lo, _ in gut]
        cols: list[list[int]] = [[] for _ in range(len(edges) + 1)]
        for i in rest:
            cols[sum(1 for e in edges if boxes[i][0] >= e)].append(i)
        cols = [c for c in cols if c]
        if len(cols) < 2 or any(len(c) < 5 or max(boxes[i][2] for i in c) - min(boxes[i][0] for i in c) < 72
                                for c in cols):
            continue
        out = sorted(head, key=lambda i: (-boxes[i][3], boxes[i][0]))
        for c in cols:
            out += sorted(c, key=lambda i: (-boxes[i][3], boxes[i][0]))
        return out
    return None


def _order(boxes: Sequence[Box], idx: list[int], min_gap: float, min_gutter: float, depth: int,
           keep_trailing: int | None = None, strict: bool = False, rows_small: float | None = None) -> list[int]:
    if len(idx) <= 1 or depth > 40:
        return list(idx)
    sub = [boxes[i] for i in idx]
    bands = [[idx[j] for j in band] for band in _bands(sub, min_gap)]

    def rec(ix: list[int]) -> list[int]:
        return _order(boxes, ix, min_gap, min_gutter, depth + 1, keep_trailing, strict, rows_small)

    if len(bands) == 1:
        gut = _gutters(sub, min_gutter)
        if gut:
            g = max(gut, key=lambda t: t[1] - t[0])
            mid = (g[0] + g[1]) / 2
            left = [i for i in idx if boxes[i][2] <= mid]
            right = [i for i in idx if boxes[i][2] > mid]
            if left and right:
                return rec(left) + rec(right)
        return _rows(boxes, idx)

    # Merge consecutive bands sharing a compatible gutter into multi-column blocks.
    # Each group keeps its bands so edge bands can be split off again (keep_trailing).
    raw_groups: list[tuple[list[list[int]], list[tuple[float, float]]]] = []
    for band in bands:
        bb = [boxes[i] for i in band]
        own = _gutters(bb, min_gutter)
        if raw_groups:
            g_bands, g_gut = raw_groups[-1]
            if rows_small:
                # Under the row-reading policy a grid (bands of short boxes) never joins a block of
                # paragraph-sized boxes, or vice versa: they are different structures.
                small = all(b[3] - b[1] <= rows_small for b in bb)
                g_boxes = [i for b_ in g_bands for i in b_]
                g_small = all(boxes[i][3] - boxes[i][1] <= rows_small for i in g_boxes)
                # A grid row has 3+ cells; two short headings side by side are not a grid.
                gridlike = (small and len(band) >= 3) or (g_small and len(g_bands[-1]) >= 3)
                if small != g_small and gridlike:
                    raw_groups.append(([band], own))
                    continue
            compatible = _narrow(g_gut, bb, min_gutter)
            if strict and len(compatible) < len(g_gut):
                compatible = []
            if g_gut and compatible:
                raw_groups[-1] = (g_bands + [band], compatible)
                continue
            if own and not g_gut:
                prev = [boxes[i] for b_ in g_bands for i in b_]
                back = _narrow(own, prev, min_gutter)
                width = max(x[2] for x in bb) - min(x[0] for x in bb)
                # A previous band that sits entirely on one side of this band's gutter
                # belongs to the same column block (e.g. columns starting at different heights).
                if back and prev and all(b[2] - b[0] < width * 0.75 for b in prev):
                    raw_groups[-1] = (g_bands + [band], back)
                    continue
        raw_groups.append(([band], own))

    groups: list[tuple[list[int], list[tuple[float, float]]]] = []
    for g_bands, g_gut in raw_groups:
        if keep_trailing is not None and g_gut and len(g_bands) > 1:
            g = max(g_gut, key=lambda t: t[1] - t[0])
            mid = (g[0] + g[1]) / 2
            two = [k for k, b_ in enumerate(g_bands)
                   if any(boxes[i][2] <= mid for i in b_) and any(boxes[i][0] >= mid for i in b_)]
            if two:
                first, last = two[0], min(two[-1] + keep_trailing, len(g_bands) - 1)
                for b_ in g_bands[:first]:
                    groups.append((list(b_), []))
                groups.append(([i for b_ in g_bands[first:last + 1] for i in b_], g_gut))
                for b_ in g_bands[last + 1:]:
                    groups.append((list(b_), []))
                continue
        groups.append(([i for b_ in g_bands for i in b_], g_gut))

    if len(groups) == 1:
        g_idx, g_gut = groups[0]
        if g_gut and rows_small and all(boxes[i][3] - boxes[i][1] <= rows_small for i in g_idx):
            return _rows(boxes, g_idx)
        if g_gut:
            g = max(g_gut, key=lambda t: t[1] - t[0])
            mid = (g[0] + g[1]) / 2
            left = [i for i in g_idx if boxes[i][2] <= mid]
            right = [i for i in g_idx if boxes[i][2] > mid]
            if left and right:
                return rec(left) + rec(right)
        # No usable gutter: read bands top to bottom.
        out: list[int] = []
        for band in bands:
            out += rec(band) if len(band) < len(idx) else _rows(boxes, band)
        return out

    out = []
    for g_idx, _ in groups:
        out += rec(g_idx)
    return out


def _rows(boxes: Sequence[Box], idx: list[int]) -> list[int]:
    """Row-major order for items on shared lines: top to bottom, then left to right."""
    items = sorted(idx, key=lambda i: -boxes[i][3])
    rows: list[list[int]] = []
    for i in items:
        b = boxes[i]
        cy = (b[1] + b[3]) / 2
        if rows:
            r0 = boxes[rows[-1][0]]
            if r0[1] - EPS <= cy <= r0[3] + EPS:
                rows[-1].append(i)
                continue
        rows.append([i])
    out = []
    for row in rows:
        out += sorted(row, key=lambda i: boxes[i][0])
    return out


def longest_increasing_subsequence(seq: Sequence[int], weights: Sequence[float] | None = None) -> list[int]:
    """Indices (into seq) of one longest strictly increasing subsequence.

    With weights, returns the increasing subsequence of maximum total weight (O(n^2)), so callers
    can prefer to keep important elements in place and blame flexible ones for disagreements.
    """
    if weights is not None:
        n = len(seq)
        if n == 0:
            return []
        best = list(weights)
        prev_w = [-1] * n
        for i in range(n):
            for j in range(i):
                if seq[j] < seq[i] and best[j] + weights[i] > best[i] + 1e-12:
                    best[i] = best[j] + weights[i]
                    prev_w[i] = j
        i = max(range(n), key=lambda k: (best[k], -k))
        out_w = []
        while i >= 0:
            out_w.append(i)
            i = prev_w[i]
        return out_w[::-1]
    import bisect

    tails: list[int] = []
    tails_idx: list[int] = []
    prev = [-1] * len(seq)
    for i, v in enumerate(seq):
        k = bisect.bisect_left(tails, v)
        if k == len(tails):
            tails.append(v)
            tails_idx.append(i)
        else:
            tails[k] = v
            tails_idx[k] = i
        prev[i] = tails_idx[k - 1] if k > 0 else -1
    out = []
    i = tails_idx[-1] if tails_idx else -1
    while i >= 0:
        out.append(i)
        i = prev[i]
    return out[::-1]


def kendall_tau_distance(seq: Sequence[int]) -> float:
    """Normalised count of inverted pairs in seq (0 = sorted, 1 = reversed)."""
    n = len(seq)
    if n < 2:
        return 0.0
    inv = 0
    for i in range(n):
        for j in range(i + 1, n):
            if seq[i] > seq[j]:
                inv += 1
    return inv / (n * (n - 1) / 2)
