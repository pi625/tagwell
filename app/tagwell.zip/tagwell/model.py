"""Joins the logical structure with drawn content: each structure element gets its geometry,
text and typography. This is the representation the semantic checks run on."""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Any

from .pdf.content import BBox, ImageDraw, PageContent, PathDraw, TextRun, interpret_page, union
from .pdf.annots import Annotation, page_annotations
from .pdf.document import Document
from .pdf.structure import GROUPING_TYPES, HEADING_TYPES, MCRef, Node, StructTree, build_struct_tree

# Elements read as one unit when comparing logical and visual order. Their inner structure
# is checked separately (tables, lists).
UNIT_TYPES = {"P", "H", "H1", "H2", "H3", "H4", "H5", "H6", "Caption", "LI", "TOCI", "Note",
              "Code", "Formula", "Figure", "Table", "BibEntry", "Form", "Title", "FENote",
              "BlockQuote", "Quote", "Lbl", "LBody", "Span", "Link", "Reference", "Annot"}
INLINE_TYPES = {"Span", "Link", "Reference", "Quote", "Em", "Strong", "Sub", "Annot", "Code",
                "BibEntry", "Ruby", "Warichu", "Lbl"}


@dataclass
class Style:
    size: float  # dominant effective font size (by character count)
    bold_ratio: float
    chars: int
    lines: int


@dataclass(eq=False)
class Unit:
    """A readable block (one per element per page)."""
    node: Node | None  # None for marked content directly under a grouping element
    page: int
    bbox: BBox
    text: str
    style: Style
    logical_rank: int
    runs: list[TextRun] = field(default_factory=list)

    @property
    def type(self) -> str:
        return self.node.type if self.node is not None else "(untyped)"

    @property
    def rotated(self) -> bool:
        """Most of the text runs are not horizontal on the displayed page (rotated tables, spine text)."""
        n = sum(len(r.text.strip()) for r in self.runs)
        return n > 0 and sum(len(r.text.strip()) for r in self.runs if r.rotated) > n / 2

    def snippet(self, n: int = 60) -> str:
        t = " ".join(self.text.split())
        return t if len(t) <= n else t[: n - 1] + "…"


@dataclass
class Analysis:
    path: str
    doc: Document
    pages: list[PageContent]
    tree: StructTree
    content_by_ref: dict[tuple[int | None, int | None, int], list[Any]]
    node_content: dict[int, list[Any]]
    units_by_page: dict[int, list[Unit]]
    body_size: float
    warnings: list[str]
    annotations: list[Annotation] = field(default_factory=list)

    def node_runs(self, node: Node) -> list[TextRun]:
        return [c for c in self.node_content.get(id(node), []) if isinstance(c, TextRun)]

    def node_images(self, node: Node) -> list[ImageDraw]:
        return [c for c in self.node_content.get(id(node), []) if isinstance(c, ImageDraw)]

    def node_paths(self, node: Node) -> list[PathDraw]:
        return [c for c in self.node_content.get(id(node), []) if isinstance(c, PathDraw)]

    def node_bbox(self, node: Node, page: int | None = None) -> BBox | None:
        bb = None
        for c in self.node_content.get(id(node), []):
            if page is None or c.page == page:
                bb = union(bb, c.bbox)
        return bb

    def node_text(self, node: Node) -> str:
        return join_runs(self.node_runs(node))

    def node_style(self, node: Node) -> Style:
        return style_of(self.node_runs(node))

    def node_pages(self, node: Node) -> list[int]:
        return sorted({c.page for c in self.node_content.get(id(node), [])})


def join_runs(runs: list[TextRun]) -> str:
    out: list[str] = []
    prev: TextRun | None = None
    for r in runs:
        if prev is not None:
            same_line = abs(((r.bbox[1] + r.bbox[3]) / 2) - ((prev.bbox[1] + prev.bbox[3]) / 2)) < max(r.size, prev.size) * 0.5
            gap = r.bbox[0] - prev.bbox[2]
            if not same_line or gap > max(r.size, 1) * 0.15:
                if out and not out[-1].endswith((" ", "\n")) and not r.text.startswith(" "):
                    out.append(" ")
        out.append(r.text)
        prev = r
    return "".join(out).strip()


NO_SPLIT_TYPES = {"Table", "Figure", "Form", "Formula", "TOC"}
# Block elements nested inside another reading unit (InDesign anchors tables and figures inside a
# <P>; LaTeX and Word put footnotes inside the paragraph that cites them). They are read where they
# sit in the tree but drawn elsewhere, so they become reading units of their own.
SPLIT_ALWAYS = {"Table", "Note", "FENote", "Figure", "Aside"}
SPLIT_FROM_TEXT = {"P", "H", "H1", "H2", "H3", "H4", "H5", "H6", "L", "BlockQuote", "Div", "Sect", "Art",
                   "Part", "TOC", "Caption"}
TEXT_BLOCKS = {"P", "H", "H1", "H2", "H3", "H4", "H5", "H6", "Caption", "BlockQuote", "Title"}


def split_fragments(runs: list[TextRun]) -> list[list[TextRun]]:
    """Split one element's text (in content order) into spatially separate fragments, e.g. a
    paragraph that flows from the bottom of one column to the top of the next, or across a
    page region. A new fragment starts when the text jumps upward or sideways out of the
    current fragment's horizontal extent (and is not on the same line)."""
    if not runs:
        return []
    frags: list[list[TextRun]] = [[runs[0]]]
    fx0, fx1 = runs[0].bbox[0], runs[0].bbox[2]
    for r in runs[1:]:
        prev = frags[-1][-1]
        size = max(prev.size, r.size, 1.0)
        same_line = min(r.bbox[3], prev.bbox[3]) - max(r.bbox[1], prev.bbox[1]) > 0.3 * size
        moved_up = r.bbox[1] > prev.bbox[3] + 0.5 * size
        outside = r.bbox[0] > fx1 + size or r.bbox[2] < fx0 - size
        if not same_line and (moved_up or outside):
            frags.append([r])
            fx0, fx1 = r.bbox[0], r.bbox[2]
        else:
            frags[-1].append(r)
            fx0, fx1 = min(fx0, r.bbox[0]), max(fx1, r.bbox[2])
    return frags


def style_of(runs: list[TextRun]) -> Style:
    visible = [r for r in runs if not r.invisible]
    if not visible:
        visible = runs
    size_chars: Counter = Counter()
    bold = 0
    total = 0
    for r in visible:
        n = len(r.text.strip())
        size_chars[round(r.size * 2) / 2] += n
        total += n
        if r.bold:
            bold += n
    size = size_chars.most_common(1)[0][0] if size_chars else 0.0
    lines = _count_lines(visible)
    return Style(size, (bold / total) if total else 0.0, total, lines)


def _count_lines(runs: list[TextRun]) -> int:
    centers = sorted(((r.bbox[1] + r.bbox[3]) / 2, r.size) for r in runs)
    lines = 0
    last = None
    for cy, size in centers:
        if last is None or abs(cy - last) > max(size, 1) * 0.5:
            lines += 1
            last = cy
    return lines


def analyse(path: str, data: bytes | None = None) -> Analysis:
    doc = Document(data) if data is not None else Document.open(path)
    warnings = list(doc.warnings)
    pages = []
    for p in doc.pages:
        pc = interpret_page(doc, p)
        warnings += pc.warnings
        pages.append(pc)
    tree = build_struct_tree(doc)
    warnings += tree.warnings

    content_by_ref: dict[tuple[int | None, int | None, int], list[Any]] = defaultdict(list)
    for pc in pages:
        for item in (*pc.texts, *pc.images, *pc.paths):
            if item.mcid is not None and not item.artifact:
                content_by_ref[(pc.page, item.stm, item.mcid)].append(item)
    # Sort by drawing order within each marked-content sequence.
    for v in content_by_ref.values():
        v.sort(key=lambda c: c.seq)

    node_content: dict[int, list[Any]] = {}
    if tree.root is not None:
        # Post-order accumulation so each node holds its descendants' content.
        for node in reversed(list(tree.root.walk())):
            items: list[Any] = []
            for c in node.children:
                if isinstance(c, MCRef):
                    items += content_by_ref.get((c.page, c.stm, c.mcid), [])
                    if c.stm is None and not content_by_ref.get((c.page, None, c.mcid)):
                        # Producers sometimes omit /Stm for form XObject content.
                        for (pg, stm, mcid), v in content_by_ref.items():
                            if pg == c.page and mcid == c.mcid and stm is not None:
                                items += v
                elif isinstance(c, Node):
                    items += node_content.get(id(c), [])
            node_content[id(node)] = items

    body = _body_size(pages, tree, node_content)
    units = _units(tree, node_content, content_by_ref)
    annotations: list[Annotation] = []
    for p in doc.pages:
        try:
            annotations += page_annotations(doc, p)
        except Exception as e:  # noqa: BLE001 - broken annotations must not stop the analysis
            warnings.append(f"page {p.index + 1}: annotations unreadable ({e})")
    return Analysis(path, doc, pages, tree, content_by_ref, node_content, units, body, warnings, annotations)


def _body_size(pages: list[PageContent], tree: StructTree, node_content: dict) -> float:
    c: Counter = Counter()
    for n in tree.nodes:
        if n.type == "P":
            for item in node_content.get(id(n), []):
                if isinstance(item, TextRun) and not item.invisible:
                    c[round(item.size * 2) / 2] += len(item.text.strip())
    if not c:
        for pc in pages:
            for t in pc.texts:
                if not t.artifact and not t.invisible:
                    c[round(t.size * 2) / 2] += len(t.text.strip())
    if not c:
        # Scanned documents: all text is an invisible OCR layer, so measure that instead.
        for n in tree.nodes:
            if n.type == "P":
                for item in node_content.get(id(n), []):
                    if isinstance(item, TextRun):
                        c[round(item.size * 2) / 2] += len(item.text.strip())
        if not c:
            for pc in pages:
                for t in pc.texts:
                    if not t.artifact:
                        c[round(t.size * 2) / 2] += len(t.text.strip())
    return c.most_common(1)[0][0] if c else 10.0


def _units(tree: StructTree, node_content: dict, content_by_ref: dict) -> dict[int, list[Unit]]:
    """Reading units per page, in logical order."""
    out: dict[int, list[Unit]] = defaultdict(list)
    if tree.root is None:
        return out
    rank = 0

    def emit(node: Node | None, items: list[Any]) -> None:
        nonlocal rank
        by_page: dict[int, list[Any]] = defaultdict(list)
        for it in items:
            by_page[it.page].append(it)
        rank += 1
        for pg, its in by_page.items():
            runs = [it for it in its if isinstance(it, TextRun)]
            only_text = len(runs) == len(its)
            if only_text and runs and (node is None or node.type not in NO_SPLIT_TYPES):
                for frag in split_fragments(runs):
                    bb = None
                    for it in frag:
                        bb = union(bb, it.bbox)
                    out[pg].append(Unit(node, pg, bb, join_runs(frag), style_of(frag), rank, frag))
                continue
            bb = None
            for it in its:
                bb = union(bb, it.bbox)
            if bb is None:
                continue
            out[pg].append(Unit(node, pg, bb, join_runs(runs), style_of(runs), rank, runs))

    def nested_blocks(node: Node) -> list[Node]:
        if node.type in NO_SPLIT_TYPES:
            return []
        split = SPLIT_ALWAYS | (SPLIT_FROM_TEXT if node.type in TEXT_BLOCKS else set())
        found: list[Node] = []

        def deep(n: Node, depth: int) -> None:
            # Floating blocks (footnotes, anchored tables and figures) anywhere inside, e.g.
            # LI > LBody > P > Note, but not inside another floating block.
            for g in n.node_children():
                if g.type in SPLIT_ALWAYS:
                    found.append(g)
                elif depth < 8:
                    deep(g, depth + 1)

        for c in node.node_children():
            if c.type in split:
                found.append(c)
            else:
                deep(c, 1)
        return found

    def visit(node: Node) -> None:
        if node.type in UNIT_TYPES and node.type not in INLINE_TYPES:
            blocks = nested_blocks(node)
            if not blocks:
                emit(node, node_content.get(id(node), []))
                return
            # Interleave the element's own text with its nested blocks, in content order, so text
            # before and after a nested list or table becomes two units rather than one box around it.
            owner = {id(it): bi for bi, b in enumerate(blocks) for it in node_content.get(id(b), [])}
            pending_own: list[Any] = []
            done: set[int] = set()
            for it in node_content.get(id(node), []):
                bi = owner.get(id(it))
                if bi is None:
                    pending_own.append(it)
                    continue
                if bi in done:
                    continue
                if pending_own:
                    emit(node, pending_own)
                    pending_own = []
                done.add(bi)
                visit(blocks[bi])
            if pending_own:
                emit(node, pending_own)
            for bi, b in enumerate(blocks):
                if bi not in done:
                    visit(b)
            return
        if node.type in INLINE_TYPES and (node.parent is None or node.parent.type in GROUPING_TYPES
                                          or node.parent.type == "StructTreeRoot"):
            emit(node, node_content.get(id(node), []))
            return
        pending: list[Any] = []
        for c in node.children:
            if isinstance(c, Node):
                if pending:
                    emit(None, pending)
                    pending = []
                visit(c)
            elif isinstance(c, MCRef):
                # Marked content directly under a grouping element: an anonymous block.
                pending += content_by_ref.get((c.page, c.stm, c.mcid), [])
        if pending:
            emit(None, pending)

    for c in tree.root.children:
        if isinstance(c, Node):
            visit(c)
    for pg in out:
        out[pg].sort(key=lambda u: u.logical_rank)
    return out
