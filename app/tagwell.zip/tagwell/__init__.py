"""Tagwell: semantic accessibility verification for tagged PDFs."""

__version__ = "0.3.0"
