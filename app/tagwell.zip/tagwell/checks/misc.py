"""Scanned pages (image-only), and link text (WCAG 2.4.4)."""
from __future__ import annotations

import re

from ..findings import Finding
from ..model import Analysis

VAGUE_LINK = re.compile(r"^(click here|here|more|read more|learn more|link|this link|click|details|info|"
                        r"this|go|download|view)\.?$", re.I)
URL_ONLY = re.compile(r"^(https?://|www\.)\S+$", re.I)


def check_scanned(a: Analysis) -> list[Finding]:
    out = []
    for pc in a.pages:
        area = max(pc.width * pc.height, 1.0)
        big = [i for i in pc.images if (i.bbox[2] - i.bbox[0]) * (i.bbox[3] - i.bbox[1]) >= area * 0.7]
        if not big:
            continue
        visible = sum(len(t.text.strip()) for t in pc.texts if not t.invisible)
        hidden = sum(len(t.text.strip()) for t in pc.texts if t.invisible)
        if visible < 20 and hidden < 20:
            out.append(Finding("scanned-page", "Scanned page with no text", "error", "high",
                               "This page is a picture of text with no real text behind it. It needs OCR before it can "
                               "be read aloud, searched, or tagged.", page=pc.page, matterhorn=["01-005"],
                               wcag=["1.1.1", "1.4.5"], machine_checkable=True))
        elif visible < 20:
            out.append(Finding("ocr-layer", "Scanned page with an OCR text layer", "notice", "medium",
                               f"This page is an image with {hidden} characters of invisible OCR text. OCR errors are "
                               "common; spot-check the recognised text against the image.", page=pc.page,
                               matterhorn=["01-006"], wcag=["1.1.1"]))
    return out


def check_links(a: Analysis) -> list[Finding]:
    out = []
    for n in a.tree.by_type("Link"):
        text = " ".join(a.node_text(n).split())
        alt = (n.alt or "").strip()
        if not text:
            continue
        if VAGUE_LINK.match(text) and not alt:
            pages = a.node_pages(n)
            out.append(Finding("link-text", "Link text does not say where it goes", "notice", "medium",
                               f"A link reads “{text}”. Out of context (e.g. in a screen reader's list of links) "
                               "this does not describe the destination.", page=pages[0] if pages else n.page,
                               bbox=a.node_bbox(n), element="Link", wcag=["2.4.4"]))
        elif URL_ONLY.match(text) and len(text) > 40 and not alt:
            pages = a.node_pages(n)
            out.append(Finding("link-text", "Long raw URL used as link text", "notice", "low",
                               f"“{text[:60]}” will be read out character by character by many screen readers.",
                               page=pages[0] if pages else n.page, bbox=a.node_bbox(n), element="Link", wcag=["2.4.4"]))
    return out
