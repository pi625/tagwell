"""Headings: structural rules (14-002/003/007, machine) and visual-vs-tagged semantics
(14-001 and 09-003, human conditions)."""
from __future__ import annotations

import re
import statistics
from collections import defaultdict

from ..findings import Finding
from ..model import Analysis, Unit

NUMBERED = {"H1": 1, "H2": 2, "H3": 3, "H4": 4, "H5": 5, "H6": 6}
NOT_HEADING_CONTEXT = {"Table", "TR", "TH", "TD", "L", "LI", "LBody", "Lbl", "Caption", "Figure",
                       "Form", "Note", "TOC", "TOCI", "Link", "Index"}
_TERMINAL = re.compile(r"[.,;!?]\s*$")
_HAS_LETTER = re.compile(r"[^\W\d_]", re.U)
_WORD = re.compile(r"[^\W\d_]{3,}", re.U)
CAPTION_RE = re.compile(r"^\s*(table|figure|fig\.|chart|exhibit|worksheet|map)\s*[0-9A-Z]", re.I)
PAGE_REFS = re.compile(r"[^\W\d_][\w)]*,?\s+\d{1,4}(,\s*\d{1,4})*$", re.U)
HEADINGS = {"H", "H1", "H2", "H3", "H4", "H5", "H6"}


def _same_style(a: Unit, b: Unit | None) -> bool:
    return (b is not None and (b.node is None or b.node.type not in HEADINGS)
            and abs(a.style.size - b.style.size) <= 0.3
            and (a.style.bold_ratio >= 0.5) == (b.style.bold_ratio >= 0.5) and b.style.lines <= 2)


def _near(a: Unit, b: Unit | None, body: float) -> bool:
    if b is None or b.page != a.page:
        return False
    gap = max(b.bbox[1] - a.bbox[3], a.bbox[1] - b.bbox[3], 0.0)
    return gap <= 1.5 * body


def check_heading_structure(a: Analysis) -> list[Finding]:
    out = []
    heads = [n for n in a.tree.nodes if n.type in NUMBERED or n.type == "H"]
    numbered = [n for n in heads if n.type in NUMBERED]
    if numbered and any(n.type == "H" for n in heads):
        out.append(Finding("heading-mixed", "Document mixes <H> and numbered <H1>-<H6> headings", "warning",
                           "high", "Use either numbered headings or the generic <H>, not both.",
                           matterhorn=["14-007"], wcag=["1.3.1"], machine_checkable=True))
    if numbered:
        first = numbered[0]
        if first.type != "H1":
            out.append(Finding("heading-first", "First heading is not <H1>", "warning", "high",
                               f"The first numbered heading is <{first.type}> (“{a.node_text(first)[:60]}”).",
                               page=_page(a, first), matterhorn=["14-002"], wcag=["1.3.1"], machine_checkable=True))
        prev = 0
        for n in numbered:
            lvl = NUMBERED[n.type]
            if prev and lvl > prev + 1:
                out.append(Finding("heading-skip", f"Heading level skipped (H{prev} → H{lvl})", "warning", "high",
                                   f"“{a.node_text(n)[:60]}” is <H{lvl}> but follows an <H{prev}>.",
                                   page=_page(a, n), bbox=a.node_bbox(n), matterhorn=["14-003"], wcag=["1.3.1"],
                                   machine_checkable=True))
            prev = lvl
    return out


def _page(a: Analysis, node) -> int | None:
    pages = a.node_pages(node)
    return pages[0] if pages else node.page


def _looks_like_heading(u: Unit, body: float, next_u: Unit | None) -> tuple[bool, str, str]:
    """Return (is_heading_like, confidence, reason)."""
    text = " ".join(u.text.split())
    if not (2 <= len(text) <= 120) or not _HAS_LETTER.search(text):
        return False, "", ""
    # Item labels such as "1z", "(a)", "35a" or "No" on forms are not headings: a heading has a word.
    if not _WORD.search(text):
        return False, "", ""
    if u.style.lines > 2 or _TERMINAL.search(text) or text.endswith(":"):
        return False, "", ""
    if re.fullmatch(r"(page\s*)?\d+(\s*(of|/)\s*\d+)?", text, re.I):
        return False, "", ""
    size, bold = u.style.size, u.style.bold_ratio
    if size >= body * 1.4:
        return True, "high", f"set in {size:g} pt against {body:g} pt body text"
    if size >= body * 1.2:
        return True, "medium", f"set in {size:g} pt against {body:g} pt body text"
    if bold >= 0.9 and size >= body * 0.95 and next_u is not None:
        nxt_longer = len(next_u.text) > len(text) * 1.5
        nxt_plain = next_u.style.bold_ratio < 0.5
        if nxt_longer and nxt_plain and u.style.lines == 1 and len(text) <= 80:
            return True, "medium", "a short bold line followed by plain body text"
    return False, "", ""


def check_visual_headings(a: Analysis) -> list[Finding]:
    from .tables import check_untagged_tables

    out = []
    body = a.body_size
    # Bold header cells of an untagged grid are table headers, reported by the table check.
    grids: dict[int, list] = {}
    for f in check_untagged_tables(a):
        grids.setdefault(f.page, []).append(f.bbox)
    form_page: dict[int, bool] = {}
    for an in a.annotations:
        if an.subtype == "Widget":
            form_page[an.page] = True
    index_page: dict[int, bool] = {}
    for page, units in a.units_by_page.items():
        refs = sum(1 for u in units if PAGE_REFS.search(u.text.strip()))
        index_page[page] = len(units) >= 15 and refs >= 0.5 * len(units)
    for page, units in sorted(a.units_by_page.items()):
        for i, u in enumerate(units):
            if u.rotated:
                continue
            cx, cy = (u.bbox[0] + u.bbox[2]) / 2, (u.bbox[1] + u.bbox[3]) / 2
            if any(g[0] - 2 <= cx <= g[2] + 2 and g[1] - 2 <= cy <= g[3] + 2 for g in grids.get(page, [])):
                continue
            if u.node is None and not u.text.strip():
                continue
            if u.node is not None and (u.node.type != "P" or u.node.has_ancestor(NOT_HEADING_CONTEXT)):
                continue
            nxt = units[i + 1] if i + 1 < len(units) else None
            prv = units[i - 1] if i > 0 else None
            ok, conf, why = _looks_like_heading(u, body, nxt)
            if ok and (CAPTION_RE.match(u.text) or (prv is not None and CAPTION_RE.match(prv.text)
                                                     and _near(u, prv, body))):
                ok = False  # a table or figure title, i.e. a caption, not a section heading
            if ok and index_page.get(page) and "bold line" in why:
                ok = False  # bold index entries ("Reminders 3")
            if ok and form_page.get(page) and "bold line" in why:
                ok = False  # bold field labels on forms
            if ok and u.style.size >= body * 1.2 and any(
                    n is not None and n.node is not None and n.node.type in HEADINGS and _near(u, n, body)
                    for n in (prv, nxt)):
                ok = False  # a line of a title block next to a tagged heading (series label, subtitle)
            if ok and (_same_style(u, prv) and _near(u, prv, body) or _same_style(u, nxt) and _near(u, nxt, body)):
                ok = False  # a run of identically styled short lines: author names, a cover block
            if ok:
                tag = f"<{u.node.raw_type}>" if u.node is not None else "untyped content"
                out.append(Finding(
                    "visual-heading", "Text looks like a heading but is not tagged as one",
                    "error" if conf == "high" else "warning", conf,
                    f"“{u.snippet(70)}” is {why}, but it is tagged as {tag}. Screen-reader users "
                    "navigate by headings and will not find this section.",
                    page=page, bbox=u.bbox, element=u.type, matterhorn=["14-001"], wcag=["1.3.1", "2.4.6"]))
    # Tagged headings that read as body text.
    for page, units in sorted(a.units_by_page.items()):
        for u in units:
            if u.node is None or u.node.type not in NUMBERED and u.node.type != "H":
                continue
            if u.style.chars > 200 or (u.style.lines >= 4 and u.style.size <= body * 1.02 and u.style.bold_ratio < 0.5):
                out.append(Finding(
                    "heading-is-body", "Heading tag on what looks like body text", "warning", "medium",
                    f"“{u.snippet(70)}” is tagged <{u.node.type}> but is {u.style.lines} lines / "
                    f"{u.style.chars} characters of {u.style.size:g} pt text. Heading navigation will be noisy.",
                    page=page, bbox=u.bbox, element=u.type, matterhorn=["09-003"], wcag=["1.3.1"]))
    # Heading levels whose visual sizes are inverted.
    sizes: dict[int, list[float]] = defaultdict(list)
    per_page: dict[int, dict[int, list[float]]] = defaultdict(lambda: defaultdict(list))
    for page, units in a.units_by_page.items():
        for u in units:
            if u.node is not None and u.node.type in NUMBERED and u.style.size:
                sizes[NUMBERED[u.node.type]].append(u.style.size)
                per_page[page][NUMBERED[u.node.type]].append(u.style.size)
    med = {lvl: statistics.median(v) for lvl, v in sizes.items() if v}
    levels = sorted(med)

    def inverted_on_most_pages(hi: int, lo: int) -> bool:
        # Forms and covers use small heading text in one place and large in another; judge levels
        # where they appear together, so one dense form page does not invert the whole outline.
        # Compare with the largest higher-level heading on the page: a small "Form" label tagged H1
        # next to a large title should not make H1 look smaller than H3.
        votes = [statistics.median(d[lo]) > max(d[hi]) * 1.1
                 for d in per_page.values() if d.get(hi) and d.get(lo)]
        return bool(votes) and sum(votes) > len(votes) / 2

    for i, hi in enumerate(levels):
        for lo in levels[i + 1:]:
            if med[lo] > med[hi] * 1.1 and inverted_on_most_pages(hi, lo):
                out.append(Finding(
                    "heading-size-inverted", f"<H{lo}> headings are visually larger than <H{hi}> headings", "warning",
                    "medium", f"Median size of H{lo} text is {med[lo]:g} pt but H{hi} is {med[hi]:g} pt. "
                    "The heading levels may be swapped, which misrepresents the document outline.",
                    matterhorn=["09-003"], wcag=["1.3.1"]))
    return out
