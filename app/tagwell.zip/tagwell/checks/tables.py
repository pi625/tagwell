"""Tables: syntax (09-004, 15-003; machine) and semantics against the drawn layout
(15-001/15-002 header cells, 15-004 layout tables, row geometry; human conditions)."""
from __future__ import annotations

import statistics

from ..findings import Finding
from ..model import Analysis, style_of
from ..pdf.content import union
from ..pdf.structure import MCRef, Node

ROW_GROUPS = {"THead", "TBody", "TFoot"}


def _rows(table: Node) -> list[Node]:
    rows = []
    for c in table.node_children():
        if c.type == "TR":
            rows.append(c)
        elif c.type in ROW_GROUPS:
            rows += [r for r in c.node_children() if r.type == "TR"]
    return rows


def _span(cell: Node, key: str) -> int:
    v = cell.attrs.get(key)
    return int(v) if isinstance(v, (int, float)) and v >= 1 else 1


def check_tables(a: Analysis) -> list[Finding]:
    out: list[Finding] = []
    uses_headers = any("Headers" in n.attrs for n in a.tree.nodes if n.type in ("TD", "TH"))
    for t in a.tree.by_type("Table"):
        page = (a.node_pages(t) or [t.page])[0]
        tbb = a.node_bbox(t)
        # --- syntax (machine) ---
        bad_kids = [c.type for c in t.node_children() if c.type not in ROW_GROUPS | {"TR", "Caption"}]
        rows = _rows(t)
        bad_cells = [c.type for r in rows for c in r.node_children() if c.type not in ("TH", "TD")]
        # Producers sometimes put a row's text straight into <TR> with no cells (seen in LaTeX output):
        # a screen reader then has no cells to navigate.
        if any(isinstance(c, MCRef) for r in rows for c in r.children):
            bad_cells.append("text directly inside <TR> with no <TD>/<TH> cells")
        if bad_kids or bad_cells or not rows:
            out.append(Finding("table-syntax", "Table structure is malformed", "error", "high",
                               "A <Table> must contain rows (<TR>, optionally grouped in THead/TBody/TFoot), and "
                               "rows must contain <TH>/<TD> cells. Found: "
                               + (", ".join(sorted(set(bad_kids + bad_cells))) or "no rows"),
                               page=page, bbox=tbb, element="Table", matterhorn=["09-004"], wcag=["1.3.1"],
                               machine_checkable=True))
            if not rows:
                continue
        cells = [[c for c in r.node_children() if c.type in ("TH", "TD")] for r in rows]
        widths = [sum(_span(c, "ColSpan") for c in row) for row in cells]
        if len(set(widths)) > 1 and not any(_span(c, "RowSpan") > 1 for row in cells for c in row):
            out.append(Finding("table-columns", "Table rows have different numbers of columns", "warning", "high",
                               f"Row widths (counting ColSpan): {widths[:12]}. Screen readers announce wrong "
                               "row/column positions in irregular tables.",
                               page=page, bbox=tbb, element="Table", matterhorn=["09-004", "15-005"], wcag=["1.3.1"],
                               machine_checkable=True))
        if not uses_headers:
            missing = [c for row in cells for c in row if c.type == "TH" and "Scope" not in c.attrs]
            if missing and len(cells) > 1 and max(widths) > 1:
                out.append(Finding("th-scope", "Header cells have no Scope", "warning", "high",
                                   f"{len(missing)} <TH> cell(s) have no Scope attribute, so it is ambiguous whether "
                                   "they head a row or a column.", page=page, bbox=tbb, element="TH",
                                   matterhorn=["15-003"], wcag=["1.3.1"], machine_checkable=True))
        # --- layout tables (15-004) ---
        ncols = max(widths) if widths else 0
        text_lens = [len(a.node_text(c)) for row in cells for c in row]
        if len(cells) >= 2 and ncols == 1:
            out.append(Finding("layout-table", "Single-column table: probably used for layout", "warning", "medium",
                               f"This <Table> has {len(cells)} rows and one column. Content tagged as a table should "
                               "be data organised in rows and columns; otherwise screen readers announce a "
                               "meaningless table.", page=page, bbox=tbb, element="Table",
                               matterhorn=["15-004"], wcag=["1.3.1"]))
        elif text_lens and statistics.mean(text_lens) > 250:
            out.append(Finding("layout-table", "Table cells contain long passages: possibly a layout table", "notice",
                               "low", "Average cell length is over 250 characters. Check this is really tabular data.",
                               page=page, bbox=tbb, element="Table", matterhorn=["15-004"], wcag=["1.3.1"]))
        # --- header semantics (15-001 / 15-002) ---
        if len(cells) >= 3 and ncols >= 2:
            out += _header_semantics(a, t, cells, page)
        # --- row geometry: cells grouped into a TR must share a visual row ---
        runs = a.node_runs(t)
        if runs and sum(1 for r in runs if r.rotated) > len(runs) / 2:
            continue  # a table set sideways: its rows run vertically on the page
        for ri, row in enumerate(cells):
            # Cells spanning several rows sit between them; they say nothing about this row's band.
            boxes = [a.node_bbox(c) for c in row if _span(c, "RowSpan") == 1]
            boxes = [b for b in boxes if b is not None]
            if len(boxes) < 2:
                continue
            # A tall cell (several lines) can hold a label at its top and a line number at its bottom:
            # the row is broken only if the cells' vertical extents fall into separate bands.
            ivs = sorted((b[1], b[3]) for b in boxes)
            bands = 1
            reach = ivs[0][1]
            for lo, hi in ivs[1:]:
                if lo > reach + 1.0:
                    bands += 1
                reach = max(reach, hi)
            if bands > 1:  # no common horizontal band
                rb = None
                for b in boxes:
                    rb = union(rb, b)
                out.append(Finding("row-geometry", "Cells in one table row are on different visual rows", "error",
                                   "medium", f"Row {ri + 1} of this table groups cells that do not line up "
                                   "horizontally. The row/column structure in the tags does not match the drawn table.",
                                   page=page, bbox=rb, element="TR", matterhorn=["15-004", "15-005"], wcag=["1.3.1"]))
                break
    return out


def _header_semantics(a: Analysis, t: Node, cells: list[list[Node]], page: int | None) -> list[Finding]:
    out = []
    first = cells[0]
    body_rows = cells[1:]
    if not any(c.type == "TH" for c in first):
        st_first = style_of([r for c in first for r in a.node_runs(c)])
        st_body = style_of([r for row in body_rows for c in row for r in a.node_runs(c)])
        shaded = _row_shaded(a, first, page)
        distinct = (st_first.bold_ratio >= 0.8 and st_body.bold_ratio < 0.3) or \
                   (st_body.size and st_first.size >= st_body.size * 1.15) or shaded
        # One filled cell spanning the row is a section title ("Funds Belonging to the Person You
        # Supported" on IRS worksheets), not a row of column names.
        filled = sum(1 for c in first if a.node_text(c).strip())
        if distinct and st_first.chars and filled >= 2:
            why = []
            if st_first.bold_ratio >= 0.8 and st_body.bold_ratio < 0.3:
                why.append("bold while the body rows are not")
            if st_body.size and st_first.size >= st_body.size * 1.15:
                why.append("larger than the body rows")
            if shaded:
                why.append("on a shaded background")
            out.append(Finding("column-headers", "First row looks like column headers but is tagged as data cells",
                               "error", "high" if len(why) >= 2 else "medium",
                               "The first row is " + " and ".join(why) + ", which is how column headers are drawn, "
                               "but its cells are <TD>. Screen readers will not announce the column names.",
                               page=page, bbox=_union_boxes(a, first), element="TD",
                               evidence=["Header-like row: " + " | ".join(a.node_text(c)[:20] for c in first[:6])],
                               matterhorn=["15-002"], wcag=["1.3.1"]))
    # Row headers: first column bold, the rest plain, and no TH in that column.
    col0 = [row[0] for row in body_rows if row]
    rest = [c for row in body_rows for c in row[1:]]
    if col0 and rest and all(c.type == "TD" for c in col0):
        s0 = style_of([r for c in col0 for r in a.node_runs(c)])
        sr = style_of([r for c in rest for r in a.node_runs(c)])
        if s0.chars and s0.bold_ratio >= 0.8 and sr.bold_ratio < 0.3:
            out.append(Finding("row-headers", "First column looks like row headers but is tagged as data cells",
                               "warning", "medium", "The first column is bold while the other cells are not, which "
                               "usually means row headers. Consider <TH Scope=Row>.",
                               page=page, bbox=_union_boxes(a, col0), element="TD", matterhorn=["15-001"],
                               wcag=["1.3.1"]))
    return out


def _union_boxes(a: Analysis, nodes: list[Node]):
    bb = None
    for n in nodes:
        bb = union(bb, a.node_bbox(n))
    return bb


def _row_shaded(a: Analysis, row: list[Node], page: int | None) -> bool:
    """Is there a non-white filled rectangle behind the row (drawn anywhere: tagged, artifact, untagged)?"""
    rb = _union_boxes(a, row)
    if rb is None or page is None or page >= len(a.pages):
        return False
    cy = (rb[1] + rb[3]) / 2
    for p in a.pages[page].paths:
        if not p.fill or p.fill_lum > 0.93:
            continue
        x0, y0, x1, y1 = p.bbox
        if y0 - 1 <= cy <= y1 + 1 and x0 <= rb[0] + 2 and x1 >= rb[2] - 2 and (y1 - y0) < (rb[3] - rb[1]) * 3:
            return True
    return False


NUMERIC = __import__("re").compile(r"^[\s$€£¥(]*[-+]?\d[\d,.\s]*%?\)?\s*$")


def _segments(runs, owner: dict, gap_em: float = 1.5):
    """Merge runs on one line into segments [x0, x1, text, unit_ids] separated by wide gaps."""
    runs = sorted(runs, key=lambda r: r.bbox[0])
    segs = []
    for r in runs:
        size = max(r.size, 1.0)
        if segs and r.bbox[0] - segs[-1][1] < gap_em * size:
            segs[-1][1] = max(segs[-1][1], r.bbox[2])
            segs[-1][2] += r.text
            segs[-1][3].add(owner[id(r)])
        else:
            segs.append([r.bbox[0], r.bbox[2], r.text, {owner[id(r)]}])
    return segs


def _running_text(reg) -> bool:
    """Columns of flowing text: some unit continues down >=3 lines of the region, while the
    segments on a line come from different units (side-by-side paragraphs)."""
    lines_per_unit: dict[int, int] = {}
    shared_line = 0
    for _, segs, _ in reg:
        units_here = [u for s in segs for u in s[3]]
        if len(set(units_here)) < len(units_here) or len(segs) > len({u for s in segs for u in s[3]}):
            shared_line += 1
        for u in {u for s in segs for u in s[3]}:
            lines_per_unit[u] = lines_per_unit.get(u, 0) + 1
    flows = any(v >= 3 for v in lines_per_unit.values())
    return flows and shared_line <= len(reg) // 3


def check_untagged_tables(a: Analysis) -> list[Finding]:
    """Text laid out as a grid (short segments aligned in columns over several lines) that is not
    tagged as a table: screen readers read it as a run-on list of values (09-003, WCAG 1.3.1)."""
    out = []
    for page, units in sorted(a.units_by_page.items()):
        runs = []
        owner: dict[int, int] = {}
        for ui, u in enumerate(units):
            if u.node is not None and (u.node.type in ("Table", "Figure", "Form", "TOC", "TOCI", "L", "LI")
                                       or u.node.has_ancestor({"Table", "L", "TOC"})):
                continue
            for r in u.runs:
                if r.text.strip() and not r.invisible:
                    runs.append(r)
                    owner[id(r)] = ui
        if len(runs) < 6:
            continue
        # Lines: cluster by vertical centre.
        runs.sort(key=lambda r: -(r.bbox[1] + r.bbox[3]) / 2)
        lines = []
        for r in runs:
            cy = (r.bbox[1] + r.bbox[3]) / 2
            if lines and abs(lines[-1][0] - cy) < 0.5 * max(r.size, 1.0):
                lines[-1][1].append(r)
            else:
                lines.append([cy, [r]])
        # Regions of consecutive multi-segment lines.
        region = []
        regions = []
        prev_cy = None
        for cy, lr in lines:
            segs = _segments(lr, owner)
            size = max(x.size for x in lr)
            contiguous = prev_cy is None or prev_cy - cy < 2.6 * size
            if len(segs) >= 2 and contiguous:
                region.append((cy, segs, size))
            else:
                if len(region) >= 3:
                    regions.append(region)
                region = [(cy, segs, size)] if len(segs) >= 2 else []
            prev_cy = cy
        if len(region) >= 3:
            regions.append(region)
        for reg in regions:
            n = len(reg)
            seg_texts = [s[2].strip() for _, segs, _ in reg for s in segs]
            lens = sorted(len(t) for t in seg_texts)
            if lens[len(lens) // 2] > 30 or _running_text(reg):
                continue  # running text in columns, not a grid
            # Column anchors: left edges (or right edges for numbers) shared by most lines.
            anchors = []
            for edge in (0, 1):
                xs = sorted(s[edge] for _, segs, _ in reg for s in segs[1:] if edge == 0 or NUMERIC.match(s[2]))
                clusters = []
                for x in xs:
                    if clusters and x - clusters[-1][-1] <= 4:
                        clusters[-1].append(x)
                    else:
                        clusters.append([x])
                anchors += [c for c in clusters if len({round(v) for v in c}) and len(c) >= 0.7 * n]
            ncols = 1 + len(anchors)
            numeric = sum(1 for _, segs, _ in reg for s in segs[1:] if NUMERIC.match(s[2]))
            total_other = sum(len(segs) - 1 for _, segs, _ in reg)
            if ncols >= 3 or (ncols == 2 and n >= 4 and numeric >= 0.5 * total_other):
                xs0 = min(s[0] for _, segs, _ in reg for s in segs)
                xs1 = max(s[1] for _, segs, _ in reg for s in segs)
                top = reg[0][0] + reg[0][2]
                bot = reg[-1][0] - reg[-1][2]
                conf = "high" if ncols >= 3 and n >= 4 else "medium"
                out.append(Finding(
                    "table-untagged", "Text is laid out as a table but not tagged as one", "warning", conf,
                    f"{n} lines of short values aligned in {ncols} columns are tagged as ordinary text. A screen reader "
                    "reads the cells as one run of words, without row or column headers.",
                    page=page, bbox=(xs0, bot, xs1, top),
                    evidence=["First rows: " + " / ".join(" | ".join(s[2].strip()[:18] for s in segs) for _, segs, _ in reg[:3])],
                    matterhorn=["09-003"], wcag=["1.3.1"]))
    return out
