"""Form fields and annotations.

Machine conditions (Matterhorn 28): tooltip/alt present (28-005), Tabs = S (28-008/009),
widgets in <Form> (28-010), links in <Link> (28-011) with Contents (28-012).
Judgement conditions, from geometry and text:
  - auto-generated tooltips ("Text1", "Check Box 3") that a screen reader would announce;
  - label-in-name: the field's accessible name does not contain the visible label next to it
    (WCAG 2.5.3, 1.3.1, 4.1.2);
  - tab order: fields are visited in a different order than they appear (28-001, WCAG 2.4.3).
These matter most under ADA Title II: forms used to apply for services are never exempt.
"""
from __future__ import annotations

import re
from collections import defaultdict

from ..findings import Finding
from ..model import Analysis
from ..pdf.content import union
from ..pdf.structure import ObjRef
from .reading_order import assess

AUTO_NAME = re.compile(
    r"^(text|text ?field|check ?box|checkbox|radio( ?button)?|button|push ?button|field|undefined|fill|"
    r"untitled|dropdown|drop ?down|list ?box|combo ?box|choice|signature|sig|group|textbox|fill_in|form)"
    r"[\s_.\-#]*\d*$", re.I)
STOP = {"the", "and", "for", "your", "you", "of", "to", "a", "an", "in", "on", "or", "if", "is", "are",
        "please", "enter", "this", "that", "with", "by", "at", "be", "as", "any", "all", "from", "its"}
WORD = re.compile(r"[^\W_]+", re.U)
# Words that appear in many different field labels; sharing only these is not a match.
GENERIC = {"number", "name", "date", "address", "code", "info", "information", "details", "field", "type",
           "contact", "line", "first", "last", "full", "primary", "secondary", "other", "required", "optional"}


def _words(s: str | None) -> set[str]:
    return {w.lower() for w in WORD.findall(s or "") if len(w) >= 3 and w.lower() not in STOP}


def _referenced(a: Analysis) -> dict[int, str]:
    """annotation object number -> type of the structure element that references it via OBJR."""
    out = {}
    for n in a.tree.nodes:
        for c in n.children:
            if isinstance(c, ObjRef) and hasattr(c.obj, "num"):
                out[c.obj.num] = n.type
    return out


def _form_alt(a: Analysis) -> dict[int, str]:
    out = {}
    for n in a.tree.nodes:
        if n.type == "Form" and (n.alt or "").strip():
            for c in n.children:
                if isinstance(c, ObjRef) and hasattr(c.obj, "num"):
                    out[c.obj.num] = n.alt.strip()
    return out


def _label_for(a: Analysis, ann) -> str | None:
    """The visible label of a field: nearest text to the left on the same line; failing that, body-size
    text directly above and aligned with the field (headings are not labels)."""
    pc = a.pages[ann.page] if ann.page < len(a.pages) else None
    if pc is None:
        return None
    x0, y0, x1, y1 = ann.rect
    h = max(y1 - y0, 6.0)
    left, above = [], []
    for t in pc.texts:
        if t.invisible or t.artifact or not t.text.strip():
            continue
        tx0, ty0, tx1, ty1 = t.bbox
        same_line = min(ty1, y1) - max(ty0, y0) > 0.4 * min(ty1 - ty0, h)
        if same_line and tx1 <= x0 + 2 and x0 - tx1 < 220:
            left.append((x0 - tx1, t))
        elif (ty0 >= y1 - 2 and ty0 - y1 < 2.5 * max(ty1 - ty0, 8) and abs(tx0 - x0) < 24
              and t.size <= a.body_size * 1.3):
            above.append((ty0 - y1, t))
    pool = left or above
    if not pool:
        return None
    best = min(pool, key=lambda c: c[0])[1]
    return " ".join(best.text.split()).rstrip(":*").strip() or None


def check_forms(a: Analysis) -> list[Finding]:
    out: list[Finding] = []
    if not a.annotations:
        return out
    refd = _referenced(a)
    alts = _form_alt(a)
    tagged = a.tree.root is not None and bool(a.tree.nodes)
    by_page = defaultdict(list)
    for ann in a.annotations:
        by_page[ann.page].append(ann)
    for page, anns in sorted(by_page.items()):
        visible = [x for x in anns if not x.hidden and x.subtype not in ("Popup",)]
        if not visible:
            continue
        pdict = a.doc.pages[page].dict if page < len(a.doc.pages) else {}
        tabs = a.doc.resolve(pdict.get("Tabs"))
        if tabs is None or str(tabs) != "S":
            out.append(Finding("tabs-order", "Page with annotations does not use structure tab order", "warning", "high",
                               "The page has form fields or links but /Tabs is " + ("missing" if tabs is None else f"/{tabs}")
                               + ", so keyboard focus may not follow the reading order.", page=page,
                               matterhorn=["28-008" if tabs is None else "28-009"], wcag=["2.4.3"], machine_checkable=True))
        widgets = [x for x in visible if x.subtype == "Widget"]
        missing_name = []
        auto_named = []
        mismatched = []
        untagged = []
        for w in widgets:
            num = w.ref.num if w.ref is not None else None
            alt = alts.get(num) if num is not None else None
            name = (w.tooltip or "").strip() or alt
            if tagged and num is not None and refd.get(num) != "Form":
                untagged.append(w)
            if not name:
                missing_name.append(w)
                continue
            if AUTO_NAME.match(name) or (w.name and name == w.name and AUTO_NAME.match(w.name.split(".")[-1])):
                auto_named.append((w, name))
                continue
            label = _label_for(a, w)
            lw = _words(label)
            nw = _words(name)
            specific = lw - GENERIC
            matched = bool(specific & nw) if specific else bool(lw & nw)
            if label and lw and not matched:
                mismatched.append((w, name, label))
        if missing_name:
            out.append(Finding("field-name-missing", "Form fields have no accessible name", "error", "high",
                               f"{len(missing_name)} field(s) have no tooltip (/TU) and no Alt text, so a screen reader "
                               "announces them only by type (“edit text”).", page=page,
                               bbox=_union(missing_name), evidence=_names(missing_name),
                               matterhorn=["28-005"], wcag=["4.1.2", "1.3.1"], machine_checkable=True))
        if auto_named:
            out.append(Finding("field-name-auto", "Form field names are auto-generated", "error", "high",
                               f"{len(auto_named)} field(s) have names like “{auto_named[0][1]}”. A screen reader "
                               "reads these out instead of what the field is for.", page=page,
                               bbox=_union([w for w, _ in auto_named]),
                               evidence=[f"“{n}”" for _, n in auto_named[:6]],
                               matterhorn=["28-005"], wcag=["4.1.2", "1.3.1"]))
        if mismatched:
            out.append(Finding("field-label-mismatch", "Field names do not match their visible labels", "warning",
                               "medium", f"{len(mismatched)} field(s) are announced with a name that shares no words with "
                               "the label printed next to them. Speech-input users say the visible label and the field "
                               "will not respond; screen-reader users hear a different name than sighted users see.",
                               page=page, bbox=_union([w for w, _, _ in mismatched]),
                               evidence=[f"label “{lab}” → announced as “{n}”" for _, n, lab in mismatched[:6]],
                               wcag=["2.5.3", "1.3.1", "4.1.2"]))
        if untagged:
            out.append(Finding("widget-untagged", "Form fields are not in the structure tree", "error", "high",
                               f"{len(untagged)} field(s) are not referenced from a <Form> element, so their position in "
                               "the reading order is undefined.", page=page, bbox=_union(untagged),
                               evidence=_names(untagged), matterhorn=["28-010"], wcag=["1.3.1", "4.1.2"],
                               machine_checkable=True))
        links = [x for x in visible if x.subtype == "Link"]
        if tagged:
            bad_links = [x for x in links if x.ref is not None and refd.get(x.ref.num) != "Link"]
            if bad_links:
                out.append(Finding("link-untagged", "Links are not in a <Link> element", "warning", "high",
                                   f"{len(bad_links)} link annotation(s) are not referenced from a <Link> structure element.",
                                   page=page, bbox=_union(bad_links), matterhorn=["28-011"], wcag=["1.3.1", "2.4.4"],
                                   machine_checkable=True))
        no_contents = [x for x in links if not (x.contents or "").strip()]
        if no_contents:
            out.append(Finding("link-contents", "Links have no alternate description", "notice", "high",
                               f"{len(no_contents)} link annotation(s) have no /Contents description.", page=page,
                               bbox=_union(no_contents), matterhorn=["28-012"], wcag=["2.4.4"], machine_checkable=True))
        out += _tab_order(a, page, widgets)
    return out


def _tab_order(a: Analysis, page: int, widgets) -> list[Finding]:
    """Compare the structure order of fields with their visual order (28-001)."""
    order = []
    pos = {}
    for n in a.tree.nodes:
        if n.type != "Form":
            continue
        for c in n.children:
            if isinstance(c, ObjRef) and hasattr(c.obj, "num"):
                pos.setdefault(c.obj.num, len(pos))
    for w in widgets:
        if w.ref is not None and w.ref.num in pos:
            order.append((pos[w.ref.num], w))
    if len(order) < 3:
        return []
    order.sort(key=lambda t: t[0])
    boxes = [w.rect for _, w in order]
    res = assess(boxes, [False] * len(boxes), a.body_size)
    if res is None or res.severity == "notice":
        return []
    names = [(w.tooltip or w.name or "field") for _, w in order]
    return [Finding("field-order", "Form fields are visited in a different order than they appear", "warning",
                    "medium", "Keyboard and screen-reader users move through the fields in structure order, which does "
                    "not follow the layout of the form.", page=page, bbox=_union([order[i][1] for i in res.misplaced]),
                    evidence=["Structure order: " + " → ".join(names[:10]),
                              "Visual order: " + " → ".join(names[i] for i in res.geo[:10])],
                    matterhorn=["28-001"], wcag=["2.4.3", "1.3.2"])]


def _union(anns):
    bb = None
    for x in anns:
        bb = union(bb, x.rect)
    return bb


def _names(anns) -> list[str]:
    return ["Fields: " + ", ".join((x.name or "(unnamed)") for x in anns[:8])]
