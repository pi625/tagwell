"""Check registry. Each check takes an Analysis and returns a list of Findings."""
from __future__ import annotations

from typing import Callable

from ..findings import Finding
from ..model import Analysis
from .artifacts import check_hidden_content, check_running_content
from .figures import check_figures
from .forms import check_forms
from .headings import check_heading_structure, check_visual_headings
from .lists import check_list_syntax, check_visual_lists
from .metadata import check_language, check_security, check_title
from .misc import check_links, check_scanned
from .reading_order import check_reading_order
from .tables import check_tables, check_untagged_tables
from .tagging import check_tagged, check_untagged_content

# (name, function, needs_structure_tree)
CHECKS: list[tuple[str, Callable[[Analysis], list[Finding]], bool]] = [
    ("tagged", check_tagged, False),
    ("scanned", check_scanned, False),
    ("title", check_title, False),
    ("language", check_language, False),
    ("security", check_security, False),
    ("untagged-content", check_untagged_content, True),
    ("reading-order", check_reading_order, True),
    ("heading-structure", check_heading_structure, True),
    ("visual-headings", check_visual_headings, True),
    ("tables", check_tables, True),
    ("untagged-tables", check_untagged_tables, True),
    ("list-syntax", check_list_syntax, True),
    ("visual-lists", check_visual_lists, True),
    ("figures", check_figures, True),
    ("running-content", check_running_content, True),
    ("hidden-content", check_hidden_content, True),
    ("links", check_links, True),
    ("forms", check_forms, False),
]


def run_checks(a: Analysis, only: set[str] | None = None) -> tuple[list[Finding], list[str]]:
    """Run all checks; a crashing check is reported, never fatal."""
    findings: list[Finding] = []
    errors: list[str] = []
    tagged = a.tree.root is not None and bool(a.tree.nodes)
    for name, fn, needs_tree in CHECKS:
        if only and name not in only:
            continue
        if needs_tree and not tagged:
            continue
        try:
            findings += fn(a)
        except Exception as e:  # noqa: BLE001 - one bad check must not hide the others
            errors.append(f"check {name} failed: {type(e).__name__}: {e}")
    return findings, errors
