"""Title (06-003 machine, 06-004 human), DisplayDocTitle (07-001/002), language (11-001 machine,
11-007 human: declared language does not match the text)."""
from __future__ import annotations

import re
from collections import Counter

from ..findings import Finding
from ..model import Analysis

BAD_TITLE = re.compile(
    r"(^microsoft (word|powerpoint|excel)\s*-)|(\.(docx?|pdf|pptx?|xlsx?|rtf|odt|indd|txt)$)|"
    r"^(untitled|document\d*|doc\d*|title|new document|presentation\d*|book\d*|scan\w*|img[_\- ]?\d+)$", re.I)

STOPWORDS = {
    "en": {"the", "and", "of", "to", "in", "is", "for", "that", "with", "on", "are", "be", "this", "by", "will"},
    "es": {"el", "la", "de", "que", "y", "en", "los", "las", "del", "por", "para", "con", "una", "es", "se"},
    "fr": {"le", "la", "les", "de", "des", "et", "est", "en", "du", "pour", "que", "une", "dans", "sur", "pas"},
    "de": {"der", "die", "das", "und", "ist", "nicht", "mit", "von", "den", "zu", "ein", "eine", "auf", "für", "im"},
    "pt": {"o", "a", "os", "as", "de", "do", "da", "que", "e", "em", "para", "com", "não", "uma", "por"},
    "it": {"il", "la", "di", "che", "e", "per", "non", "del", "della", "un", "una", "sono", "con", "gli", "le"},
    "nl": {"de", "het", "een", "en", "van", "is", "dat", "niet", "voor", "met", "op", "zijn", "te", "ook", "aan"},
}
SCRIPTS = [
    ("Cyrillic", 0x0400, 0x04FF), ("Greek", 0x0370, 0x03FF), ("Arabic", 0x0600, 0x06FF),
    ("Hebrew", 0x0590, 0x05FF), ("Devanagari", 0x0900, 0x097F), ("CJK", 0x4E00, 0x9FFF),
    ("Hiragana/Katakana", 0x3040, 0x30FF), ("Hangul", 0xAC00, 0xD7AF), ("Thai", 0x0E00, 0x0E7F),
]
LATIN_LANGS = set(STOPWORDS) | {"fi", "sv", "da", "no", "nb", "pl", "cs", "ro", "hu", "tr", "vi", "id"}


def check_title(a: Analysis) -> list[Finding]:
    out = []
    xmp_title, info_title = a.doc.title()
    title = xmp_title or info_title
    if not title:
        out.append(Finding("title-missing", "Document has no title", "error", "high",
                           "There is no dc:title in the XMP metadata and no /Title in the document info, so readers "
                           "announce the file name instead.", matterhorn=["06-003"], wcag=["2.4.2"],
                           machine_checkable=True))
    else:
        if not xmp_title:
            out.append(Finding("title-xmp", "Title is not in XMP metadata", "warning", "high",
                               "PDF/UA requires the title in the XMP metadata (dc:title); only the legacy /Info "
                               "title is present.", matterhorn=["06-003"], wcag=["2.4.2"], machine_checkable=True))
        if BAD_TITLE.search(title.strip()):
            out.append(Finding("title-quality", "Title does not describe the document", "warning", "high",
                               f"The title “{title}” looks like a file name or a placeholder. Users hear the "
                               "title first and use it to tell documents apart.", matterhorn=["06-004"],
                               wcag=["2.4.2"]))
    vp = a.doc.get(a.doc.catalog, "ViewerPreferences")
    ddt = a.doc.resolve(vp.get("DisplayDocTitle")) if isinstance(vp, dict) else None
    if ddt is not True:
        out.append(Finding("display-doc-title", "Viewer is not told to display the title", "notice", "high",
                           "ViewerPreferences/DisplayDocTitle is " + ("false" if ddt is False else "missing")
                           + ", so the window shows the file name.", matterhorn=["07-001" if ddt is None else "07-002"],
                           wcag=["2.4.2"], machine_checkable=True))
    return out


def _primary(lang: str | None) -> str | None:
    if not lang:
        return None
    return lang.split("-")[0].split("_")[0].strip().lower() or None


def check_language(a: Analysis) -> list[Finding]:
    out = []
    cat_lang = a.doc.resolve(a.doc.catalog.get("Lang"))
    cat_lang = cat_lang.decode_text() if hasattr(cat_lang, "decode_text") else (str(cat_lang) if cat_lang else None)
    if not cat_lang:
        nodes_with_text = [n for n in a.tree.nodes if n.type in ("P", "H1", "H2", "H3", "H4", "H5", "H6", "H", "LI", "TD", "TH")]
        if not nodes_with_text or any(not n.effective_lang() for n in nodes_with_text):
            out.append(Finding("lang-missing", "Document language is not declared", "error", "high",
                               "The catalog has no /Lang, so screen readers pronounce the text with the user's default "
                               "voice, which may be the wrong language.", matterhorn=["11-001"], wcag=["3.1.1"],
                               machine_checkable=True))
    declared = _primary(cat_lang)
    text = " ".join(t.text for pc in a.pages for t in pc.texts if not t.artifact)
    if not declared or len(text) < 200:
        return out
    letters = [c for c in text if c.isalpha()]
    if letters:
        counts = Counter()
        for c in letters:
            o = ord(c)
            for name, lo, hi in SCRIPTS:
                if lo <= o <= hi:
                    counts[name] += 1
                    break
        script, n = counts.most_common(1)[0] if counts else (None, 0)
        if declared in LATIN_LANGS and script and n / len(letters) > 0.3:
            out.append(Finding("lang-mismatch", "Declared language does not match the text", "warning", "high",
                               f"The document declares “{cat_lang}” but {n / len(letters):.0%} of its letters are "
                               f"{script}. A screen reader would read it with the wrong voice.",
                               matterhorn=["11-007"], wcag=["3.1.1"]))
            return out
    words = re.findall(r"[^\W\d_]+", text.lower())
    if len(words) >= 60 and declared in STOPWORDS:
        hits = {lang: sum(1 for w in words if w in sw) / len(words) for lang, sw in STOPWORDS.items()}
        best = max(hits, key=hits.get)
        if best != declared and hits[best] > 0.12 and hits[declared] < hits[best] * 0.4:
            out.append(Finding("lang-mismatch", "Declared language does not match the text", "warning", "medium",
                               f"The document declares “{cat_lang}”, but its common words look like "
                               f"“{best}” ({hits[best]:.0%} vs {hits[declared]:.0%} stop-word rate).",
                               matterhorn=["11-007"], wcag=["3.1.1"]))
    return out


def check_security(a: Analysis) -> list[Finding]:
    """Encryption must not block assistive technology (Matterhorn 26-001/26-002, machine)."""
    crypt = getattr(a.doc, "crypt", None)
    if crypt is None:
        return []
    out = [Finding("encrypted", "Document is encrypted (opens without a password)", "notice", "high",
                   f"The file uses permissions-only encryption (standard security handler, revision {crypt.r}). "
                   "Tagwell decrypted it with the empty user password.", machine_checkable=True)]
    if not crypt.p & (1 << 9):
        out.append(Finding("security-at-access", "Encryption blocks text extraction for assistive technology",
                           "error", "high",
                           "Bit 10 of the permissions (/P) is off, so the file tells screen readers they may not "
                           "extract its text. PDF/UA requires that bit to be set when a file is encrypted.",
                           matterhorn=["26-002"], wcag=["1.3.1", "4.1.2"], machine_checkable=True))
    return out
