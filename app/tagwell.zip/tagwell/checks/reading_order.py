"""Logical reading order versus geometric reading order (Matterhorn 09-001, human condition).

We infer the visual reading order of the page's blocks from layout alone (layout.py) and
compare it with the order of the same blocks in the structure tree. Blocks that are not part
of a longest common ordering are reported as out of place, with the text that a screen-reader
user hears around them. Disagreement is evidence, not proof: some layouts (sidebars, pull
quotes) have more than one valid order, which is why most findings carry medium confidence.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from ..findings import Finding
from ..layout import kendall_tau_distance, longest_increasing_subsequence, reading_orders
from ..model import Analysis, Unit
from .artifacts import MARGIN

MIN_UNITS = 3
# Types whose position is often legitimately flexible (floating elements).
FLOATING = {"Figure", "Caption", "Note", "FENote", "Aside", "Form", "Annot", "Link", "Table"}
# Form pages are dense grids of labels; a handful of local label swaps among 40+ blocks is noise.
FORM_WIDGETS_MIN = 5
FORM_TAU_MAX = 0.05


def _isolated(boxes: list, i: int) -> bool:
    """A block that sits alone in a column of its own (sidebar, pull quote)."""
    x0, _, x1, _ = boxes[i]
    w = max(x1 - x0, 1.0)
    for j, b in enumerate(boxes):
        if j != i and min(x1, b[2]) - max(x0, b[0]) > 0.5 * min(w, b[2] - b[0]):
            return False
    return True


CAPTION_RE = re.compile(r"^\s*(table|figure|fig\.|chart|exhibit|worksheet|map)\s*[0-9A-Z]", re.I)


def _explicit_float(u: Unit) -> bool:
    return (u.type in FLOATING or (u.node is not None and u.node.has_ancestor({"Aside", "Note", "FENote"}))
            or (u.style.lines <= 2 and len(u.text) <= 160 and bool(CAPTION_RE.match(u.text))))


def _table_titles(units: list[Unit], flt: list[bool], body: float) -> list[bool]:
    """Short lines that title a floating table ("Table 4." / "Who Is a Qualifying Person") move with it."""
    out = list(flt)
    for _ in range(2):
        for i, u in enumerate(units):
            if out[i] or u.style.lines > 2 or len(u.text) > 160 or (u.type.startswith("H") and len(u.type) <= 2):
                continue
            for j in (i - 1, i + 1):
                if 0 <= j < len(units) and out[j] and units[j].type in ("Table", "Caption", "P", "(untyped)") \
                        and (units[j].type == "Table" or CAPTION_RE.match(units[j].text)):
                    v = units[j].bbox
                    gap = max(v[1] - u.bbox[3], u.bbox[1] - v[3], 0.0)
                    overlap = min(u.bbox[2], v[2]) - max(u.bbox[0], v[0])
                    if gap <= 3 * body and overlap > 0:
                        out[i] = True
                        break
    return out


def _furniture(u: Unit, page_height: float, body_size: float) -> bool:
    """Small text in the top/bottom margin: running headers, footers, page numbers."""
    cy = (u.bbox[1] + u.bbox[3]) / 2
    in_margin = cy >= page_height * (1 - MARGIN) or cy <= page_height * MARGIN
    small = u.style.size <= body_size * 1.05 and not (u.type.startswith("H") and len(u.type) <= 2)
    return in_margin and small and u.style.lines <= 2 and len(u.text) <= 150 and u.type != "Figure"


def _columns(boxes: list) -> dict[int, int]:
    """Column index for each block (0 = left, 1 = right, -1 = spans), choosing the x position that
    best splits blocks into a left and a right group while tolerating a few spanning blocks."""
    n = len(boxes)
    best, best_score = None, 0
    for c in sorted({b[0] for b in boxes}):
        left = sum(1 for b in boxes if b[2] <= c + 0.5)
        right = sum(1 for b in boxes if b[0] >= c - 0.5)
        cross = n - left - right
        if left >= 2 and right >= 2 and cross <= max(1, n * 0.3) and min(left, right) > best_score:
            best, best_score = c, min(left, right)
    if best is None:
        return {}
    return {i: (0 if b[2] <= best + 0.5 else 1 if b[0] >= best - 0.5 else -1) for i, b in enumerate(boxes)}


@dataclass
class Assessment:
    geo: list[int]
    seq: list[int]
    misplaced: list[int]
    hard: list[int]
    tau: float
    interleaved: bool
    severity: str
    confidence: str
    message: str


def assess(boxes: list, explicit_float: list[bool], body_size: float) -> Assessment | None:
    """Compare logical order (the order of `boxes`) with every plausible visual order.

    Returns None when some plausible reading of the layout agrees with the logical order.
    Pure function of geometry, shared by the check and by external validation harnesses.
    """
    if len(boxes) < MIN_UNITS:
        return None
    floating = [explicit_float[i] or _isolated(boxes, i) for i in range(len(boxes))]
    # When several blocks could equally be "the misplaced one", blame floating elements first.
    weights = [0.6 if f else 1.0 for f in floating]
    best = None
    for geo in reading_orders(boxes, min_gap=max(1.0, body_size * 0.2), min_gutter=max(6.0, body_size * 0.8),
                              rows_small=body_size * 2.6):
        geo_rank = {u_idx: r for r, u_idx in enumerate(geo)}
        seq = [geo_rank[i] for i in range(len(boxes))]  # logical order -> visual rank
        keep = set(longest_increasing_subsequence(seq, weights))
        mis = [i for i in range(len(boxes)) if i not in keep]
        cost = (sum(1 for i in mis if not floating[i]), len(mis))
        if best is None or cost < best[3]:
            best = (geo, seq, mis, cost)
    geo, seq, misplaced, _ = best
    if not misplaced:
        return None
    # Floating elements alone out of place are common and usually acceptable.
    hard = [i for i in misplaced if not floating[i]]
    tau = kendall_tau_distance(seq)
    cols = _columns(boxes)
    interleaved = False
    if cols:
        def switches(order: list[int]) -> int:
            cs = [cols[i] for i in order if cols.get(i, -1) >= 0 and not floating[i]]
            return sum(1 for x, y in zip(cs, cs[1:]) if x != y)
        # Stacked multi-column sections legitimately switch columns; only flag the logical
        # order when it switches far more often than the visual order does.
        interleaved = switches(list(range(len(boxes)))) >= switches(geo) + 2
    if not hard and not interleaved:
        return Assessment(geo, seq, misplaced, hard, tau, False, "notice", "low",
                          "Floating elements (figures, captions, notes, sidebars) are read at a different point "
                          "than where they appear. This is often acceptable; confirm that the order makes sense "
                          "when listening to the page.")
    if interleaved:
        return Assessment(geo, seq, misplaced, hard, tau, True, "error", "high",
                          "The reading order alternates between the page's columns. A screen-reader user will "
                          "hear the first line or paragraph of one column, then the other, rather than each "
                          "column in turn.")
    if tau >= 0.15 or len(hard) >= 3:
        return Assessment(geo, seq, misplaced, hard, tau, False, "error", "medium",
                          "Several blocks are read in a different order than they appear on the page.")
    return Assessment(geo, seq, misplaced, hard, tau, False, "warning", "medium",
                      "Some blocks are read in a different order than they appear on the page.")


def _boxed(units: list[Unit], paths: list, body: float, page_area: float) -> list[bool]:
    """Blocks drawn inside a framed or shaded box (callouts, sidebars): their position in the
    reading order is flexible, like a figure's. Table cell backgrounds and full-page panels are
    excluded by size."""
    boxes = [p.bbox for p in paths
             if (p.stroke or p.fill) and (p.bbox[3] - p.bbox[1]) >= 2.5 * body
             and (p.bbox[2] - p.bbox[0]) * (p.bbox[3] - p.bbox[1]) <= 0.4 * page_area]
    # Word draws a box border as thin filled strips, one per side and line segment.
    bars = [p.bbox for p in paths if (p.stroke or p.fill) and (p.bbox[2] - p.bbox[0]) <= 3
            and (p.bbox[3] - p.bbox[1]) >= body]
    out = []
    for u in units:
        x0, y0, x1, y1 = u.bbox
        def holds(b, v) -> bool:
            return b[0] - 2 <= v[0] and b[1] - 2 <= v[1] and v[2] <= b[2] + 2 and v[3] <= b[3] + 2
        # A box framing this block and no other block: a callout. (A shaded panel holding a whole
        # section frames several blocks and says nothing about reading order.)
        inside = [b for b in boxes if holds(b, u.bbox)
                  and not any(w is not u and w.text.strip() and holds(b, w.bbox) for w in units)]

        def side(lo: float, hi: float) -> bool:
            return any(lo <= b[0] <= hi and min(b[3], y1) - max(b[1], y0) > 0 for b in bars)
        framed = side(x0 - 14, x0 + 2) and side(x1 - 2, x1 + 14)
        # A pull-quote or note marked by a single bar down its left side.
        framed = framed or any(x0 - 20 <= b[0] <= x0 - 1 and b[1] <= y0 + body and b[3] >= y1 - body for b in bars)
        out.append((bool(inside) or framed) and u.style.lines >= 2)
    return out


def check_reading_order(a: Analysis) -> list[Finding]:
    out: list[Finding] = []
    widgets: dict[int, int] = {}
    for an in a.annotations:
        if an.subtype == "Widget":
            widgets[an.page] = widgets.get(an.page, 0) + 1
    for page, units in sorted(a.units_by_page.items()):
        pc = a.pages[page] if page < len(a.pages) else None
        h = pc.height if pc is not None else 792
        # Page furniture (running headers, page numbers) is judged by the artifacts check;
        # including it here would double-report the same defect as a reading-order problem.
        # Rotated text (landscape tables on portrait pages) has no left-to-right line order to infer.
        units = [u for u in units if (u.text.strip() or u.type == "Figure") and not _furniture(u, h, a.body_size)
                 and not u.rotated]
        boxed = _boxed(units, pc.paths if pc is not None else [], a.body_size,
                       (pc.width * pc.height) if pc is not None else 612 * 792)
        flt = _table_titles(units, [_explicit_float(u) or boxed[i] for i, u in enumerate(units)], a.body_size)
        res = assess([u.bbox for u in units], flt, a.body_size)
        if res is None:
            continue
        if widgets.get(page, 0) >= FORM_WIDGETS_MIN and res.tau < FORM_TAU_MAX:
            res.severity, res.confidence = "notice", "low"
            res.message = ("A few labels on this form page are read in a slightly different order than they "
                           "appear. On dense forms this is often harmless; check that each label is read next "
                           "to its field.")
        out.append(_finding(a, page, units, res.misplaced, res.geo, res.tau, res.severity, res.confidence,
                            res.message))
    return out


def _finding(a: Analysis, page: int, units: list[Unit], misplaced: list[int], geo: list[int], tau: float,
             sev: str, conf: str, msg: str) -> Finding:
    evidence = []
    geo_pos = {u: r for r, u in enumerate(geo)}
    for i in misplaced[:6]:
        u = units[i]
        g = geo_pos[i]
        before = units[geo[g - 1]].snippet(40) if g > 0 else None
        where = f"visually it comes after “{before}”" if before else "visually it comes first on the page"
        evidence.append(f"“{u.snippet(50)}” ({u.type}) is read as block {i + 1} of {len(units)}, "
                        f"but {where}.")
    if len(misplaced) > 6:
        evidence.append(f"…and {len(misplaced) - 6} more block(s).")
    evidence.append("Logical order: " + " → ".join(f"“{units[i].snippet(18)}”" for i in range(min(len(units), 8)))
                    + (" …" if len(units) > 8 else ""))
    evidence.append("Visual order: " + " → ".join(f"“{units[i].snippet(18)}”" for i in geo[:8])
                    + (" …" if len(units) > 8 else ""))
    bb = None
    for i in misplaced:
        b = units[i].bbox
        bb = b if bb is None else (min(bb[0], b[0]), min(bb[1], b[1]), max(bb[2], b[2]), max(bb[3], b[3]))
    f = Finding("reading-order", "Reading order does not match the visual layout", sev, conf,
                msg + f" (order disagreement: {tau:.0%} of block pairs).", page=page, bbox=bb,
                evidence=evidence, matterhorn=["09-001"], wcag=["1.3.2", "2.4.3"])
    f.related_boxes = [units[i].bbox for i in misplaced]
    return f
