"""Tagging coverage: is the content in the structure tree at all? (Matterhorn 01)."""
from __future__ import annotations

from collections import defaultdict

from ..findings import Finding
from ..model import Analysis
from ..pdf.content import union
from ..pdf.structure import MCRef


def check_tagged(a: Analysis) -> list[Finding]:
    out = []
    mark = a.doc.get(a.doc.catalog, "MarkInfo")
    marked = isinstance(mark, dict) and a.doc.resolve(mark.get("Marked")) is True
    if a.tree.root is None or not a.tree.nodes:
        out.append(Finding(
            "untagged-document", "Document is not tagged", "error", "high",
            "The PDF has no structure tree, so assistive technology has to guess the reading "
            "order and cannot identify headings, lists, tables or figures.",
            matterhorn=["01-005"], wcag=["1.3.1"], machine_checkable=True))
    elif not marked:
        out.append(Finding(
            "markinfo", "MarkInfo /Marked is not true", "warning", "high",
            "The document has a structure tree but does not declare itself as tagged "
            "(/MarkInfo << /Marked true >>). Some readers will ignore the tags.",
            matterhorn=["01-005"], wcag=["1.3.1"], machine_checkable=True))
    if a.tree.unknown_types:
        out.append(Finding(
            "unmapped-types", "Non-standard structure types without a role mapping", "warning", "high",
            "These element types are not standard and are not role-mapped to a standard type, so "
            "assistive technology cannot interpret them: " + ", ".join(sorted(a.tree.unknown_types)),
            matterhorn=["02-001"], wcag=["1.3.1"], machine_checkable=True))
    return out


def check_untagged_content(a: Analysis) -> list[Finding]:
    """Visible content that is neither tagged nor an artifact (01-005), and tagged content
    that the structure tree never references (orphans)."""
    if a.tree.root is None:
        return []
    out = []
    referenced: set[tuple[int | None, int | None, int]] = set()
    for n in a.tree.nodes:
        for c in n.children:
            if isinstance(c, MCRef):
                referenced.add((c.page, c.stm, c.mcid))
    for pc in a.pages:
        untagged = [t for t in pc.texts if t.mcid is None and not t.artifact and t.text.strip()]
        if untagged:
            chars = sum(len(t.text.strip()) for t in untagged)
            bb = None
            for t in untagged:
                bb = union(bb, t.bbox)
            sample = "; ".join(sorted({" ".join(t.text.split())[:40] for t in untagged})[:3])
            out.append(Finding(
                "untagged-text", "Text is neither tagged nor marked as an artifact", "error", "high",
                f"{chars} characters of visible text on this page are outside the structure tree. "
                "Screen readers may skip them or read them out of order.",
                page=pc.page, bbox=bb, evidence=[f"Examples: {sample}"],
                matterhorn=["01-005"], wcag=["1.3.1"], machine_checkable=True))
        imgs = [i for i in pc.images if i.mcid is None and not i.artifact]
        if imgs:
            bb = None
            for i in imgs:
                bb = union(bb, i.bbox)
            out.append(Finding(
                "untagged-image", "Image is neither tagged nor marked as an artifact", "error", "high",
                f"{len(imgs)} image(s) on this page are outside the structure tree. Meaningful "
                "images need a <Figure> with alternative text; decorative ones should be artifacts.",
                page=pc.page, bbox=bb, matterhorn=["01-005", "13-001"], wcag=["1.1.1"],
                machine_checkable=True))
        orphans: dict[int, list] = defaultdict(list)
        for item in (*pc.texts, *pc.images):
            if item.mcid is not None and not item.artifact and (pc.page, item.stm, item.mcid) not in referenced:
                orphans[item.mcid].append(item)
        if orphans:
            chars = sum(len(t.text.strip()) for v in orphans.values() for t in v if hasattr(t, "text"))
            bb = None
            for v in orphans.values():
                for t in v:
                    bb = union(bb, t.bbox)
            out.append(Finding(
                "orphan-content", "Marked content is not referenced by any structure element", "error", "high",
                f"{len(orphans)} marked-content sequence(s) ({chars} characters) carry an MCID that no "
                "structure element points to, so they are effectively untagged.",
                page=pc.page, bbox=bb, evidence=[f"MCIDs: {sorted(orphans)[:12]}"],
                matterhorn=["01-005"], wcag=["1.3.1"], machine_checkable=True))
    seen = {(pc.page, mcid) for pc in a.pages for (_, mcid) in pc.mcids_seen}
    # Dangling = the MCID never occurs on that page. A sequence that exists but draws nothing (a
    # clipping path, an empty span) is harmless to assistive technology and is not reported.
    dangling = [(pg, mcid) for (pg, stm, mcid) in referenced
                if pg is not None and not a.content_by_ref.get((pg, stm, mcid))
                and not any(k[0] == pg and k[2] == mcid for k in a.content_by_ref)
                and (pg, mcid) not in seen]
    if dangling:
        pages = sorted({pg for pg, _ in dangling})
        out.append(Finding(
            "dangling-mcid", "Structure elements point at content that does not exist", "warning", "medium",
            f"{len(dangling)} marked-content reference(s) in the structure tree do not occur in "
            f"the content of page(s) {', '.join(str(p + 1) for p in pages[:10])}. The tags describe content "
            "that was deleted or never drawn.",
            matterhorn=["01-006"], wcag=["1.3.1"]))
    return out
