"""Page furniture tagged as content (01-001) and real content hidden as artifacts (01-002).
Both are human conditions in Matterhorn; we detect them from position and repetition."""
from __future__ import annotations

import re
from collections import defaultdict

from ..findings import Finding
from ..model import Analysis

MARGIN = 0.10  # top/bottom fraction of the page treated as header/footer zone
_DIGITS = re.compile(r"\d+")


def _norm(text: str) -> str:
    return _DIGITS.sub("#", " ".join(text.split()).lower())


def check_running_content(a: Analysis) -> list[Finding]:
    """Headers, footers and page numbers repeated on several pages but tagged as real content."""
    n_pages = len(a.pages)
    if n_pages < 2:
        return []
    groups: dict[tuple[str, str, int], list] = defaultdict(list)
    for page, units in a.units_by_page.items():
        h = a.pages[page].height or 792
        for u in units:
            if not u.text.strip() or u.style.lines > 2 or len(u.text) > 150 or u.rotated:
                continue
            if u.node is not None and (u.node.type in ("Table", "TR", "TD", "TH")
                                       or u.node.has_ancestor({"Table"})):
                continue  # repeated values in a table that runs over several pages
            if u.style.size > a.body_size * 1.15:
                continue  # large text at the top of each page is a heading, not a running header
            cy = (u.bbox[1] + u.bbox[3]) / 2
            zone = "top" if cy >= h * (1 - MARGIN) else ("bottom" if cy <= h * MARGIN else None)
            if zone is None:
                continue
            groups[(zone, _norm(u.text), int(round(cy / 4.0)))].append(u)
    out = []
    need = 2 if n_pages <= 3 else 3
    for (zone, text, _), us in groups.items():
        pages = sorted({u.page for u in us})
        if len(pages) < need:
            continue
        is_page_no = bool(re.fullmatch(r"(page\s*)?#(\s*(of|/)\s*#)?", text))
        what = "page number" if is_page_no else ("running header" if zone == "top" else "running footer")
        out.append(Finding(
            "furniture-tagged", f"Repeated {what} is tagged as real content", "warning", "high" if len(pages) >= 3 else "medium",
            f"“{us[0].snippet(50)}” appears at the same place on {len(pages)} pages and is tagged as "
            f"<{us[0].type}>. Screen readers will read it on every page; it should be an artifact.",
            page=pages[0], bbox=us[0].bbox, element=us[0].type,
            evidence=[f"Pages: {', '.join(str(p + 1) for p in pages[:12])}"],
            matterhorn=["01-001"], wcag=["1.3.1"]))
    return out


def check_hidden_content(a: Analysis) -> list[Finding]:
    """Substantial body-area text marked as an artifact, i.e. hidden from assistive technology."""
    out = []
    for pc in a.pages:
        h = pc.height or 792
        body = [t for t in pc.texts if t.artifact and not t.invisible
                and h * MARGIN < (t.bbox[1] + t.bbox[3]) / 2 < h * (1 - MARGIN)
                and (t.artifact_kind or "") not in ("Watermark", "Background")]
        chars = sum(len(t.text.strip()) for t in body)
        if chars >= 80:
            bb = body[0].bbox
            for t in body[1:]:
                bb = (min(bb[0], t.bbox[0]), min(bb[1], t.bbox[1]), max(bb[2], t.bbox[2]), max(bb[3], t.bbox[3]))
            sample = " ".join(" ".join(t.text.split()) for t in body)[:90]
            out.append(Finding(
                "content-as-artifact", "Body text is marked as an artifact", "error", "medium",
                f"{chars} characters of text in the body of the page are marked as artifacts, which hides them "
                "from screen readers. Artifacts are for decoration and page furniture only.",
                page=pc.page, bbox=bb, evidence=[f"“{sample}…”"],
                matterhorn=["01-002"], wcag=["1.3.1"]))
    return out
