"""Page furniture tagged as content (01-001) and real content hidden as artifacts (01-002).
Both are human conditions in Matterhorn; we detect them from position and repetition."""
from __future__ import annotations

import re
from collections import defaultdict

from ..findings import Finding
from ..model import Analysis

MARGIN = 0.10  # top/bottom fraction of the page treated as header/footer zone
_DIGITS = re.compile(r"\d+")


def _norm(text: str) -> str:
    return _DIGITS.sub("#", " ".join(text.split()).lower())


def check_running_content(a: Analysis) -> list[Finding]:
    """Headers, footers and page numbers repeated on several pages but tagged as real content."""
    n_pages = len(a.pages)
    if n_pages < 2:
        return []
    groups: dict[tuple[str, str, int], list] = defaultdict(list)
    for page, units in a.units_by_page.items():
        h = a.pages[page].height or 792
        for u in units:
            if not u.text.strip() or u.style.lines > 2 or len(u.text) > 150 or u.rotated:
                continue
            if u.node is not None and (u.node.type in ("Table", "TR", "TD", "TH")
                                       or u.node.has_ancestor({"Table"})):
                continue  # repeated values in a table that runs over several pages
            if u.style.size > a.body_size * 1.15:
                continue  # large text at the top of each page is a heading, not a running header
            cy = (u.bbox[1] + u.bbox[3]) / 2
            zone = "top" if cy >= h * (1 - MARGIN) else ("bottom" if cy <= h * MARGIN else None)
            if zone is None:
                continue
            groups[(zone, _norm(u.text), int(round(cy / 4.0)))].append(u)
    out = []
    need = 2 if n_pages <= 3 else 3
    for (zone, text, _), us in groups.items():
        pages = sorted({u.page for u in us})
        if len(pages) < need:
            continue
        is_page_no = bool(re.fullmatch(r"(page\s*)?#(\s*(of|/)\s*#)?", text))
        what = "page number" if is_page_no else ("running header" if zone == "top" else "running footer")
        out.append(Finding(
            "furniture-tagged", f"Repeated {what} is tagged as real content", "warning", "high" if len(pages) >= 3 else "medium",
            f"“{us[0].snippet(50)}” appears at the same place on {len(pages)} pages and is tagged as "
            f"<{us[0].type}>. Screen readers will read it on every page; it should be an artifact.",
            page=pages[0], bbox=us[0].bbox, element=us[0].type,
            evidence=[f"Pages: {', '.join(str(p + 1) for p in pages[:12])}"],
            matterhorn=["01-001"], wcag=["1.3.1"]))
    return out


LEADER_RE = re.compile(r"[.\-_\u00b7\u2026 ]{3,}")  # dot leaders and rules


def _words(s: str) -> list[str]:
    return re.findall(r"[^\W_]+", s.lower())


def _tagged_copies(pc) -> list[tuple]:
    return [(u, re.sub(r"\W+", "", u.text).lower(), set(_words(u.text)))
            for u in pc.texts if not u.artifact and u.text.strip()]


def _overlaid_copy(t, real) -> bool:
    """True when the same text is also tagged: drawn at the same place (an OCR layer or an overlay
    copy), or anywhere in an invisible tagged reading layer, whose boxes are often unreliable.
    Hiding such a copy hides nothing from assistive technology. Small wording differences between
    the two copies are allowed (80% of the words)."""
    key = re.sub(r"\W+", "", t.text).lower()
    words = _words(t.text)
    area = max((t.bbox[2] - t.bbox[0]) * (t.bbox[3] - t.bbox[1]), 1e-6)
    for u, other, uwords in real:
        same_words = bool(words) and sum(w in uwords for w in words) >= 0.8 * len(words)
        if u.invisible and same_words:
            return True
        ix = min(t.bbox[2], u.bbox[2]) - max(t.bbox[0], u.bbox[0])
        iy = min(t.bbox[3], u.bbox[3]) - max(t.bbox[1], u.bbox[1])
        if ix > 0 and iy > 0 and ix * iy >= 0.5 * area:
            if same_words or key and (key in other or other in key):
                return True
    return False


def check_hidden_content(a: Analysis) -> list[Finding]:
    """Substantial body-area text marked as an artifact, i.e. hidden from assistive technology."""
    out = []
    for pc in a.pages:
        h = pc.height or 792
        real = _tagged_copies(pc)
        body = [t for t in pc.texts if t.artifact and not t.invisible
                and h * MARGIN < (t.bbox[1] + t.bbox[3]) / 2 < h * (1 - MARGIN)
                and (t.artifact_kind or "") not in ("Watermark", "Background")
                and re.search(r"[^\W_]", t.text)  # leader dots and rules are rightly artifacts
                and not _overlaid_copy(t, real)]
        chars = sum(len(LEADER_RE.sub("", t.text).strip()) for t in body)
        if chars >= 80:
            bb = body[0].bbox
            for t in body[1:]:
                bb = (min(bb[0], t.bbox[0]), min(bb[1], t.bbox[1]), max(bb[2], t.bbox[2]), max(bb[3], t.bbox[3]))
            sample = " ".join(" ".join(t.text.split()) for t in body)[:90]
            out.append(Finding(
                "content-as-artifact", "Body text is marked as an artifact", "error", "medium",
                f"{chars} characters of text in the body of the page are marked as artifacts, which hides them "
                "from screen readers. Artifacts are for decoration and page furniture only.",
                page=pc.page, bbox=bb, evidence=[f"“{sample}…”"],
                matterhorn=["01-002"], wcag=["1.3.1"]))
    return out
