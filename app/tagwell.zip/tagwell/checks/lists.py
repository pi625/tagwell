"""Lists: syntax (09-005, machine) and visual lists not tagged as lists (16-003, 16-001; human)."""
from __future__ import annotations

import re

from ..findings import Finding
from ..model import Analysis, Unit
from ..pdf.content import union

BULLET_RE = re.compile(r"^\s*([•●○▪■◦‣⁃∙·–—➢✓✔*\-−])\s+\S")
DASH_RE = re.compile(r"^\s*[–—\-−]\s")
ENUM_RE = re.compile(r"^\s*(\(?\d{1,3}[.)]|\(?[a-z][.)]|\(?[ivxlc]{1,5}[.)]|[A-Z][.)])\s+\S")


def _marker(text: str) -> str | None:
    if BULLET_RE.match(text):
        return "bullet"
    if ENUM_RE.match(text):
        return "number"
    return None


def check_list_syntax(a: Analysis) -> list[Finding]:
    out = []
    for l in a.tree.by_type("L"):
        bad = sorted({c.type for c in l.node_children() if c.type not in ("LI", "L", "Caption")})
        bad_li = sorted({c.type for li in l.node_children() if li.type == "LI"
                         for c in li.node_children() if c.type not in ("Lbl", "LBody")})
        if bad or bad_li:
            pages = a.node_pages(l)
            out.append(Finding("list-syntax", "List structure is malformed", "warning", "high",
                               "<L> should contain <LI> items, and each <LI> should contain <Lbl> and/or <LBody>. "
                               "Found: " + ", ".join(bad + bad_li),
                               page=pages[0] if pages else l.page, bbox=a.node_bbox(l), element="L",
                               matterhorn=["09-005"], wcag=["1.3.1"], machine_checkable=True))
        numbering = l.attrs.get("ListNumbering")
        labels = [a.node_text(c) for li in l.node_children() if li.type == "LI" for c in li.node_children()
                  if c.type == "Lbl"]
        if labels and all(ENUM_RE.match(x + " x") for x in labels) and (numbering in (None, "None")):
            pages = a.node_pages(l)
            out.append(Finding("list-numbering", "Numbered list has no ListNumbering", "notice", "medium",
                               "The list labels are numbers or letters, but the list does not declare a numbering "
                               "style, so assistive technology may not announce it as an ordered list.",
                               page=pages[0] if pages else l.page, bbox=a.node_bbox(l), element="L",
                               matterhorn=["16-001"], wcag=["1.3.1"]))
    return out


def check_visual_lists(a: Analysis) -> list[Finding]:
    out = []
    flagged: set[int] = set()
    for page, units in sorted(a.units_by_page.items()):
        run: list[Unit] = []
        kind = None

        def flush() -> None:
            nonlocal run
            if len(run) >= 2:
                flagged.update(id(u) for u in run)
                bb = None
                for u in run:
                    bb = union(bb, u.bbox)
                out.append(Finding(
                    "visual-list", "Text looks like a list but is not tagged as one", "warning",
                    "high" if len(run) >= 3 else "medium",
                    f"{len(run)} consecutive blocks start with {'bullets' if kind == 'bullet' else 'numbers'} but "
                    f"are tagged <{run[0].node.raw_type if run[0].node else 'untyped'}>, not <L>/<LI>. "
                    "Screen readers will not announce a list or its length.",
                    page=page, bbox=bb, element=run[0].type,
                    evidence=[f"“{u.snippet(50)}”" for u in run[:4]],
                    matterhorn=["16-003"], wcag=["1.3.1"]))
            run = []

        for u in units:
            in_list = u.node is not None and (u.node.type in ("LI", "Lbl", "LBody", "TOCI", "TOC")
                                              or u.node.has_ancestor({"L", "TOC", "TOCI"}))
            m = None if in_list else _marker(u.text)
            if m and (kind is None or m == kind):
                run.append(u)
                kind = m
                continue
            flush()
            kind = None
            if m:
                run = [u]
                kind = m
        flush()
        # A single paragraph containing several bulleted lines.
        for u in units:
            if u.node is None or id(u) in flagged or u.node.has_ancestor({"L", "Table", "TOC"}) \
                    or u.node.type in ("LI", "L", "Table", "TOC", "TOCI"):
                continue  # numbered criteria in table cells are table content, not an untagged list
            # A dash that starts a line inside a paragraph is usually a wrapped parenthetical dash
            # ("... – including ..."), so only bullet glyphs and numbers count here.
            starts = [r for r in u.runs if _marker(r.text) and not DASH_RE.match(r.text)]
            if len(starts) >= 2 and u.style.lines >= 2:
                out.append(Finding(
                    "visual-list", "Several bulleted lines are tagged as one paragraph", "warning", "medium",
                    f"“{u.snippet(60)}” contains {len(starts)} lines that start with list markers, all "
                    f"inside one <{u.node.raw_type}>.", page=page, bbox=u.bbox, element=u.type,
                    matterhorn=["16-003"], wcag=["1.3.1"]))
    return out


HIDDEN_NUM_RE = re.compile(r"^\(?(\d{1,3}|[a-z]|[ivxlc]{1,5}|[A-Z])[.)]\)?$")


def check_toc_syntax(a: Analysis) -> list[Finding]:
    """A <TOC> must contain <TOCI> entries (or nested <TOC>/<Caption>) (09-006, machine)."""
    out = []
    for t in a.tree.by_type("TOC"):
        if t.parent is not None and t.parent.type == "TOCI":
            continue  # nested TOC inside an entry: judged with its parent
        bad = sorted({c.type for c in t.node_children() if c.type not in ("TOCI", "TOC", "Caption")})
        if bad:
            for page in a.node_pages(t) or [t.page]:
                out.append(Finding("toc-syntax", "Table of contents is not tagged as TOC entries", "warning", "high",
                                   "<TOC> should contain one <TOCI> per entry. Here it contains " + ", ".join(bad)
                                   + ", so screen readers cannot present it as a table of contents.",
                                   page=page, bbox=a.node_bbox(t, page) if page is not None else None, element="TOC",
                                   matterhorn=["09-006"], wcag=["1.3.1"], machine_checkable=True))
    return out


def check_hidden_list_numbers(a: Analysis) -> list[Finding]:
    """Numbered lists whose numbers are drawn as artifacts, with no <Lbl> and no ListNumbering:
    the numbers exist only visually, so screen readers announce an unnumbered list (16-001)."""
    out = []
    by_page_art: dict[int, list] = {}
    for pc in a.pages:
        by_page_art[pc.page] = [t for t in pc.texts if t.artifact and HIDDEN_NUM_RE.match(t.text.strip() or "x")]
    for l in a.tree.by_type("L"):
        items = [li for li in l.node_children() if li.type == "LI"]
        if len(items) < 2 or l.attrs.get("ListNumbering") not in (None, "None"):
            continue
        if any(c.type == "Lbl" for li in items for c in li.node_children()):
            continue
        hidden: dict[int, list] = {}
        for li in items:
            runs = sorted(a.node_runs(li), key=lambda r: r.seq)
            runs = [r for r in runs if r.text.strip()]
            if not runs:
                continue
            first = runs[0]
            size = max(first.size, 1.0)
            for t in by_page_art.get(first.page, []):
                same_line = min(t.bbox[3], first.bbox[3]) - max(t.bbox[1], first.bbox[1]) > 0.4 * size
                if same_line and t.bbox[2] <= first.bbox[0] + 1 and first.bbox[0] - t.bbox[2] < 5 * size:
                    hidden.setdefault(first.page, []).append((li, t.text.strip()))
                    break
        found = sum(len(v) for v in hidden.values())
        if found < 2 or found < 0.6 * len(items):
            continue
        for page, hits in sorted(hidden.items()):
            bb = None
            for li, _ in hits:
                b = a.node_bbox(li, page)
                if b is not None:
                    bb = b if bb is None else (min(bb[0], b[0]), min(bb[1], b[1]), max(bb[2], b[2]), max(bb[3], b[3]))
            out.append(Finding("list-numbers-hidden", "List numbers are hidden from screen readers", "warning", "high",
                               f"This numbered list shows {', '.join(x for _, x in hits[:4])}{'…' if len(hits) > 4 else ''} on "
                               "the page, but the numbers are artifacts, the items have no <Lbl> and the list has no "
                               "ListNumbering. A screen reader announces an unnumbered list, so references such as "
                               "\u201citem 3\u201d cannot be followed.", page=page, bbox=bb, element="L",
                               matterhorn=["16-001"], wcag=["1.3.1"]))
    return out

