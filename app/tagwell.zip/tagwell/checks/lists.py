"""Lists: syntax (09-005, machine) and visual lists not tagged as lists (16-003, 16-001; human)."""
from __future__ import annotations

import re

from ..findings import Finding
from ..model import Analysis, Unit
from ..pdf.content import union

BULLET_RE = re.compile(r"^\s*([•●○▪■◦‣⁃∙·–—➢✓✔*\-−])\s+\S")
DASH_RE = re.compile(r"^\s*[–—\-−]\s")
ENUM_RE = re.compile(r"^\s*(\(?\d{1,3}[.)]|\(?[a-z][.)]|\(?[ivxlc]{1,5}[.)]|[A-Z][.)])\s+\S")


def _marker(text: str) -> str | None:
    if BULLET_RE.match(text):
        return "bullet"
    if ENUM_RE.match(text):
        return "number"
    return None


def check_list_syntax(a: Analysis) -> list[Finding]:
    out = []
    for l in a.tree.by_type("L"):
        bad = sorted({c.type for c in l.node_children() if c.type not in ("LI", "L", "Caption")})
        bad_li = sorted({c.type for li in l.node_children() if li.type == "LI"
                         for c in li.node_children() if c.type not in ("Lbl", "LBody")})
        if bad or bad_li:
            pages = a.node_pages(l)
            out.append(Finding("list-syntax", "List structure is malformed", "warning", "high",
                               "<L> should contain <LI> items, and each <LI> should contain <Lbl> and/or <LBody>. "
                               "Found: " + ", ".join(bad + bad_li),
                               page=pages[0] if pages else l.page, bbox=a.node_bbox(l), element="L",
                               matterhorn=["09-005"], wcag=["1.3.1"], machine_checkable=True))
        numbering = l.attrs.get("ListNumbering")
        labels = [a.node_text(c) for li in l.node_children() if li.type == "LI" for c in li.node_children()
                  if c.type == "Lbl"]
        if labels and all(ENUM_RE.match(x + " x") for x in labels) and (numbering in (None, "None")):
            pages = a.node_pages(l)
            out.append(Finding("list-numbering", "Numbered list has no ListNumbering", "notice", "medium",
                               "The list labels are numbers or letters, but the list does not declare a numbering "
                               "style, so assistive technology may not announce it as an ordered list.",
                               page=pages[0] if pages else l.page, bbox=a.node_bbox(l), element="L",
                               matterhorn=["16-001"], wcag=["1.3.1"]))
    return out


def check_visual_lists(a: Analysis) -> list[Finding]:
    out = []
    flagged: set[int] = set()
    for page, units in sorted(a.units_by_page.items()):
        run: list[Unit] = []
        kind = None

        def flush() -> None:
            nonlocal run
            if len(run) >= 2:
                flagged.update(id(u) for u in run)
                bb = None
                for u in run:
                    bb = union(bb, u.bbox)
                out.append(Finding(
                    "visual-list", "Text looks like a list but is not tagged as one", "warning",
                    "high" if len(run) >= 3 else "medium",
                    f"{len(run)} consecutive blocks start with {'bullets' if kind == 'bullet' else 'numbers'} but "
                    f"are tagged <{run[0].node.raw_type if run[0].node else 'untyped'}>, not <L>/<LI>. "
                    "Screen readers will not announce a list or its length.",
                    page=page, bbox=bb, element=run[0].type,
                    evidence=[f"“{u.snippet(50)}”" for u in run[:4]],
                    matterhorn=["16-003"], wcag=["1.3.1"]))
            run = []

        for u in units:
            in_list = u.node is not None and (u.node.type in ("LI", "Lbl", "LBody", "TOCI", "TOC")
                                              or u.node.has_ancestor({"L", "TOC", "TOCI"}))
            m = None if in_list else _marker(u.text)
            if m and (kind is None or m == kind):
                run.append(u)
                kind = m
                continue
            flush()
            kind = None
            if m:
                run = [u]
                kind = m
        flush()
        # A single paragraph containing several bulleted lines.
        for u in units:
            if u.node is None or id(u) in flagged or u.node.has_ancestor({"L", "Table", "TOC"}) \
                    or u.node.type in ("LI", "L", "Table", "TOC", "TOCI"):
                continue  # numbered criteria in table cells are table content, not an untagged list
            # A dash that starts a line inside a paragraph is usually a wrapped parenthetical dash
            # ("... – including ..."), so only bullet glyphs and numbers count here.
            starts = [r for r in u.runs if _marker(r.text) and not DASH_RE.match(r.text)]
            if len(starts) >= 2 and u.style.lines >= 2:
                out.append(Finding(
                    "visual-list", "Several bulleted lines are tagged as one paragraph", "warning", "medium",
                    f"“{u.snippet(60)}” contains {len(starts)} lines that start with list markers, all "
                    f"inside one <{u.node.raw_type}>.", page=page, bbox=u.bbox, element=u.type,
                    matterhorn=["16-003"], wcag=["1.3.1"]))
    return out
