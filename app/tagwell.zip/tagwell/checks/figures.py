"""Figures and alternative text: presence (13-004, machine) and quality (WCAG 1.1.1, human)."""
from __future__ import annotations

import re
from collections import Counter

from ..findings import Finding
from ..model import Analysis
from ..pdf.structure import ObjRef

FILENAME_RE = re.compile(r"\.(png|jpe?g|gif|bmp|tiff?|emf|wmf|svg|webp|heic)\b", re.I)
CAMERA_RE = re.compile(r"^(img|dsc|dscn|pxl|image|photo|screenshot|scan)[\s_\-]?\d+", re.I)
GENERIC = {"image", "picture", "graphic", "photo", "photograph", "figure", "logo", "icon", "chart",
           "diagram", "img", "alt", "alt text", "untitled", "placeholder", "spacer", "decorative",
           "graph", "map", "illustration", "banner", "screenshot", "table"}
# Office's automatic descriptions: "Arrow Up with solid fill", "A picture containing text...",
# "... Description automatically generated".
AUTO_ALT = re.compile(r"\bwith solid fill\b|\boutline\s*$|description automatically generated|"
                      r"^a picture containing\b|^graphical user interface\b", re.I)
REDUNDANT_PREFIX = re.compile(r"^(an?\s+)?(image|picture|photo|graphic)\s+of\b", re.I)


def check_figures(a: Analysis) -> list[Finding]:
    out: list[Finding] = []
    figures = a.tree.by_type("Figure")
    alts = Counter((n.alt or "").strip().lower() for n in figures if (n.alt or "").strip())
    # The same alt text on the same repeated icon ("Tip", "Caution") is correct. Only a shared
    # alt text on visibly different figures is suspicious; figures are compared by drawn size.
    shapes: dict[str, set] = {}
    pictures: dict[str, set] = {}  # the image XObjects each figure draws
    for n in figures:
        k = (n.alt or "").strip().lower()
        bb = a.node_bbox(n)
        if k and bb is not None:
            pics = frozenset(im.xobj for im in a.node_images(n) if im.xobj is not None)
            if pics:
                pictures.setdefault(k, set()).add(pics)
            shapes.setdefault(k, set()).add((bb[2] - bb[0], bb[3] - bb[1]))
    for n in figures:
        pages = a.node_pages(n)
        page = pages[0] if pages else n.page
        bb = a.node_bbox(n)
        alt = (n.alt or "").strip()
        if not alt and not (n.actual_text or "").strip():
            out.append(Finding("figure-alt-missing", "Figure has no alternative text", "error", "high",
                               "This <Figure> has neither /Alt nor /ActualText, so screen-reader users get nothing.",
                               page=page, bbox=bb, element="Figure", matterhorn=["13-004"], wcag=["1.1.1"],
                               machine_checkable=True))
            continue
        if not alt:
            continue
        problems = []
        low = alt.lower().strip(" .")
        if FILENAME_RE.search(alt) or CAMERA_RE.match(alt):
            problems.append(("high", "it looks like a file name"))
        elif low in GENERIC:
            problems.append(("high", f"“{alt}” is a generic word, not a description"))
        elif len(low) < 3 or (len(low) < 4 and not low.isalpha()):
            problems.append(("medium", "it is only a few characters long"))
        if AUTO_ALT.search(alt):
            problems.append(("medium", "it looks like text generated automatically by Office, which describes the "
                                       "shape rather than what it means"))
        if REDUNDANT_PREFIX.match(alt):
            problems.append(("low", "it starts with “image of”, which screen readers already announce"))
        if alts.get(alt.lower(), 0) >= 3 and len(figures) >= 3 and _differ(shapes.get(alt.lower(), ())) \
                and len(pictures.get(alt.lower(), ())) != 1:  # one picture reused (a signature) is fine
            # Cannot tell a re-embedded copy of one picture from different pictures: ask, don't assert.
            problems.append(("low", f"the same text is used for {alts[alt.lower()]} figures that may be "
                                    "different pictures"))
        caption = _caption_text(a, n)
        if caption and caption.strip().lower() == low:
            problems.append(("medium", "it repeats the caption word for word"))
        if len(alt) > 400:
            problems.append(("low", "it is very long; complex images may need a longer description elsewhere"))
        if not problems:
            continue
        conf = "high" if any(c == "high" for c, _ in problems) else ("medium" if any(c == "medium" for c, _ in problems) else "low")
        sev = "error" if conf == "high" else ("warning" if conf == "medium" else "notice")
        out.append(Finding("figure-alt-quality", "Alternative text is not meaningful", sev, conf,
                           f"The alt text “{alt[:80]}” is probably not useful: " + "; ".join(p for _, p in problems) + ".",
                           page=page, bbox=bb, element="Figure", matterhorn=["13-004"], wcag=["1.1.1"]))
    # Figures with nothing drawn inside them.
    for n in figures:
        if not a.node_content.get(id(n)) and not any(isinstance(c, ObjRef) for c in n.children):
            out.append(Finding("figure-empty", "Figure tag has no visible content", "notice", "medium",
                               "A <Figure> element is not associated with any drawn content.",
                               page=n.page, element="Figure", matterhorn=["01-006"], wcag=["1.3.1"]))
    return out


def _differ(sizes) -> bool:
    """Several figures share an alt text: suspicious only for pictures (not icons, not a repeated
    signature) whose drawn sizes differ, i.e. visibly different images."""
    sizes = [x for x in sizes if max(x) >= 108]  # 1.5 inch: smaller marks are icons and bullets
    if len(sizes) < 2:
        return False
    ws = [w for w, _ in sizes]
    hs = [h for _, h in sizes]
    return max(ws) > 1.2 * min(ws) or max(hs) > 1.2 * min(hs)


def _caption_text(a: Analysis, fig) -> str | None:
    sibs = fig.parent.node_children() if fig.parent is not None else []
    for c in fig.node_children() + sibs:
        if c.type == "Caption":
            return a.node_text(c)
    return None
