"""Command line interface.

  tagwell check FILE_OR_DIR... [--json out.json] [--html out.html] [--fail-on fail|review|never]
  tagwell serve [--port 8765]          local web UI (binds to 127.0.0.1 only)
  tagwell checks                        list the checks and the Matterhorn conditions they cover
  tagwell label FILE_OR_DIR... --out review.csv   review sheet for measuring accuracy on real files
  tagwell score review.csv                         precision per check from a filled-in sheet
"""
from __future__ import annotations

import argparse
import os
import sys

from . import __version__
from .checks import CHECKS
from .engine import check_file, collect_pdfs
from .report import STATUS_ERROR, STATUS_FAIL, STATUS_REVIEW, render_html, render_json, render_text


def _write(path: str, text: str) -> None:
    d = os.path.dirname(os.path.abspath(path))
    os.makedirs(d, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text)


def cmd_check(args: argparse.Namespace) -> int:
    files = collect_pdfs(args.paths)
    if not files:
        print("no PDF files found", file=sys.stderr)
        return 2
    only = set(args.only.split(",")) if args.only else None
    reports = [check_file(f, cost_per_page=args.cost_per_page, only=only) for f in files]
    if args.json:
        _write(args.json, render_json(reports))
    if args.html:
        _write(args.html, render_html(reports))
    if not args.quiet:
        print(render_text(reports))
        if args.json:
            print(f"JSON report: {args.json}")
        if args.html:
            print(f"HTML report: {args.html}")
    if any(r.status == STATUS_ERROR for r in reports) and args.fail_on != "never":
        return 2
    if args.fail_on == "fail" and any(r.status == STATUS_FAIL for r in reports):
        return 1
    if args.fail_on == "review" and any(r.status in (STATUS_FAIL, STATUS_REVIEW) for r in reports):
        return 1
    return 0


def cmd_checks(_args: argparse.Namespace) -> int:
    for name, fn, needs_tree in CHECKS:
        doc = (fn.__doc__ or "").strip().splitlines()[0] if fn.__doc__ else ""
        print(f"{name:<18} {'(tagged only) ' if needs_tree else ''}{doc}")
    return 0


def cmd_label(args: argparse.Namespace) -> int:
    from .labeling import write_sheet

    stats = write_sheet(args.paths, args.out)
    print(f"wrote {args.out}: {stats['documents']} document(s), {stats['findings']} finding(s) to judge, "
          f"{stats['clean_pages']} clean page(s) to spot-check, {stats['unreadable']} unreadable")
    print("Fill the 'verdict' column (findings: TP / FP / UNSURE; clean pages: OK / MISSED), then run "
          f"`tagwell score {args.out}`.")
    return 0


def cmd_score(args: argparse.Namespace) -> int:
    from .labeling import format_score, score_sheet

    print(format_score(score_sheet(args.sheet)))
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    from .server import serve

    serve(args.port)
    return 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="tagwell", description="Semantic accessibility check for tagged PDFs.")
    p.add_argument("--version", action="version", version=f"tagwell {__version__}")
    sub = p.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("check", help="check PDF files or folders")
    c.add_argument("paths", nargs="+")
    c.add_argument("--json", help="write a JSON report here")
    c.add_argument("--html", help="write an HTML report here")
    c.add_argument("--cost-per-page", type=float, default=6.0,
                   help="assumed cost of human review per page, for the savings estimate (default 6)")
    c.add_argument("--only", help="comma-separated check names (see `tagwell checks`)")
    c.add_argument("--fail-on", choices=["fail", "review", "never"], default="never",
                   help="exit 1 when any document reaches this status (for CI)")
    c.add_argument("-q", "--quiet", action="store_true")
    c.set_defaults(fn=cmd_check)
    s = sub.add_parser("serve", help="run the local web UI on 127.0.0.1")
    s.add_argument("--port", type=int, default=8765)
    s.set_defaults(fn=cmd_serve)
    k = sub.add_parser("checks", help="list checks")
    k.set_defaults(fn=cmd_checks)
    lb = sub.add_parser("label", help="write a review sheet (CSV) for measuring accuracy on real files")
    lb.add_argument("paths", nargs="+")
    lb.add_argument("--out", default="review.csv")
    lb.set_defaults(fn=cmd_label)
    sc = sub.add_parser("score", help="score a filled-in review sheet")
    sc.add_argument("sheet")
    sc.set_defaults(fn=cmd_score)
    args = p.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
