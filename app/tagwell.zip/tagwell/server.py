"""A tiny local web UI: upload PDFs, get the HTML report. Binds to 127.0.0.1 only; files are
processed in memory and never written to disk or sent anywhere."""
from __future__ import annotations

import html
from email.parser import BytesParser
from email.policy import HTTP
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .engine import check_file
from .report import render_html

MAX_UPLOAD = 100 * 1024 * 1024

FORM = """<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport"
content="width=device-width,initial-scale=1"><title>Tagwell</title><style>
:root{--bg:#fbfaf7;--fg:#1d1d1b;--muted:#5d5b55;--card:#fff;--line:#dedad2;--accent:#3b4cca}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#151514;--fg:#ecebe6;--muted:#a8a69f;--card:#1f1f1d;--line:#3a3935;--accent:#a6b0ff}}
:root[data-theme="dark"]{--bg:#151514;--fg:#ecebe6;--muted:#a8a69f;--card:#1f1f1d;--line:#3a3935;--accent:#a6b0ff}
body{margin:0;background:var(--bg);color:var(--fg);font:16px/1.5 system-ui,sans-serif}
main{max-width:640px;margin:0 auto;padding:40px 16px}.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:20px}
button{background:var(--accent);color:var(--bg);border:0;border-radius:8px;padding:10px 18px;font-size:16px;cursor:pointer}
p{color:var(--muted)}</style></head><body><main><h1>Tagwell</h1>
<p>Check tagged PDFs for the accessibility problems rule checkers miss: reading order, headings, tables,
lists, alt text, page furniture. Files stay on this computer.</p>
<form class="card" method="post" action="/check" enctype="multipart/form-data">
<label for="f">PDF files</label><br><input id="f" name="files" type="file" accept="application/pdf,.pdf" multiple required>
<p><button type="submit">Check</button></p></form>%s</main></body></html>"""


class Handler(BaseHTTPRequestHandler):
    server_version = "Tagwell"

    def _send(self, code: int, body: str, ctype: str = "text/html; charset=utf-8") -> None:
        data = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; img-src data:; form-action 'self'")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:  # noqa: N802
        if self.path in ("/", "/index.html"):
            self._send(200, FORM % "")
        else:
            self._send(404, "not found", "text/plain; charset=utf-8")

    def do_POST(self) -> None:  # noqa: N802
        if self.path != "/check":
            self._send(404, "not found", "text/plain; charset=utf-8")
            return
        length = int(self.headers.get("Content-Length") or 0)
        if length <= 0 or length > MAX_UPLOAD:
            self._send(413, FORM % "<p>Upload too large or empty.</p>")
            return
        body = self.rfile.read(length)
        ctype = self.headers.get("Content-Type", "")
        files = parse_multipart(ctype, body)
        if not files:
            self._send(400, FORM % "<p>No PDF files received.</p>")
            return
        reports = [check_file(name, data=data) for name, data in files]
        self._send(200, render_html(reports))

    def log_message(self, fmt: str, *args) -> None:  # quiet by default
        return


def parse_multipart(content_type: str, body: bytes) -> list[tuple[str, bytes]]:
    if "multipart/form-data" not in content_type:
        return []
    msg = BytesParser(policy=HTTP).parsebytes(b"Content-Type: " + content_type.encode("latin-1") + b"\r\n\r\n" + body)
    out = []
    for part in msg.iter_parts():
        name = part.get_filename()
        if not name:
            continue
        data = part.get_payload(decode=True) or b""
        out.append((html.unescape(name), data))
    return out


def serve(port: int = 8765) -> None:  # pragma: no cover - interactive
    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    print(f"Tagwell running at http://127.0.0.1:{port}/  (Ctrl+C to stop)")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
