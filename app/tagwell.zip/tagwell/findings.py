"""Finding model shared by all checks."""
from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

SEVERITIES = ("error", "warning", "notice")
CONFIDENCES = ("high", "medium", "low")


@dataclass
class Finding:
    check: str
    title: str
    severity: str
    confidence: str
    message: str
    page: int | None = None  # 0-based; None = document level
    bbox: tuple[float, float, float, float] | None = None
    evidence: list[str] = field(default_factory=list)
    matterhorn: list[str] = field(default_factory=list)
    wcag: list[str] = field(default_factory=list)
    machine_checkable: bool = False  # True when the Matterhorn condition is machine-checkable (M)
    element: str | None = None
    related_boxes: list[tuple[float, float, float, float]] = field(default_factory=list)

    def __post_init__(self) -> None:
        assert self.severity in SEVERITIES, self.severity
        assert self.confidence in CONFIDENCES, self.confidence

    @property
    def needs_human(self) -> bool:
        """A person should confirm this finding: a judgement condition we are not sure about."""
        return not self.machine_checkable and self.confidence != "high"

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["page"] = None if self.page is None else self.page + 1  # 1-based for people
        d["needs_human"] = self.needs_human
        d.pop("related_boxes", None)
        return d
