"""Generate the demo documents. All content is fictional (the 'City of Riverton' does not exist).

Each document models something we see in the market:
  01  a well-tagged document (the control: should have no semantic findings)
  02  a two-column page whose tags read across the columns row by row
  03  'auto-remediated' output that passes basic machine checks but is semantically wrong
  04  a scanned notice with no text at all
  05  body text hidden as an artifact, and running headers handled correctly
  06  a Spanish document declared as English
  07  a fillable form with auto-generated, missing and wrong field names, tagged out of order
  08  the same form done properly (control: no findings)
"""
from __future__ import annotations

import os
import textwrap

from .pdfwriter import TaggedPDF

CHAR_W = 0.6  # Courier: 600/1000 em


def wrap(text: str, width_pt: float, size: float) -> list[str]:
    return textwrap.wrap(text, max(10, int(width_pt / (size * CHAR_W))))


LOREM = ("The council reviewed the quarterly report on road maintenance, the library extension and "
         "the stormwater plan. Staff answered questions about the timeline and the remaining budget. "
         "Residents may request any document in an alternative format from the clerk's office.")


def _header_footer(doc: TaggedPDF, page, n: int, total: int, tagged: bool, header: str) -> None:
    if tagged:
        e = doc.elem("P")
        page.text(e, 72, 752, header, size=8)
        e2 = doc.elem("P")
        page.text(e2, 290, 40, f"Page {n} of {total}", size=8)
    else:
        page.text(None, 72, 752, header, size=8, artifact=True, subtype="Header")
        page.text(None, 290, 40, f"Page {n} of {total}", size=8, artifact=True, subtype="Footer")


def doc_well_tagged() -> TaggedPDF:
    d = TaggedPDF(title="Riverton City Council Minutes, 3 September 2026")
    p1 = d.page()
    _header_footer(d, p1, 1, 2, False, "City of Riverton - Council Minutes")
    sect = d.elem("Sect")
    p1.text(d.elem("H1", sect), 72, 700, "Council Minutes", size=22, bold=True)
    y = 670
    lines = wrap(LOREM, 468, 11)
    p1.text(d.elem("P", sect), 72, y, lines)
    y -= len(lines) * 13.75 + 24
    p1.text(d.elem("H2", sect), 72, y, "Attendance", size=15, bold=True)
    y -= 26
    lst = d.elem("L", sect, attrs={"O": "List", "ListNumbering": "Disc"})
    for name in ("Mayor A. Lindqvist", "Councillor R. Osei", "Councillor M. Haddad"):
        li = d.elem("LI", lst)
        p1.text(d.elem("Lbl", li), 80, y, "•")
        p1.text(d.elem("LBody", li), 96, y, name)
        y -= 16
    y -= 18
    p1.text(d.elem("H2", sect), 72, y, "Budget summary", size=15, bold=True)
    y -= 30
    tbl = d.elem("Table", sect)
    head = d.elem("THead", tbl)
    tr = d.elem("TR", head)
    xs = (72, 272, 400)
    p1.rect(70, y - 5, 472, 18, gray=0.85)
    for x, t in zip(xs, ("Item", "Budget", "Spent")):
        p1.text(d.elem("TH", tr, attrs={"O": "Table", "Scope": "Column"}), x, y, t, bold=True)
    body = d.elem("TBody", tbl)
    for row in (("Road maintenance", "$120,000", "$84,500"), ("Library extension", "$310,000", "$295,100"),
                ("Stormwater plan", "$75,000", "$12,250")):
        y -= 18
        tr = d.elem("TR", body)
        for x, t in zip(xs, row):
            p1.text(d.elem("TD", tr), x, y, t)
    y -= 40
    fig = d.elem("Figure", sect, alt="Bar chart: library extension has used 95% of its budget, road maintenance "
                                     "70% and the stormwater plan 16%.")
    p1.image(72, y - 90, 200, 90, elem=fig)
    p1.text(d.elem("Caption", sect), 290, y - 40, "Figure 1. Budget used by project.", size=9)
    p2 = d.page()
    _header_footer(d, p2, 2, 2, False, "City of Riverton - Council Minutes")
    p2.text(d.elem("H2", sect), 72, 700, "Public comment", size=15, bold=True)
    y = 672
    for para in (LOREM, "Two residents spoke about parking near the library. The council asked staff to report "
                        "back at the next meeting with options and costs."):
        ls = wrap(para, 468, 11)
        p2.text(d.elem("P", sect), 72, y, ls)
        y -= len(ls) * 13.75 + 14
    return d


def doc_two_column_wrong_order() -> TaggedPDF:
    d = TaggedPDF(title="Riverton Parks Newsletter, Autumn 2026")
    p = d.page()
    p.text(None, 72, 752, "Riverton Parks Newsletter", size=8, artifact=True, subtype="Header")
    art = d.elem("Art")
    p.text(d.elem("H1", art), 72, 700, "Autumn in the parks", size=22, bold=True)
    left = ["Leaf collection starts on 1 October. Bags are free at the community centre and at both libraries.",
            "The north playground reopens after resurfacing. The new surface is softer and wheelchair accessible.",
            "Volunteers planted 140 trees along the river path this spring. Most are doing well after the dry summer."]
    right = ["The dog park will close for drainage work from 14 to 18 October. Please use the east field instead.",
             "Pool hours change on 1 November. The winter timetable is available at the front desk and online.",
             "Our survey closes on 30 October. Tell us which park improvements matter most to you and your family."]
    col_w = 216
    lx, rx = 72, 324
    y = 660
    blocks = []
    for lt, rt in zip(left, right):
        ll, rl = wrap(lt, col_w, 11), wrap(rt, col_w, 11)
        blocks.append((lx, y, ll))
        blocks.append((rx, y, rl))
        y -= max(len(ll), len(rl)) * 13.75 + 18
    # The tags follow the drawing order row by row: L1, R1, L2, R2, L3, R3. That is the classic
    # failure when a two-column page is tagged without checking reading order.
    for x, yy, ls in blocks:
        p.text(d.elem("P", art), x, yy, ls)
    return d


def doc_auto_remediated() -> TaggedPDF:
    """Looks tagged and passes basic machine checks, but the semantics are wrong."""
    d = TaggedPDF(title="Microsoft Word - agenda_final_v2.docx")
    total = 3
    for n in range(1, total + 1):
        p = d.page()
        # Running header and page number tagged as real content on every page (01-001).
        _header_footer(d, p, n, total, True, "City of Riverton - Planning Commission Agenda")
        if n == 1:
            # Headings tagged as plain paragraphs (14-001).
            p.text(d.elem("P"), 72, 700, "Planning Commission Agenda", size=22, bold=True)
            ls = wrap("The commission meets at 6:00 pm in the council chamber. Public comment is taken on each "
                      "item before the vote.", 468, 11)
            p.text(d.elem("P"), 72, 668, ls)
            p.text(d.elem("P"), 72, 620, "Items for decision", size=15, bold=True)
            y = 594
            # A bulleted list tagged as separate paragraphs (16-003).
            for item in ("Rezoning request for 14 Mill Road", "Variance for a garage at 9 Elm Street",
                         "Draft tree protection ordinance", "Minutes of the August meeting"):
                p.text(d.elem("P"), 80, y, "• " + item)
                y -= 16
            y -= 30
            p.text(d.elem("P"), 72, y, "Fee schedule", size=15, bold=True)
            y -= 30
            # A table whose header row is drawn as a header but tagged as data (15-002).
            tbl = d.elem("Table")
            xs = (72, 300)
            p.rect(70, y - 5, 330, 18, gray=0.8)
            tr = d.elem("TR", tbl)
            for x, t in zip(xs, ("Application", "Fee")):
                p.text(d.elem("TD", tr), x, y, t, bold=True)
            for row in (("Rezoning", "$1,200"), ("Variance", "$350"), ("Site plan review", "$600")):
                y -= 18
                tr = d.elem("TR", tbl)
                for x, t in zip(xs, row):
                    p.text(d.elem("TD", tr), x, y, t)
            y -= 34
            # A meeting schedule drawn as a table but tagged one paragraph per row (09-003).
            for k, row in enumerate((("Meeting", "Date", "Room"), ("Workshop", "14 Oct", "Room B"),
                                     ("Hearing", "21 Oct", "Chamber"), ("Site visit", "4 Nov", "Mill Road"))):
                e = d.elem("P")
                for x, t in zip((72, 250, 400), row):
                    p.text(e, x, y, t, bold=k == 0)
                y -= 16
            y -= 24
            # Alt text that is a camera file name (WCAG 1.1.1).
            fig = d.elem("Figure", alt="IMG_4032.jpg")
            p.image(72, y - 100, 180, 100, elem=fig)
        else:
            p.text(d.elem("P"), 72, 700, f"Item {n}: staff report", size=15, bold=True)
            y = 672
            for _ in range(3):
                ls = wrap(LOREM, 468, 11)
                p.text(d.elem("P"), 72, y, ls)
                y -= len(ls) * 13.75 + 14
    return d


def doc_scanned() -> TaggedPDF:
    d = TaggedPDF(title=None, lang=None, tagged=False, marked=False, display_doc_title=False, xmp_title=False)
    p = d.page()
    p.image(0, 0, 612, 792)
    return d


def doc_hidden_text() -> TaggedPDF:
    d = TaggedPDF(title="Riverton Water Quality Notice 2026")
    p = d.page()
    p.text(None, 72, 752, "City of Riverton - Utilities", size=8, artifact=True, subtype="Header")
    p.text(d.elem("H1"), 72, 700, "Water quality notice", size=22, bold=True)
    ls = wrap("Testing in August found all samples within federal limits. No action is needed by residents.", 468, 11)
    p.text(d.elem("P"), 72, 668, ls)
    # A real paragraph wrongly marked as an artifact: hidden from screen readers (01-002).
    hidden = wrap("Households with infants should use cold tap water for formula and run the tap for thirty "
                  "seconds first. Free test kits are available at City Hall until 30 November.", 468, 11)
    p.text(None, 72, 620, hidden, artifact=True)
    p.text(None, 290, 40, "1", size=8, artifact=True, subtype="Footer")
    return d


def doc_wrong_language() -> TaggedPDF:
    d = TaggedPDF(title="Aviso de mantenimiento de calles", lang="en-US")
    p = d.page()
    p.text(d.elem("H1"), 72, 700, "Aviso de mantenimiento", size=22, bold=True)
    y = 668
    for para in ("La ciudad de Riverton realizará trabajos de mantenimiento en las calles del centro durante el "
                 "mes de octubre. Los trabajos se harán de lunes a viernes, de las siete de la mañana a las cinco "
                 "de la tarde.",
                 "Para más información, los residentes pueden llamar a la oficina de obras públicas o visitar la "
                 "biblioteca. Las personas con discapacidad pueden pedir este aviso en otro formato.",
                 "Agradecemos su paciencia. Las rutas de autobús no cambian y el estacionamiento en la calle "
                 "principal estará disponible por la noche y durante los fines de semana."):
        ls = wrap(para, 468, 11)
        p.text(d.elem("P"), 72, y, ls)
        y -= len(ls) * 13.75 + 14
    return d


def _form(d: TaggedPDF, broken: bool) -> None:
    p = d.page()
    p.text(None, 72, 752, "City of Riverton - Building Department", size=8, artifact=True, subtype="Header")
    sect = d.elem("Sect")
    p.text(d.elem("H1", sect), 72, 710, "Fence permit application", size=20, bold=True)
    p.text(d.elem("P", sect), 72, 680, wrap("Complete every field and return this form to the Building Department. "
                                             "Applications are reviewed within ten working days.", 468, 11))
    fields = [("Applicant name", "applicant_name"), ("Street address", "street"), ("Phone number", "phone"),
              ("Email address", "email"), ("Fence height in feet", "height"), ("Fence material", "material")]
    y = 620
    labels = []
    for label, name in fields:
        lab = d.elem("P", sect)
        labels.append((lab, label, name, y))
        y -= 34
    if broken:
        # Typical output of a quick "make fillable" pass: auto names, a wrong tooltip, one field
        # with no name at all, fields tagged in creation order (right column first).
        tips = {"applicant_name": "Text1", "street": "Street address", "phone": "Email address",
                "email": None, "height": "Fence height in feet", "material": "Text6"}
        order = [4, 5, 0, 1, 2, 3]
    else:
        tips = {name: label for label, name in fields}
        order = list(range(6))
    for lab, label, name, yy in labels:
        p.text(lab, 72, yy + 4, label + ":")
    for k in order:
        _, label, name, yy = labels[k]
        p.field(name, 230, yy, w=220, h=18, tooltip=tips[name], elem=d.elem("Form", sect))
    p.text(d.elem("P", sect), 72, y - 10, "Signature of applicant and date are required before review.")


def doc_form_broken() -> TaggedPDF:
    d = TaggedPDF(title="Fence Permit Application")
    _form(d, broken=True)
    return d


def doc_form_good() -> TaggedPDF:
    d = TaggedPDF(title="Fence Permit Application (accessible)")
    _form(d, broken=False)
    return d


DOCS = {
    "01-council-minutes-well-tagged.pdf": doc_well_tagged,
    "02-parks-newsletter-two-column.pdf": doc_two_column_wrong_order,
    "03-planning-agenda-auto-remediated.pdf": doc_auto_remediated,
    "04-scanned-notice.pdf": doc_scanned,
    "05-water-notice-hidden-text.pdf": doc_hidden_text,
    "06-street-notice-wrong-language.pdf": doc_wrong_language,
    "07-fence-permit-form-broken.pdf": doc_form_broken,
    "08-fence-permit-form-accessible.pdf": doc_form_good,
}


def generate(out_dir: str) -> list[str]:
    os.makedirs(out_dir, exist_ok=True)
    paths = []
    for name, fn in DOCS.items():
        paths.append(fn().save(os.path.join(out_dir, name)))
    return paths


if __name__ == "__main__":  # pragma: no cover
    import sys

    for p in generate(sys.argv[1] if len(sys.argv) > 1 else "sample_data"):
        print(p)
