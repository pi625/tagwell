"""Synthetic benchmark: random layouts with randomly injected, labelled defects.

For every generated document we know exactly which defects were planted, so we can measure
per-check recall (planted defects found) and false-positive rate (findings on documents where
that defect was not planted). This is a measurement on *synthetic* documents written by our own
writer; it says nothing about accuracy on real-world producer output, which must be measured on
a real corpus (see README, "What is not proven").
"""
from __future__ import annotations

import random
import textwrap
from collections import defaultdict
from dataclasses import dataclass

from ..checks import run_checks
from ..model import analyse
from .pdfwriter import TaggedPDF

WORDS = ("council budget library road water park meeting report residents plan staff review public "
         "notice service program schedule permit application community district school transit safety "
         "project funding grant item vote motion approval request update summary option cost").split()

DEFECTS = ("reading-order", "visual-heading", "column-headers", "visual-list", "figure-alt-quality",
           "furniture-tagged", "content-as-artifact", "title-quality", "field-name-auto", "field-label-mismatch",
           "table-untagged")
LABELS = ["Full name", "Street address", "City", "Postcode", "Phone number", "Email address", "Date of birth",
          "Account number", "Parcel number", "Business name", "Emergency contact", "Signature date"]


def sentence(rng: random.Random, n: int) -> str:
    w = [rng.choice(WORDS) for _ in range(n)]
    return " ".join(w).capitalize() + "."


def para(rng: random.Random) -> str:
    return " ".join(sentence(rng, rng.randint(6, 12)) for _ in range(rng.randint(2, 4)))


@dataclass
class Sample:
    doc: TaggedPDF
    planted: set[str]


def make(rng: random.Random) -> Sample:
    planted: set[str] = set()
    inject = {d for d in DEFECTS if rng.random() < 0.25}
    title = "Microsoft Word - report_final.docx" if "title-quality" in inject else \
        f"Riverton {rng.choice(WORDS).title()} {rng.choice(['Report', 'Notice', 'Agenda', 'Minutes'])}"
    if "title-quality" in inject:
        planted.add("title-quality")
    d = TaggedPDF(title=title)
    n_pages = rng.randint(1, 3) if "furniture-tagged" not in inject else rng.randint(3, 4)
    size = rng.choice([10, 11, 12])
    for pn in range(n_pages):
        p = d.page()
        if "furniture-tagged" in inject:
            p.text(d.elem("P"), 72, 752, "City of Riverton", size=8)
            planted.add("furniture-tagged")
        else:
            p.text(None, 72, 752, "City of Riverton", size=8, artifact=True)
        y = 710
        head_tag = "P" if ("visual-heading" in inject and pn == 0) else "H1"
        if head_tag == "P":
            planted.add("visual-heading")
        ro_mode = rng.choice(["interleave", "swap", "title-last"]) if (pn == 0 and "reading-order" in inject) else None
        if ro_mode:
            planted.add("reading-order")
        heading_args = (d.elem(head_tag if pn == 0 else "H2") if ro_mode != "title-last" else None, 72, y,
                        title.split(" - ")[-1][:40] if pn == 0 else sentence(rng, 3)[:-1],
                        size * 2 if pn == 0 else size * 1.5)
        if ro_mode != "title-last":
            p.text(heading_args[0], heading_args[1], heading_args[2], heading_args[3], size=heading_args[4], bold=True)
        y -= size * 3
        ncols = 2 if ro_mode == "interleave" or (ro_mode is None and rng.random() < 0.3) else 1
        variant = rng.random() if ro_mode is None else 1.0
        if ncols == 1 and variant < 0.15:
            # Three columns, tagged column by column (correct).
            colw, xs = 140, (72, 236, 400)
            yy0 = y
            lowest = y
            for x in xs:
                yy = yy0
                for _ in range(rng.randint(1, 3)):
                    ls = textwrap.wrap(para(rng), int(colw / (size * 0.6)))[:4]
                    p.text(d.elem("P"), x, yy, ls, size=size)
                    yy -= len(ls) * size * 1.25 + size * rng.uniform(0.8, 2.0)
                lowest = min(lowest, yy)
            y = lowest
            ncols = 0
        elif ncols == 1 and variant < 0.3:
            # Main text with a narrow sidebar on the right, tagged after the main text (correct).
            yy = y
            for _ in range(2):
                ls = textwrap.wrap(para(rng), int(300 / (size * 0.6)))
                p.text(d.elem("P"), 72, yy, ls, size=size)
                yy -= len(ls) * size * 1.25 + size
            side = d.elem("Aside") if rng.random() < 0.5 else d.elem("Sect")
            p.text(d.elem("P", side), 400, y, textwrap.wrap(para(rng), int(140 / (size * 0.6)))[:6], size=size * 0.9)
            y = yy
            ncols = 0
        elif ncols == 1 and variant < 0.45:
            # Figure on the left with its caption on the right, then text below.
            fig = d.elem("Figure", alt="Photo of the " + rng.choice(WORDS) + " site after the work was finished")
            p.image(72, y - 90, 200, 90, elem=fig)
            p.text(d.elem("Caption"), 290, y - 40, sentence(rng, 6), size=size * 0.8)
            y -= 110
        if ncols == 2:
            uneven = rng.random() < 0.4 and "reading-order" not in inject
            colw, xs = 216, (72, 324)
            blocks = []
            for _ in range(3):
                row = []
                for x in xs:
                    ls = textwrap.wrap(para(rng), int(colw / (size * 0.6)))[:5]
                    row.append((x, ls))
                blocks.append(row)
            interleave = ro_mode == "interleave"
            ys = []
            yy = y
            for row in blocks:
                ys.append(yy)
                yy -= max(len(ls) for _, ls in row) * size * 1.25 + size * 1.5
            order = [(r, c) for r in range(3) for c in range(2)] if interleave else \
                [(r, c) for c in range(2) for r in range(3)]
            if uneven:
                order = [o for o in order if o != (2, 1)]  # right column one paragraph shorter
            for r, c in order:
                x, ls = blocks[r][c]
                p.text(d.elem("P"), x, ys[r], ls, size=size)
            y = yy
        elif ncols == 1:
            placed = []
            for _ in range(3 if ro_mode == "swap" else 2):
                ls = textwrap.wrap(para(rng), int(468 / (size * 0.6)))
                placed.append((y, ls))
                y -= len(ls) * size * 1.25 + size * rng.uniform(0.6, 2.2)
            if ro_mode == "swap":
                placed[1], placed[2] = placed[2], placed[1]  # tags read paragraph 3 before 2
            for yy, ls in placed:
                p.text(d.elem("P"), 72, yy, ls, size=size)
        if pn == 0 and y > 260:
            # A list.
            items = [sentence(rng, 4) for _ in range(rng.randint(3, 4))]
            if "visual-list" in inject:
                planted.add("visual-list")
                for it in items:
                    p.text(d.elem("P"), 80, y, "• " + it, size=size)
                    y -= size * 1.5
            else:
                lst = d.elem("L", attrs={"O": "List", "ListNumbering": "Disc"})
                for it in items:
                    li = d.elem("LI", lst)
                    p.text(d.elem("Lbl", li), 80, y, "•", size=size)
                    p.text(d.elem("LBody", li), 96, y, it, size=size)
                    y -= size * 1.5
            y -= size
        if pn == 0 and y > 200:
            if "table-untagged" in inject and "column-headers" not in inject:
                # A fee schedule tagged as plain paragraphs: one <P> per row, or one per cell.
                planted.add("table-untagged")
                per_cell = rng.random() < 0.5
                xs = (72, 250, 400)
                rows = [("Item", "Fee", "Due")] + [(rng.choice(WORDS).title(), f"${rng.randint(1, 900)}",
                                                    rng.choice(["Jan", "Apr", "Jul", "Oct"])) for _ in range(3)]
                for k, row in enumerate(rows):
                    e = None if per_cell else d.elem("P")
                    for x, txt in zip(xs, row):
                        p.text(d.elem("P") if per_cell else e, x, y, txt, size=size, bold=k == 0)
                    y -= size * 1.6
                y -= size * 2
            t = d.elem("Table")
            bad = "column-headers" in inject
            if bad:
                planted.add("column-headers")
            tr = d.elem("TR", t)
            for x, h in zip((72, 300), ("Item", "Amount")):
                p.text(d.elem("TD" if bad else "TH", tr, attrs=None if bad else {"O": "Table", "Scope": "Column"}),
                       x, y, h, size=size, bold=True)
            for _ in range(3):
                y -= size * 1.6
                tr = d.elem("TR", t)
                p.text(d.elem("TD", tr), 72, y, rng.choice(WORDS).title(), size=size)
                p.text(d.elem("TD", tr), 300, y, f"${rng.randint(1, 900)},000", size=size)
            y -= size * 3
        if pn == 0 and y > 150:
            alt = rng.choice(["IMG_2231.jpg", "image", "DSC00042.JPG"]) if "figure-alt-quality" in inject else \
                f"Chart of {rng.choice(WORDS)} spending by quarter, rising from Q1 to Q4"
            if "figure-alt-quality" in inject:
                planted.add("figure-alt-quality")
            p.image(72, y - 80, 160, 80, elem=d.elem("Figure", alt=alt))
            y -= 100
        want_form = pn == 0 and ("field-name-auto" in inject or "field-label-mismatch" in inject or rng.random() < 0.3)
        if want_form and y > 140:
            labels = rng.sample(LABELS, 3)
            bad_auto = "field-name-auto" in inject
            bad_mis = "field-label-mismatch" in inject
            if bad_auto:
                planted.add("field-name-auto")
            if bad_mis:
                planted.add("field-label-mismatch")
            fx = rng.choice([220, 260, 300])
            for k, lab in enumerate(labels):
                fy = y - k * size * 2.6
                p.text(d.elem("P"), 72, fy + 3, lab + ":", size=size)
                if bad_auto and k == 0:
                    tip = f"Text{rng.randint(1, 40)}"
                elif bad_mis and k == 1:
                    tip = rng.choice([x for x in LABELS if x not in labels])
                else:
                    tip = lab if rng.random() < 0.6 else lab + " (required)"
                p.field(lab.lower().replace(" ", "_"), fx, fy, w=180, h=size * 1.5, tooltip=tip)
            y -= 3 * size * 2.6 + size
        if ro_mode == "title-last":
            p.text(d.elem(head_tag), heading_args[1], heading_args[2], heading_args[3], size=heading_args[4], bold=True)
        if pn == 0 and "content-as-artifact" in inject and y > 130:
            planted.add("content-as-artifact")
            p.text(None, 72, y, textwrap.wrap(para(rng), 70)[:2], size=size, artifact=True)
    return Sample(d, planted)


def run(n: int = 200, seed: int = 7) -> dict:
    rng = random.Random(seed)
    tp: dict[str, int] = defaultdict(int)
    fn: dict[str, int] = defaultdict(int)
    fp: dict[str, int] = defaultdict(int)
    neg: dict[str, int] = defaultdict(int)
    other_fp: dict[str, int] = defaultdict(int)
    for _ in range(n):
        s = make(rng)
        a = analyse("bench.pdf", s.doc.to_bytes())
        f, errors = run_checks(a)
        if errors:
            raise RuntimeError(errors)
        found = {x.check for x in f if x.severity != "notice"}
        # Correct consequences of a planted defect are not false positives.
        if "visual-heading" in s.planted:
            found.discard("heading-first")
        for dname in DEFECTS:
            if dname in s.planted:
                (tp if dname in found else fn)[dname] += 1
            else:
                neg[dname] += 1
                if dname in found:
                    fp[dname] += 1
        for c in found - set(DEFECTS):
            other_fp[c] += 1
    rows = {}
    for dname in DEFECTS:
        pos = tp[dname] + fn[dname]
        rows[dname] = {
            "planted": pos,
            "recall": (tp[dname] / pos) if pos else None,
            "false_positive_rate": (fp[dname] / neg[dname]) if neg[dname] else None,
            "negatives": neg[dname],
        }
    return {"documents": n, "seed": seed, "per_check": rows, "unexpected_checks": dict(other_fp)}


def format_results(res: dict) -> str:
    lines = [f"Synthetic benchmark: {res['documents']} random documents (seed {res['seed']})",
             f"{'defect':<22}{'planted':>8}{'recall':>9}{'FP rate':>9}"]
    for name, r in res["per_check"].items():
        rec = "-" if r["recall"] is None else f"{r['recall']:.0%}"
        fpr = "-" if r["false_positive_rate"] is None else f"{r['false_positive_rate']:.1%}"
        lines.append(f"{name:<22}{r['planted']:>8}{rec:>9}{fpr:>9}")
    if res["unexpected_checks"]:
        lines.append("Other checks that fired (not planted): " +
                     ", ".join(f"{k} x{v}" for k, v in sorted(res["unexpected_checks"].items())))
    else:
        lines.append("No other checks fired.")
    return "\n".join(lines)


if __name__ == "__main__":  # pragma: no cover
    import sys

    print(format_results(run(int(sys.argv[1]) if len(sys.argv) > 1 else 200)))
