"""A small writer for *tagged* PDFs, used to build test fixtures and demo documents.

It writes real, viewable PDFs (Courier/Courier-Bold standard fonts, whose metrics are exact:
every glyph is 600/1000 em wide) with a structure tree, ParentTree, marked content and
artifacts, so the reader can be tested end to end without third-party files.
"""
from __future__ import annotations

import zlib
from dataclasses import dataclass, field
from typing import Any

from ..pdf.objects import Name, Ref


@dataclass
class Elem:
    type: str
    parent: "Elem | None"
    alt: str | None = None
    actual_text: str | None = None
    lang: str | None = None
    attrs: dict | None = None
    kids: list[Any] = field(default_factory=list)  # Elem | (page_no, mcid)
    num: int = 0


@dataclass
class _Field:
    name: str
    tooltip: str | None
    rect: tuple[float, float, float, float]
    ft: str
    elem: "Elem | None"


@dataclass
class _Page:
    width: float
    height: float
    fields: list[_Field] = field(default_factory=list)
    tabs: str | None = "S"
    ops: list[str] = field(default_factory=list)
    next_mcid: int = 0
    mcid_owner: dict[int, Elem] = field(default_factory=dict)
    uses_image: bool = False
    rotate: int = 0


def _esc(s: str) -> str:
    b = s.encode("cp1252", "replace").decode("latin-1")
    return b.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


class PageBuilder:
    def __init__(self, doc: "TaggedPDF", index: int, p: _Page):
        self.doc = doc
        self.index = index
        self.p = p

    def _begin(self, elem: Elem | None, artifact: bool, subtype: str | None) -> None:
        if artifact:
            extra = f" /Subtype /{subtype}" if subtype else ""
            self.p.ops.append(f"/Artifact << /Type /Pagination{extra} >> BDC")
        elif elem is not None:
            mcid = self.p.next_mcid
            self.p.next_mcid += 1
            self.p.mcid_owner[mcid] = elem
            elem.kids.append((self.index, mcid))
            self.p.ops.append(f"/{elem.type} << /MCID {mcid} >> BDC")

    def _end(self, elem: Elem | None, artifact: bool) -> None:
        if artifact or elem is not None:
            self.p.ops.append("EMC")

    def text(self, elem: Elem | None, x: float, y: float, lines: str | list[str], size: float = 11,
             bold: bool = False, leading: float | None = None, artifact: bool = False,
             subtype: str | None = None, invisible: bool = False) -> "PageBuilder":
        """Draw text. All lines of one call form one marked-content sequence (one MCID)."""
        if isinstance(lines, str):
            lines = [lines]
        lead = leading if leading is not None else size * 1.25
        self._begin(elem, artifact, subtype)
        font = "F2" if bold else "F1"
        self.p.ops.append(f"BT /{font} {size:g} Tf {'3 Tr ' if invisible else ''}{lead:g} TL {x:g} {y:g} Td")
        for i, line in enumerate(lines):
            if i:
                self.p.ops.append("T*")
            self.p.ops.append(f"({_esc(line)}) Tj")
        self.p.ops.append("ET")
        self._end(elem, artifact)
        return self

    def rect(self, x: float, y: float, w: float, h: float, gray: float = 0.85, elem: Elem | None = None,
             artifact: bool = True, stroke: bool = False) -> "PageBuilder":
        self._begin(elem, artifact and elem is None, None)
        op = "S" if stroke else "f"
        self.p.ops.append(f"q {gray:g} g {gray:g} G {x:g} {y:g} {w:g} {h:g} re {op} Q")
        self._end(elem, artifact and elem is None)
        return self

    def image(self, x: float, y: float, w: float, h: float, elem: Elem | None = None,
              artifact: bool = False, picture: int = 1) -> "PageBuilder":
        """Draw one of two built-in pictures (1 or 2: different pixels, so different images)."""
        self.p.uses_image = True
        self._begin(elem, artifact, None)
        self.p.ops.append(f"q {w:g} 0 0 {h:g} {x:g} {y:g} cm /Im{2 if picture == 2 else 1} Do Q")
        self._end(elem, artifact)
        return self

    def field(self, name: str, x: float, y: float, w: float = 160, h: float = 16, tooltip: str | None = None,
              ft: str = "Tx", elem: "Elem | None" = None, tagged: bool = True) -> "PageBuilder":
        """Add a form field (merged field/widget annotation). With tagged=True and no elem, a
        <Form> element is created under the document root."""
        if tagged and elem is None:
            elem = self.doc.elem("Form")
        f = _Field(name, tooltip, (x, y, x + w, y + h), ft, elem if tagged else None)
        self.p.fields.append(f)
        if f.elem is not None:
            f.elem.kids.append(("obj", self.index, len(self.p.fields) - 1))
        self.p.ops.append(f"q 0.5 G {x:g} {y:g} {w:g} {h:g} re S Q")
        return self

    def raw(self, ops: str) -> "PageBuilder":
        self.p.ops.append(ops)
        return self


class TaggedPDF:
    def __init__(self, title: str | None = "Untitled document", lang: str | None = "en-US",
                 info_title: str | None = None, xmp_title: bool = True, display_doc_title: bool = True,
                 tagged: bool = True, marked: bool = True):
        self.title = title
        self.lang = lang
        self.info_title = info_title if info_title is not None else title
        self.xmp_title = xmp_title
        self.display_doc_title = display_doc_title
        self.tagged = tagged
        self.marked = marked
        self.pages: list[_Page] = []
        self.root = Elem("Document", None)
        self.role_map: dict[str, str] = {}

    def page(self, width: float = 612, height: float = 792, rotate: int = 0) -> PageBuilder:
        p = _Page(width, height, rotate=rotate)
        self.pages.append(p)
        return PageBuilder(self, len(self.pages) - 1, p)

    def elem(self, type_: str, parent: Elem | None = None, alt: str | None = None, attrs: dict | None = None,
             lang: str | None = None, actual_text: str | None = None) -> Elem:
        parent = parent or self.root
        e = Elem(type_, parent, alt, actual_text, lang, attrs)
        parent.kids.append(e)
        return e

    # -- serialisation ---------------------------------------------------------
    def to_bytes(self, compress: bool = True, xref_stream: bool = False, object_streams: bool = False,
                 break_xref: bool = False, encrypt: str | None = None, user_password: str = "",
                 owner_password: str = "owner-secret") -> bytes:
        objs: dict[int, Any] = {}
        streams: dict[int, tuple[dict, bytes]] = {}
        n = [0]

        def new() -> int:
            n[0] += 1
            return n[0]

        cat, pages_n, f1, f2, img, img2 = new(), new(), new(), new(), new(), new()
        widths = [600] * 224
        for num, base in ((f1, "Courier"), (f2, "Courier-Bold")):
            objs[num] = {"Type": Name("Font"), "Subtype": Name("Type1"), "BaseFont": Name(base),
                         "Encoding": Name("WinAnsiEncoding"), "FirstChar": 32, "LastChar": 255, "Widths": widths}
        streams[img] = ({"Type": Name("XObject"), "Subtype": Name("Image"), "Width": 1, "Height": 1,
                         "ColorSpace": Name("DeviceGray"), "BitsPerComponent": 8}, b"\x99")
        streams[img2] = ({"Type": Name("XObject"), "Subtype": Name("Image"), "Width": 1, "Height": 1,
                          "ColorSpace": Name("DeviceGray"), "BitsPerComponent": 8}, b"\x33")
        page_nums = []
        field_nums: dict[tuple[int, int], int] = {}
        for i, p in enumerate(self.pages):
            for k in range(len(p.fields)):
                field_nums[(i, k)] = 0  # assigned below
        for i, p in enumerate(self.pages):
            pn, cn = new(), new()
            page_nums.append(pn)
            for k in range(len(p.fields)):
                field_nums[(i, k)] = new()
            res: dict = {"Font": {"F1": Ref(f1), "F2": Ref(f2)}}
            if p.uses_image:
                res["XObject"] = {"Im1": Ref(img), "Im2": Ref(img2)}
            pd = {"Type": Name("Page"), "Parent": Ref(pages_n), "MediaBox": [0, 0, p.width, p.height],
                  "Resources": res, "Contents": Ref(cn)}
            if p.rotate:
                pd["Rotate"] = p.rotate
            if self.tagged:
                pd["StructParents"] = i
            if p.tabs:
                pd["Tabs"] = Name(p.tabs)
            if p.fields:
                pd["Annots"] = [Ref(field_nums[(i, k)]) for k in range(len(p.fields))]
            objs[pn] = pd
            content = ("\n".join(p.ops) + "\n").encode("latin-1")
            streams[cn] = ({}, content)
        objs[pages_n] = {"Type": Name("Pages"), "Kids": [Ref(x) for x in page_nums], "Count": len(page_nums)}
        catalog: dict = {"Type": Name("Catalog"), "Pages": Ref(pages_n)}
        if self.lang:
            catalog["Lang"] = self.lang.encode("latin-1")
        if self.display_doc_title:
            catalog["ViewerPreferences"] = {"DisplayDocTitle": True}
        if self.marked:
            catalog["MarkInfo"] = {"Marked": True}
        if self.tagged:
            str_root = new()
            # Assign object numbers to elements.
            elems: list[Elem] = []
            stack = [self.root]
            while stack:
                e = stack.pop()
                e.num = new()
                elems.append(e)
                stack.extend(reversed([k for k in e.kids if isinstance(k, Elem)]))
            for e in elems:
                d: dict = {"Type": Name("StructElem"), "S": Name(e.type),
                           "P": Ref(e.parent.num) if e.parent else Ref(str_root)}
                first_pg = next((k[1] if k[0] == "obj" else k[0] for k in e.kids if isinstance(k, tuple)), None)
                if first_pg is not None:
                    d["Pg"] = Ref(page_nums[first_pg])
                kids = []
                for k in e.kids:
                    if isinstance(k, Elem):
                        kids.append(Ref(k.num))
                    elif k[0] == "obj":
                        kids.append({"Type": Name("OBJR"), "Obj": Ref(field_nums[(k[1], k[2])]),
                                     "Pg": Ref(page_nums[k[1]])})
                    elif k[0] == first_pg:
                        kids.append(k[1])
                    else:
                        kids.append({"Type": Name("MCR"), "Pg": Ref(page_nums[k[0]]), "MCID": k[1]})
                if kids:
                    d["K"] = kids if len(kids) != 1 else kids[0]
                if e.alt is not None:
                    d["Alt"] = e.alt.encode("latin-1", "replace")
                if e.actual_text is not None:
                    d["ActualText"] = e.actual_text.encode("latin-1", "replace")
                if e.lang:
                    d["Lang"] = e.lang.encode("latin-1")
                if e.attrs:
                    d["A"] = dict(e.attrs)
                objs[e.num] = d
            nums: list[Any] = []
            for i, p in enumerate(self.pages):
                nums += [i, [Ref(p.mcid_owner[m].num) for m in sorted(p.mcid_owner)]]
            next_key = len(self.pages)
            struct_parent: dict[tuple[int, int], int] = {}
            for i, p in enumerate(self.pages):
                for k, f in enumerate(p.fields):
                    if f.elem is not None:
                        struct_parent[(i, k)] = next_key
                        nums += [next_key, Ref(f.elem.num)]
                        next_key += 1
            parent_tree = new()
            objs[parent_tree] = {"Nums": nums}
            root_d: dict = {"Type": Name("StructTreeRoot"), "K": Ref(self.root.num), "ParentTree": Ref(parent_tree),
                            "ParentTreeNextKey": next_key}
            if self.role_map:
                root_d["RoleMap"] = {k: Name(v) for k, v in self.role_map.items()}
            objs[str_root] = root_d
            catalog["StructTreeRoot"] = Ref(str_root)
        all_fields = []
        for i, p in enumerate(self.pages):
            for k, f in enumerate(p.fields):
                wd = {"Type": Name("Annot"), "Subtype": Name("Widget"), "FT": Name(f.ft), "T": f.name.encode("latin-1"),
                      "Rect": list(f.rect), "P": Ref(page_nums[i]), "F": 4, "DA": b"/F1 10 Tf 0 g"}
                if f.tooltip is not None:
                    wd["TU"] = f.tooltip.encode("latin-1", "replace")
                if self.tagged and f.elem is not None:
                    wd["StructParent"] = struct_parent[(i, k)]
                objs[field_nums[(i, k)]] = wd
                all_fields.append(Ref(field_nums[(i, k)]))
        if all_fields:
            catalog["AcroForm"] = {"Fields": all_fields, "DA": b"/F1 10 Tf 0 g", "DR": {"Font": {"F1": Ref(f1)}}}
        info = new()
        objs[info] = {"Producer": b"Tagwell sample writer"}
        if self.info_title:
            objs[info]["Title"] = self.info_title.encode("latin-1", "replace")
        if self.xmp_title and self.title:
            md = new()
            t = self.title.replace("&", "&amp;").replace("<", "&lt;")
            xmp = ('<?xpacket begin="" id="W5M0MpCehiHzreSzNTczkc9d"?><x:xmpmeta xmlns:x="adobe:ns:meta/">'
                   '<rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"><rdf:Description rdf:about="" '
                   'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:pdfuaid="http://www.aiim.org/pdfua/ns/id/">'
                   f'<dc:title><rdf:Alt><rdf:li xml:lang="x-default">{t}</rdf:li></rdf:Alt></dc:title>'
                   '<pdfuaid:part>1</pdfuaid:part></rdf:Description></rdf:RDF></x:xmpmeta><?xpacket end="w"?>')
            streams[md] = ({"Type": Name("Metadata"), "Subtype": Name("XML")}, xmp.encode("utf-8"))
            catalog["Metadata"] = Ref(md)
        objs[cat] = catalog
        enc = _Encryptor(encrypt, user_password, owner_password, (self.title or "x").encode("utf-8")) if encrypt else None
        return _serialise(objs, streams, cat, info, n[0], compress, xref_stream, object_streams, break_xref, enc)

    def save(self, path: str, **kw: Any) -> str:
        with open(path, "wb") as fh:
            fh.write(self.to_bytes(**kw))
        return path


def _ser(v: Any) -> str:
    if v is True:
        return "true"
    if v is False:
        return "false"
    if v is None:
        return "null"
    if isinstance(v, Name):
        return "/" + str(v)
    if isinstance(v, Ref):
        return f"{v.num} {v.gen} R"
    if isinstance(v, (bytes, bytearray)):
        s = bytes(v).decode("latin-1")
        return "(" + s.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)") + ")"
    if isinstance(v, str):
        return "(" + _esc(v) + ")"
    if isinstance(v, float):
        return f"{v:.4f}".rstrip("0").rstrip(".")
    if isinstance(v, int):
        return str(v)
    if isinstance(v, list):
        return "[" + " ".join(_ser(x) for x in v) + "]"
    if isinstance(v, dict):
        return "<<" + " ".join(f"/{k} {_ser(x)}" for k, x in v.items()) + ">>"
    raise TypeError(type(v))


def _serialise(objs: dict, streams: dict, cat: int, info: int, maxnum: int, compress: bool,
               xref_stream: bool, object_streams: bool, break_xref: bool, enc: "_Encryptor | None" = None) -> bytes:
    if enc is not None:
        if xref_stream or object_streams:
            raise ValueError("the sample writer only encrypts with classic xref tables")
        maxnum += 1
        objs = {k: enc.value(v, k) for k, v in objs.items()}
        objs[maxnum] = enc.encrypt_dict
        streams = {k: (enc.value(d, k), d_data) for k, (d, d_data) in streams.items()}
        enc_num = maxnum
    else:
        enc_num = None
    out = bytearray(b"%PDF-1.7\n%\xe2\xe3\xcf\xd3\n")
    offsets: dict[int, int] = {}
    in_objstm: dict[int, tuple[int, int]] = {}
    total = maxnum
    if object_streams:
        total += 1
        stm_num = total
        body = bytearray()
        header = []
        for i, num in enumerate(sorted(objs)):
            header.append(f"{num} {len(body)}")
            body += _ser(objs[num]).encode("latin-1") + b"\n"
            in_objstm[num] = (stm_num, i)
        head = (" ".join(header) + "\n").encode("latin-1")
        data = zlib.compress(head + bytes(body))
        streams[stm_num] = ({"Type": Name("ObjStm"), "N": len(header), "First": len(head),
                             "Filter": Name("FlateDecode")}, data)
        loose = {}
    else:
        loose = objs
    for num in range(1, total + 1):
        if num in loose:
            offsets[num] = len(out)
            out += f"{num} 0 obj\n{_ser(loose[num])}\nendobj\n".encode("latin-1")
        elif num in streams:
            d, data = streams[num]
            d = dict(d)
            if compress and "Filter" not in d and d.get("Subtype") != Name("XML"):
                data = zlib.compress(data)
                d["Filter"] = Name("FlateDecode")
            if enc is not None:
                data = enc.data(data, num)
            d["Length"] = len(data)
            offsets[num] = len(out)
            out += f"{num} 0 obj\n{_ser(d)}\nstream\n".encode("latin-1") + data + b"\nendstream\nendobj\n"
    if break_xref:
        offsets = {k: v + 7 for k, v in offsets.items()}
    xref_pos = len(out)
    size = total + 1
    if xref_stream:
        size += 1
        xnum = total + 1
        rows = bytearray(b"\x00" + (0).to_bytes(4, "big") + (65535).to_bytes(2, "big"))
        for num in range(1, total + 1):
            if num in offsets:
                rows += b"\x01" + offsets[num].to_bytes(4, "big") + (0).to_bytes(2, "big")
            elif num in in_objstm:
                s, i = in_objstm[num]
                rows += b"\x02" + s.to_bytes(4, "big") + i.to_bytes(2, "big")
            else:
                rows += b"\x00" + (0).to_bytes(4, "big") + (0).to_bytes(2, "big")
        rows += b"\x01" + xref_pos.to_bytes(4, "big") + (0).to_bytes(2, "big")
        data = zlib.compress(bytes(rows))
        d = {"Type": Name("XRef"), "Size": size, "W": [1, 4, 2], "Root": Ref(cat), "Info": Ref(info),
             "Filter": Name("FlateDecode"), "Length": len(data)}
        out += f"{xnum} 0 obj\n{_ser(d)}\nstream\n".encode("latin-1") + data + b"\nendstream\nendobj\n"
    else:
        if object_streams:
            raise ValueError("object streams require xref_stream=True")
        out += f"xref\n0 {size}\n0000000000 65535 f \n".encode("latin-1")
        for num in range(1, size):
            if num in offsets:
                out += f"{offsets[num]:010d} 00000 n \n".encode("latin-1")
            else:
                out += b"0000000000 65535 f \n"
        extra = ""
        if enc_num is not None:
            extra = f" /Encrypt {enc_num} 0 R /ID [<{enc.id0.hex()}> <{enc.id0.hex()}>]"
        out += f"trailer\n<</Size {size} /Root {cat} 0 R /Info {info} 0 R{extra}>>\n".encode("latin-1")
    out += f"startxref\n{xref_pos}\n%%EOF\n".encode("latin-1")
    return bytes(out)


class _Encryptor:
    """Standard security handler, encrypt side (for fixtures): rc4 = V2/R3 128-bit,
    aes128 = V4/R4 AESV2, aes256 = V5/R6 AESV3. Deterministic so tests are reproducible."""

    def __init__(self, mode: str, user: str, owner: str, seed: bytes):
        import hashlib
        import struct

        from ..pdf import crypto

        self.mode = mode
        self.crypto = crypto
        self.id0 = hashlib.md5(seed).digest()
        self.p = -3904
        upw, opw = user.encode("utf-8"), owner.encode("utf-8")
        pad = lambda pw: (pw + crypto.PAD)[:32]  # noqa: E731
        if mode in ("rc4", "aes128"):
            r = 3 if mode == "rc4" else 4
            ok = hashlib.md5(pad(opw)).digest()
            for _ in range(50):
                ok = hashlib.md5(ok).digest()
            ok = ok[:16]
            o = crypto.rc4(ok, pad(upw))
            for i in range(1, 20):
                o = crypto.rc4(bytes(b ^ i for b in ok), o)
            key = hashlib.md5(pad(upw) + o + struct.pack("<i", self.p) + self.id0).digest()
            for _ in range(50):
                key = hashlib.md5(key[:16]).digest()
            self.key = key[:16]
            x = crypto.rc4(self.key, hashlib.md5(crypto.PAD + self.id0).digest())
            for i in range(1, 20):
                x = crypto.rc4(bytes(b ^ i for b in self.key), x)
            u = x + b"\0" * 16
            d = {"Filter": Name("Standard"), "V": 2 if r == 3 else 4, "R": r, "Length": 128, "O": o, "U": u, "P": self.p}
            if r == 4:
                d["CF"] = {"StdCF": {"CFM": Name("AESV2"), "Length": 16, "AuthEvent": Name("DocOpen")}}
                d["StmF"] = Name("StdCF")
                d["StrF"] = Name("StdCF")
            self.encrypt_dict = d
        elif mode == "aes256":
            self.key = hashlib.sha256(seed + b"file-key").digest()
            vs, ks = hashlib.sha256(seed + b"vs").digest()[:8], hashlib.sha256(seed + b"ks").digest()[:8]
            u = crypto._r6_hash(upw, vs, b"", 6) + vs + ks
            ue = crypto.AES(crypto._r6_hash(upw, ks, b"", 6)).cbc_encrypt(b"\0" * 16, self.key)
            ovs, oks = hashlib.sha256(seed + b"ovs").digest()[:8], hashlib.sha256(seed + b"oks").digest()[:8]
            o = crypto._r6_hash(opw, ovs, u, 6) + ovs + oks
            oe = crypto.AES(crypto._r6_hash(opw, oks, u, 6)).cbc_encrypt(b"\0" * 16, self.key)
            perms = crypto.AES(self.key).encrypt_block(struct.pack("<i", self.p) + b"\xff\xff\xff\xffTadb" + b"\0" * 4)
            self.encrypt_dict = {"Filter": Name("Standard"), "V": 5, "R": 6, "Length": 256, "O": o, "U": u,
                                 "OE": oe, "UE": ue, "P": self.p, "Perms": perms,
                                 "CF": {"StdCF": {"CFM": Name("AESV3"), "Length": 32, "AuthEvent": Name("DocOpen")}},
                                 "StmF": Name("StdCF"), "StrF": Name("StdCF")}
        else:
            raise ValueError(mode)

    def _obj_key(self, num: int, aes: bool) -> bytes:
        import hashlib
        import struct

        if self.mode == "aes256":
            return self.key
        k = self.key + struct.pack("<i", num)[:3] + b"\0\0" + (b"sAlT" if aes else b"")
        return hashlib.md5(k).digest()[:16]

    def data(self, raw: bytes, num: int) -> bytes:
        import hashlib

        if self.mode == "rc4":
            return self.crypto.rc4(self._obj_key(num, False), raw)
        iv = hashlib.md5(b"iv" + num.to_bytes(4, "big") + raw[:16]).digest()
        padn = 16 - len(raw) % 16
        return iv + self.crypto.AES(self._obj_key(num, True)).cbc_encrypt(iv, raw + bytes([padn]) * padn)

    def value(self, v: Any, num: int) -> Any:
        if isinstance(v, (bytes, bytearray)):
            return self.data(bytes(v), num)
        if isinstance(v, str) and not isinstance(v, Name):
            return self.data(v.encode("cp1252", "replace"), num)
        if isinstance(v, list):
            return [self.value(x, num) for x in v]
        if isinstance(v, dict):
            return {k: self.value(x, num) for k, x in v.items()}
        return v
