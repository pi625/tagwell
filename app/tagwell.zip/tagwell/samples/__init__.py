"""Sample-document generation (fictional content only; never real customer data)."""
