"""Analyse one PDF end to end. Never raises for bad input: returns a report describing the problem."""
from __future__ import annotations

import os

from .checks import run_checks
from .model import analyse
from .pdf.document import EncryptedPDFError
from .pdf.objects import PDFError
from .report import DocumentReport, build_report, error_report

MAX_BYTES = 200 * 1024 * 1024


def check_file(path: str, data: bytes | None = None, cost_per_page: float = 6.0,
               only: set[str] | None = None) -> DocumentReport:
    try:
        if data is None:
            if os.path.getsize(path) > MAX_BYTES:
                return error_report(path, f"file larger than {MAX_BYTES // (1024 * 1024)} MB")
            with open(path, "rb") as fh:
                data = fh.read()
        if not data.lstrip()[:5].startswith(b"%PDF") and b"%PDF-" not in data[:1024]:
            return error_report(path, "not a PDF file")
        a = analyse(path, data)
    except EncryptedPDFError as e:
        return error_report(path, str(e))
    except PDFError as e:
        return error_report(path, f"unreadable PDF: {e}")
    except (OSError, MemoryError, RecursionError) as e:
        return error_report(path, f"{type(e).__name__}: {e}")
    findings, errors = run_checks(a, only)
    return build_report(path, a, findings, errors, cost_per_page)


def collect_pdfs(paths: list[str]) -> list[str]:
    out = []
    for p in paths:
        if os.path.isdir(p):
            for root, _dirs, files in os.walk(p):
                for f in sorted(files):
                    if f.lower().endswith(".pdf"):
                        out.append(os.path.join(root, f))
        else:
            out.append(p)
    return out
