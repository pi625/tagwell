"""Turns findings into per-page routing decisions and renders JSON, text and HTML reports."""
from __future__ import annotations

import html
import json
import os
from dataclasses import dataclass, field
from typing import Any

from . import __version__
from .findings import Finding

STATUS_FAIL = "fail"
STATUS_REVIEW = "needs-review"
STATUS_CLEAN = "no-detected-defects"
STATUS_ERROR = "not-analysable"
ALL_PAGE_CHECKS = {"untagged-document", "security-at-access", "encrypted", "lang-missing", "lang-mismatch"}

DISCLAIMER = ("Tagwell reports evidence of accessibility defects that automated rule checkers "
              "(veraPDF, PAC) do not test. It does not certify compliance with WCAG, PDF/UA, Section 508 "
              "or the ADA, and a page with no detected defects can still have problems Tagwell cannot see.")


@dataclass
class PageSummary:
    page: int  # 0-based
    status: str
    findings: int
    width: float = 612
    height: float = 792
    units: list[dict] = field(default_factory=list)  # for diagrams: bbox, rank, type, flagged


@dataclass
class DocumentReport:
    file: str
    pages: int
    tagged: bool
    status: str
    findings: list[Finding]
    page_summaries: list[PageSummary]
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    cost_per_page: float = 6.0

    @property
    def pages_by_status(self) -> dict[str, list[int]]:
        out: dict[str, list[int]] = {STATUS_FAIL: [], STATUS_REVIEW: [], STATUS_CLEAN: []}
        for p in self.page_summaries:
            out.setdefault(p.status, []).append(p.page)
        return out

    def routing(self) -> dict[str, Any]:
        by = self.pages_by_status
        human = sorted(by[STATUS_FAIL] + by[STATUS_REVIEW])
        return {
            "pages_total": self.pages,
            "pages_fail": len(by[STATUS_FAIL]),
            "pages_needs_review": len(by[STATUS_REVIEW]),
            "pages_no_detected_defects": len(by[STATUS_CLEAN]),
            "pages_for_human": [p + 1 for p in human],
            "cost_per_page_assumed": self.cost_per_page,
            "cost_if_every_page_reviewed": round(self.pages * self.cost_per_page, 2),
            "cost_if_only_flagged_pages_reviewed": round(len(human) * self.cost_per_page, 2),
        }

    def to_dict(self) -> dict[str, Any]:
        counts: dict[str, int] = {}
        for f in self.findings:
            counts[f.severity] = counts.get(f.severity, 0) + 1
        return {
            "tool": "Tagwell",
            "version": __version__,
            "file": os.path.basename(self.file),
            "pages": self.pages,
            "tagged": self.tagged,
            "status": self.status,
            "counts": counts,
            "routing": self.routing(),
            "findings": [f.to_dict() for f in self.findings],
            "pages_detail": [{"page": p.page + 1, "status": p.status, "findings": p.findings} for p in self.page_summaries],
            "errors": self.errors,
            "warnings": self.warnings[:50],
            "disclaimer": DISCLAIMER,
        }


def page_status(findings: list[Finding]) -> str:
    if any(f.severity == "error" and f.confidence == "high" for f in findings):
        return STATUS_FAIL
    if any(f.severity in ("error", "warning") for f in findings) or any(f.needs_human for f in findings if f.severity != "notice"):
        return STATUS_REVIEW
    return STATUS_CLEAN


def build_report(path: str, analysis: Any, findings: list[Finding], errors: list[str], cost_per_page: float = 6.0) -> DocumentReport:
    sev_rank = {"error": 0, "warning": 1, "notice": 2}
    findings = sorted(findings, key=lambda f: (f.page if f.page is not None else -1, sev_rank[f.severity], f.check))
    doc_level = [f for f in findings if f.page is None]
    summaries = []
    flagged_boxes: dict[int, list] = {}
    for f in findings:
        if f.page is not None:
            flagged_boxes.setdefault(f.page, []).extend(f.related_boxes or ([f.bbox] if f.bbox else []))
    for pc in analysis.pages:
        pf = [f for f in findings if f.page == pc.page]
        # Document-level problems that change how every page is read (untagged, language, no access for
        # assistive technology) route every page; the rest (title, metadata, outline) are reported once.
        st = page_status(pf + [f for f in doc_level if f.check in ALL_PAGE_CHECKS])
        units = []
        flagged = flagged_boxes.get(pc.page, [])
        for u in analysis.units_by_page.get(pc.page, []):
            units.append({"bbox": [round(v, 1) for v in u.bbox], "rank": u.logical_rank, "type": u.type,
                          "text": u.snippet(40), "flagged": any(_overlaps(u.bbox, b) for b in flagged)})
        summaries.append(PageSummary(pc.page, st, len(pf), pc.width, pc.height, units))
    tagged = analysis.tree.root is not None and bool(analysis.tree.nodes)
    statuses = {s.status for s in summaries}
    if doc_level:
        statuses.add(page_status(doc_level))
    status = STATUS_FAIL if STATUS_FAIL in statuses else STATUS_REVIEW if STATUS_REVIEW in statuses else STATUS_CLEAN
    return DocumentReport(path, len(analysis.pages), tagged, status, findings, summaries, errors,
                          analysis.warnings, cost_per_page)


def error_report(path: str, message: str) -> DocumentReport:
    return DocumentReport(path, 0, False, STATUS_ERROR, [], [], [message])


def _overlaps(a, b) -> bool:
    return not (a[2] < b[0] or b[2] < a[0] or a[3] < b[1] or b[3] < a[1])


# --- text -------------------------------------------------------------------

def render_text(reports: list[DocumentReport]) -> str:
    lines = []
    for r in reports:
        lines.append(f"{os.path.basename(r.file)}: {r.status.upper()}  ({r.pages} page(s){'' if r.tagged or not r.pages else ', untagged'})")
        if r.status == STATUS_ERROR:
            lines.append(f"  could not analyse: {'; '.join(r.errors)}")
            continue
        rt = r.routing()
        lines.append(f"  pages: {rt['pages_fail']} fail, {rt['pages_needs_review']} need review, "
                     f"{rt['pages_no_detected_defects']} no detected defects")
        for f in r.findings:
            where = f"p{f.page + 1}" if f.page is not None else "doc"
            mh = f" [Matterhorn {', '.join(f.matterhorn)}]" if f.matterhorn else ""
            lines.append(f"  - {where:>4} {f.severity:<7} {f.confidence:<6} {f.title}{mh}")
        for e in r.errors:
            lines.append(f"  ! {e}")
    total = sum(r.pages for r in reports)
    human = sum(len(r.routing()["pages_for_human"]) for r in reports if r.status != STATUS_ERROR)
    lines.append("")
    lines.append(f"{len(reports)} document(s), {total} page(s); {human} page(s) flagged for a person, "
                 f"{total - human} with no detected defects.")
    return "\n".join(lines)


# --- JSON -------------------------------------------------------------------

def render_json(reports: list[DocumentReport]) -> str:
    return json.dumps({"documents": [r.to_dict() for r in reports], "disclaimer": DISCLAIMER}, indent=2, ensure_ascii=False)


# --- HTML -------------------------------------------------------------------

_CSS = """
:root{--bg:#fbfaf7;--fg:#1d1d1b;--muted:#5d5b55;--card:#ffffff;--line:#dedad2;--err:#b42318;--warn:#a15c07;
--note:#2e5aac;--ok:#18794e;--accent:#3b4cca;--box:#7a8599;--flag:#d92d20}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){--bg:#151514;--fg:#ecebe6;--muted:#a8a69f;
--card:#1f1f1d;--line:#3a3935;--err:#ff6b5e;--warn:#f0a43a;--note:#8fb1ff;--ok:#4cc38a;--accent:#a6b0ff;--box:#8d97a8;--flag:#ff6b5e}}
:root[data-theme="dark"]{--bg:#151514;--fg:#ecebe6;--muted:#a8a69f;--card:#1f1f1d;--line:#3a3935;--err:#ff6b5e;
--warn:#f0a43a;--note:#8fb1ff;--ok:#4cc38a;--accent:#a6b0ff;--box:#8d97a8;--flag:#ff6b5e}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--fg);font:15px/1.5 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:1060px;margin:0 auto;padding:24px 16px 64px}h1{font-size:26px;margin:0 0 4px}h2{font-size:20px;margin:32px 0 8px}
h3{font-size:16px;margin:20px 0 6px}.muted{color:var(--muted)}.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:16px;margin:12px 0}
table{border-collapse:collapse;width:100%}th,td{text-align:left;padding:6px 8px;border-bottom:1px solid var(--line);vertical-align:top}
.pill{display:inline-block;padding:1px 8px;border-radius:999px;font-size:12px;font-weight:600;border:1px solid currentColor}
.fail,.error{color:var(--err)}.needs-review,.warning{color:var(--warn)}.no-detected-defects{color:var(--ok)}.notice{color:var(--note)}
.not-analysable{color:var(--muted)}.f{border-left:3px solid var(--line);padding:6px 12px;margin:10px 0}.f.error{border-color:var(--err)}
.f.warning{border-color:var(--warn)}.f.notice{border-color:var(--note)}.f .t{color:var(--fg);font-weight:600}.f p{margin:4px 0;color:var(--fg)}
.f ul{margin:4px 0 0 18px;padding:0;color:var(--muted);font-size:14px}.tags{font-size:12px;color:var(--muted)}
.pages{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,340px),1fr));gap:16px}
.pg svg{width:100%;height:auto;background:var(--card);border:1px solid var(--line);border-radius:6px}
.pg figcaption{font-size:13px;margin-top:4px}.stats{display:flex;flex-wrap:wrap;gap:12px}.stat{flex:1 1 150px}
.stat b{display:block;font-size:22px}.scroll{overflow-x:auto}footer{margin-top:40px;font-size:13px;color:var(--muted)}
"""


def _e(s: Any) -> str:
    return html.escape(str(s), quote=True)


def _svg(p: PageSummary, crop: bool = False) -> str:
    w, h = max(p.width, 1), max(p.height, 1)
    vb = f"0 0 {w:.0f} {h:.0f}"
    if crop and p.units:
        m = 24
        x0 = max(min(u["bbox"][0] for u in p.units) - m, 0)
        x1 = min(max(u["bbox"][2] for u in p.units) + m, w)
        top = max(h - max(u["bbox"][3] for u in p.units) - m, 0)
        bottom = min(h - min(u["bbox"][1] for u in p.units) + m, h)
        vb = f"{x0:.0f} {top:.0f} {x1 - x0:.0f} {bottom - top:.0f}"
    parts = [f'<svg viewBox="{vb}" role="img" aria-label="Page {p.page + 1} layout: numbered boxes '
             f'show the order assistive technology reads blocks; red boxes have findings">']
    ordered = sorted(p.units, key=lambda u: u["rank"])
    r = max(min(w, h) / 34, 7)
    if len(ordered) > 1:
        pts = []
        for u in ordered:
            x0, y0, x1, y1 = u["bbox"]
            pts.append(f"{x0 + r:.1f},{h - y1 + r:.1f}")
        parts.append(f'<polyline points="{" ".join(pts)}" fill="none" stroke="var(--accent)" stroke-width="2" '
                     'stroke-dasharray="6 4" vector-effect="non-scaling-stroke" opacity="0.85"/>')
    for n, u in enumerate(ordered, 1):
        x0, y0, x1, y1 = u["bbox"]
        y = h - y1
        col = "var(--flag)" if u["flagged"] else "var(--box)"
        parts.append(f'<rect x="{x0:.1f}" y="{y:.1f}" width="{max(x1 - x0, 1):.1f}" height="{max(y1 - y0, 1):.1f}" '
                     f'fill="none" stroke="{col}" stroke-width="{2.5 if u["flagged"] else 1.2}" '
                     f'vector-effect="non-scaling-stroke"><title>{_e(n)}. {_e(u["type"])}: {_e(u["text"])}</title></rect>')
        parts.append(f'<circle cx="{x0 + r:.1f}" cy="{y + r:.1f}" r="{r:.1f}" fill="{col}"/>'
                     f'<text x="{x0 + r:.1f}" y="{y + r:.1f}" font-size="{r * 1.15:.1f}" fill="var(--card)" '
                     f'text-anchor="middle" dominant-baseline="central" font-family="system-ui,sans-serif" '
                     f'font-weight="700">{n}</text>')
    parts.append("</svg>")
    return "".join(parts)


def render_html(reports: list[DocumentReport], title: str = "Tagwell report") -> str:
    out = [f"<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" "
           f"content=\"width=device-width,initial-scale=1\"><title>{_e(title)}</title><style>{_CSS}</style></head><body><main>"]
    out.append(f"<h1>{_e(title)}</h1><p class=\"muted\">Semantic accessibility check of tagged PDFs. "
               f"Tagwell {_e(__version__)}.</p>")
    total = sum(r.pages for r in reports)
    human = sum(len(r.routing()["pages_for_human"]) for r in reports if r.status != STATUS_ERROR)
    out.append('<div class="card stats">')
    out.append(f'<div class="stat"><b>{len(reports)}</b>documents</div><div class="stat"><b>{total}</b>pages</div>')
    out.append(f'<div class="stat"><b>{human}</b>pages flagged for a person</div>')
    out.append(f'<div class="stat"><b>{total - human}</b>pages with no detected defects</div></div>')
    out.append('<div class="card scroll"><table><thead><tr><th>Document</th><th>Status</th><th>Pages</th>'
               '<th>Errors</th><th>Warnings</th><th>Notices</th><th>Pages for a person</th></tr></thead><tbody>')
    for i, r in enumerate(reports):
        c = {"error": 0, "warning": 0, "notice": 0}
        for f in r.findings:
            c[f.severity] += 1
        rt = r.routing() if r.status != STATUS_ERROR else {"pages_for_human": []}
        hp = ", ".join(str(p) for p in rt["pages_for_human"][:20]) or "none"
        out.append(f'<tr><td><a href="#d{i}">{_e(os.path.basename(r.file))}</a></td>'
                   f'<td><span class="pill {_e(r.status)}">{_e(r.status)}</span></td><td>{r.pages}</td>'
                   f'<td>{c["error"]}</td><td>{c["warning"]}</td><td>{c["notice"]}</td><td>{_e(hp)}</td></tr>')
    out.append("</tbody></table></div>")
    for i, r in enumerate(reports):
        out.append(f'<h2 id="d{i}">{_e(os.path.basename(r.file))} <span class="pill {_e(r.status)}">{_e(r.status)}</span></h2>')
        if r.status == STATUS_ERROR:
            out.append(f'<p class="muted">Could not analyse: {_e("; ".join(r.errors))}</p>')
            continue
        rt = r.routing()
        out.append(f'<p class="muted">{r.pages} page(s), {"tagged" if r.tagged else "not tagged"}. '
                   f'{rt["pages_fail"]} fail, {rt["pages_needs_review"]} need review, '
                   f'{rt["pages_no_detected_defects"]} with no detected defects. At ${rt["cost_per_page_assumed"]:g}/page, '
                   f'reviewing only flagged pages costs ${rt["cost_if_only_flagged_pages_reviewed"]:,.2f} instead of '
                   f'${rt["cost_if_every_page_reviewed"]:,.2f}.</p>')
        if r.page_summaries and any(p.units for p in r.page_summaries):
            out.append('<div class="pages">')
            for p in r.page_summaries[:40]:
                out.append(f'<figure class="pg">{_svg(p)}<figcaption>Page {p.page + 1}: '
                           f'<span class="{_e(p.status)}">{_e(p.status)}</span></figcaption></figure>')
            out.append("</div><p class=\"tags\">Boxes are numbered in the order assistive technology reads them; the "
                       "dashed line follows that order. Red boxes have findings.</p>")
        if not r.findings:
            out.append('<p>No defects detected by Tagwell\'s checks.</p>')
        for f in r.findings:
            where = f"Page {f.page + 1}" if f.page is not None else "Document"
            tags = []
            if f.matterhorn:
                tags.append("Matterhorn " + ", ".join(f.matterhorn) + (" (machine)" if f.machine_checkable else " (human)"))
            if f.wcag:
                tags.append("WCAG " + ", ".join(f.wcag))
            tags.append(f"confidence {f.confidence}")
            if f.needs_human:
                tags.append("confirm by a person")
            ev = "".join(f"<li>{_e(x)}</li>" for x in f.evidence)
            ev_html = "<ul>" + ev + "</ul>" if ev else ""
            tag_text = _e(" · ".join(tags))
            out.append(f'<div class="f {_e(f.severity)}"><span class="t">{_e(where)} · {_e(f.title)}</span> '
                       f'<span class="pill {_e(f.severity)}">{_e(f.severity)}</span><p>{_e(f.message)}</p>'
                       f'{ev_html}<div class="tags">{tag_text}</div></div>')
        for e in r.errors:
            out.append(f'<p class="muted">Internal: {_e(e)}</p>')
    out.append(f"<footer><p>{_e(DISCLAIMER)}</p></footer></main></body></html>")
    return "".join(out)
