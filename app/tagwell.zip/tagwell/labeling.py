"""Human review sheets for measuring accuracy on real documents.

`label` writes a CSV with one row per finding (verdict: TP / FP / unsure) and one row per page
that had no findings (verdict: OK / MISSED, for estimating missed defects). `score` reads the
filled-in sheet and reports precision per check and the page-level miss rate.
"""
from __future__ import annotations

import csv
import os
from collections import defaultdict

from .engine import check_file, collect_pdfs
from .report import STATUS_ERROR

FIELDS = ["file", "page", "row_type", "check", "severity", "confidence", "title", "message", "evidence",
          "verdict", "notes"]
FINDING_VERDICTS = {"TP", "FP", "UNSURE"}
PAGE_VERDICTS = {"OK", "MISSED"}


def write_sheet(paths: list[str], out_csv: str) -> dict:
    files = collect_pdfs(paths)
    n_find = n_pages = n_err = 0
    os.makedirs(os.path.dirname(os.path.abspath(out_csv)), exist_ok=True)
    with open(out_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=FIELDS)
        w.writeheader()
        for f in files:
            r = check_file(f)
            name = os.path.relpath(f)
            if r.status == STATUS_ERROR:
                n_err += 1
                w.writerow({"file": name, "row_type": "error", "message": "; ".join(r.errors), "verdict": "n/a"})
                continue
            for x in r.findings:
                n_find += 1
                w.writerow({"file": name, "page": "" if x.page is None else x.page + 1, "row_type": "finding",
                            "check": x.check, "severity": x.severity, "confidence": x.confidence, "title": x.title,
                            "message": x.message, "evidence": " | ".join(x.evidence[:3]), "verdict": "", "notes": ""})
            flagged = {x.page for x in r.findings if x.page is not None}
            for p in r.page_summaries:
                if p.page not in flagged:
                    n_pages += 1
                    w.writerow({"file": name, "page": p.page + 1, "row_type": "clean-page",
                                "message": "No page-level findings. Open the page: is there a reading-order, heading, "
                                           "table, list, alt-text or artifact problem Tagwell missed?",
                                "verdict": "", "notes": ""})
    return {"documents": len(files), "findings": n_find, "clean_pages": n_pages, "unreadable": n_err}


def score_sheet(csv_path: str) -> dict:
    per_check: dict[str, dict[str, int]] = defaultdict(lambda: {"TP": 0, "FP": 0, "UNSURE": 0, "blank": 0})
    pages = {"OK": 0, "MISSED": 0, "blank": 0}
    with open(csv_path, newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            v = (row.get("verdict") or "").strip().upper()
            if row.get("row_type") == "finding":
                per_check[row["check"]][v if v in FINDING_VERDICTS else "blank"] += 1
            elif row.get("row_type") == "clean-page":
                pages[v if v in PAGE_VERDICTS else "blank"] += 1
    checks = {}
    tp = fp = 0
    for c, d in sorted(per_check.items()):
        judged = d["TP"] + d["FP"]
        checks[c] = {**d, "precision": (d["TP"] / judged) if judged else None}
        tp += d["TP"]
        fp += d["FP"]
    judged_pages = pages["OK"] + pages["MISSED"]
    return {
        "checks": checks,
        "overall_precision": (tp / (tp + fp)) if tp + fp else None,
        "clean_pages": pages,
        "clean_page_miss_rate": (pages["MISSED"] / judged_pages) if judged_pages else None,
    }


def format_score(s: dict) -> str:
    lines = [f"{'check':<22}{'TP':>4}{'FP':>4}{'unsure':>8}{'blank':>7}{'precision':>11}"]
    for c, d in s["checks"].items():
        prec = "-" if d["precision"] is None else f"{d['precision']:.0%}"
        lines.append(f"{c:<22}{d['TP']:>4}{d['FP']:>4}{d['UNSURE']:>8}{d['blank']:>7}{prec:>11}")
    op = s["overall_precision"]
    lines.append(f"overall precision: {'-' if op is None else f'{op:.0%}'}")
    cp = s["clean_pages"]
    mr = s["clean_page_miss_rate"]
    lines.append(f"clean pages: {cp['OK']} OK, {cp['MISSED']} with a missed defect, {cp['blank']} not reviewed"
                 f" (miss rate {'-' if mr is None else f'{mr:.0%}'})")
    return "\n".join(lines)
